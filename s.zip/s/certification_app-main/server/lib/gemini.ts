import { GoogleGenAI, ThinkingLevel } from "@google/genai";

// 무료 등급이 있는 최신 Flash 모델. 필요하면 이 상수만 바꾸면 된다.
export const GEMINI_MODEL = "gemini-3.8-flash";

// gemini-3.8-flash(Flash 계열)는 thinking을 완전히 끌 수 없고, thinking에 쓴
// 토큰도 maxOutputTokens에서 깎인다. OCR/해설 생성처럼 깊은 추론이 필요 없는
// 작업에는 가장 낮은 단계로 설정해서 실제 답변에 토큰을 더 남겨준다.
export const GEMINI_LOW_THINKING = { thinkingLevel: ThinkingLevel.LOW };

export function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY not configured");
  }
  return new GoogleGenAI({ apiKey });
}
