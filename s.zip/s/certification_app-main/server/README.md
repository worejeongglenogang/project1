# Backend Development Guide

이 서버는 원래 Manus 플랫폼 템플릿(OAuth 로그인, MySQL DB, S3 스토리지, 자체 LLM/이미지생성/TTS 헬퍼 등)을 기반으로 만들어졌지만, 실제로 이 앱이 쓰는 기능은 그중 아무것도 없었다는 걸 확인하고 전부 걷어낸 적이 있다 (배경은 프로젝트 루트의 `ADSP_퀴즈앱_재기획서.md` "인프라 전환" 절 참고). 이후 로그인 기능을 다시 추가하면서, 로그인 계정에 딸린 학습 기록(오답노트/통계/일별 로그)을 저장할 자체 DB도 다시 들어왔다. 지금 이 서버가 하는 일은 세 가지다:

1. **로그인/회원가입** — 이메일 + 비밀번호 기반 자체 인증 (JWT 발급).
2. **학습 기록 저장** — 오답노트, 과목별 통계, 일별 학습 로그를 로그인 계정 기준으로 DB에 저장.
3. **Gemini API 대행** — 클라이언트가 tRPC로 보내는 사진 OCR, 해설 생성 요청을 `GEMINI_API_KEY`를 들고 대신 처리 (`server/lib/gemini.ts`). 원래 OpenAI(GPT-4o)를 썼지만, Gemini는 Google AI Studio에서 결제 없이 무료로 키를 받을 수 있어서 바꿨다 — 무료 등급은 요청 속도 제한이 있고 입력 데이터가 구글 제품 개선에 쓰일 수 있다는 점만 참고.

문제 데이터(90문항)는 여전히 `data/questions.ts`에 정적으로 번들되어 있고 DB에는 없다 — 자주 바뀌지 않는 콘텐츠라 굳이 옮길 실익이 없다는 판단.

---

## 파일 구조

```
server/
  routers.ts          ← tRPC 프로시저 (auth.*, progress.*, vision.recognizeQuestion, explain.generateForWrongAnswer)
  auth/
    password.ts        ← bcrypt 해시/검증
    jwt.ts              ← JWT 서명/검증
  db/
    schema.ts           ← drizzle 테이블 정의 (users, wrong_answers, study_stats, subject_stats, daily_log)
    client.ts           ← libsql(SQLite) + drizzle 클라이언트
    init.ts             ← 서버 부팅 시 테이블을 CREATE TABLE IF NOT EXISTS로 준비
  _core/
    index.ts           ← Express 서버 부팅 (CORS, /api/health, /api/trpc 마운트, initDb 호출)
    context.ts          ← tRPC 컨텍스트 (Authorization: Bearer <JWT>를 파싱해 userId를 담음)
    trpc.ts              ← tRPC 초기화 (router, publicProcedure, protectedProcedure)
```

새 기능을 추가할 때는 `server/routers.ts`에 라우터/프로시저를 추가하면 된다. 로그인이 필요한 기능은 `protectedProcedure`를 쓰면 `ctx.userId`가 항상 채워져 있다고 가정할 수 있다 (없으면 자동으로 UNAUTHORIZED를 던진다).

---

## DB

로컬 파일 SQLite(`@libsql/client` + `drizzle-orm/libsql`)를 쓴다. Windows에 Visual Studio 빌드 도구가 없어도 되도록 네이티브 컴파일이 필요한 `better-sqlite3` 대신 선택했다.

- 로컬 DB 파일: 프로젝트 루트의 `local.db` (git에는 커밋되지 않음, `.gitignore` 참고).
- 스키마를 바꾸면 `server/db/schema.ts`와 `server/db/init.ts`의 `CREATE TABLE` 문을 같이 수정해야 한다 (지금은 마이그레이션 도구 없이 idempotent한 부트스트랩으로 처리한다).
- 원격 DB(Turso 등)로 옮기고 싶으면 `DATABASE_URL`에 `libsql://...` 형태의 URL을 넣으면 된다.
- `drizzle-kit`도 devDependency로 들어있어서(`pnpm db:studio`로 로컬 DB를 GUI로 볼 수 있다), 나중에 정식 마이그레이션 파일이 필요해지면 `pnpm db:generate`로 시작할 수 있다.

---

## 환경변수

`.env.example`을 `.env`로 복사해서 채우면 된다.

| 변수 | 설명 |
|------|------|
| `GEMINI_API_KEY` | 사진 OCR과 해설 생성에 쓰는 Gemini API 키. 필수. https://aistudio.google.com/apikey 에서 무료로 발급받는다. |
| `JWT_SECRET` | 로그인 토큰 서명 비밀 키. 비워두면 개발용 기본값으로 동작하지만 실제 사용자가 접근하는 환경에서는 반드시 채워야 한다. |
| `DATABASE_URL` | 비워두면 로컬 `local.db` 사용. 원격 SQLite(Turso 등)로 옮길 때만 채운다. |
| `EXPO_PUBLIC_API_BASE_URL` | 앱이 이 서버를 찾을 주소. 로컬 웹/시뮬레이터에서는 보통 비워둬도 자동으로 찾는다(`constants/api.ts` 참고). 같은 와이파이의 실기기(Expo Go)에서 테스트할 때는 이 컴퓨터의 LAN IP로 반드시 지정해야 한다. |

---

## 로컬에서 실행하기

```bash
pnpm install
cp .env.example .env   # GEMINI_API_KEY 채우기
pnpm dev                # 서버(3000번 포트) + Metro(8081번 포트) 동시 실행
```

- 웹 브라우저: `http://localhost:8081` — 처음 접속하면 로그인 화면으로 리다이렉트된다. 회원가입 후 이용하면 된다.
- 같은 와이파이의 실기기(Expo Go): `.env`에 `EXPO_PUBLIC_API_BASE_URL=http://<이 컴퓨터의 LAN IP>:3000`을 설정한 뒤 Expo Go로 QR 스캔

서버가 정상 기동했는지는 `curl http://localhost:3000/api/health` 로 확인할 수 있다.

---

## tRPC 프로시저 추가하기

```ts
// server/routers.ts
export const appRouter = router({
  // ...기존 라우터들...

  myFeature: router({
    doSomething: protectedProcedure // 로그인 필요 없으면 publicProcedure
      .input(z.object({ text: z.string() }))
      .mutation(async ({ ctx, input }) => {
        // ctx.userId로 로그인한 사용자를 식별할 수 있다 (protectedProcedure일 때)
        return { result: "..." };
      }),
  }),
});
```

클라이언트에서는 `trpc.myFeature.doSomething.useMutation()`처럼 그대로 타입 안전하게 호출할 수 있다 (`lib/trpc.ts`). 화면 밖(예: `lib/storage.ts`처럼 훅이 아닌 일반 함수)에서 호출해야 하면 `lib/trpc.ts`의 `trpcVanilla`를 쓴다.

---

## 나중에 파일 스토리지가 실제로 필요해지면

사진을 서버에 저장해야 하는 기능이 생기면(지금은 사진을 서버에 올리지 않고 바로 Gemini로 보내기만 한다) S3 호환 스토리지(AWS S3, Cloudflare R2 등)를 붙이면 된다.
