import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { randomUUID } from "node:crypto";
import { eq, and, desc, sql } from "drizzle-orm";
import { db } from "./db/client";
import {
  users,
  wrongAnswers,
  studyStats,
  subjectStats,
  dailyLog,
  questionAttempts,
  mockExamResults,
  bookmarks,
} from "./db/schema";
import { hashPassword, verifyPassword } from "./auth/password";
import { signToken } from "./auth/jwt";
import { getGeminiClient, GEMINI_MODEL, GEMINI_LOW_THINKING } from "./lib/gemini";
import { incrementDailyLog, recordAnswers, updateStudyStats } from "./lib/progress";
import { SUBJECTS, questions, type Question, type Subject } from "@/data/questions";
import { addDays, isValidDateStr, kstDateStr } from "@/lib/kst-date";
import { scoreMockExam, type SubjectScore } from "@/lib/mock-exam-scoring";

const subjectSchema = z.enum(SUBJECTS as [Subject, ...Subject[]]);

const questionById = new Map(questions.map((q) => [q.id, q]));

function getQuestionOrThrow(questionId: string): Question {
  const q = questionById.get(questionId);
  if (!q) {
    throw new TRPCError({ code: "BAD_REQUEST", message: `알 수 없는 문제입니다: ${questionId}` });
  }
  return q;
}

const answerInputSchema = z.object({
  questionId: z.string(),
  selectedOption: z.number().int().min(0),
});

function emptySubjectTotals(): Record<Subject, { total: number; correct: number }> {
  return {
    "1과목(데이터 이해)": { total: 0, correct: 0 },
    "2과목(데이터 분석 기획)": { total: 0, correct: 0 },
    "3과목(데이터 분석)": { total: 0, correct: 0 },
  };
}

const authRouter = router({
  signup: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        nickname: z.string().trim().min(1, "닉네임을 입력해주세요.").max(20, "닉네임은 20자 이하로 입력해주세요."),
        password: z.string().min(6, "비밀번호는 6자 이상이어야 합니다."),
      })
    )
    .mutation(async ({ input }) => {
      const email = input.email.trim().toLowerCase();
      const nickname = input.nickname.trim();

      const existing = await db.select().from(users).where(eq(users.email, email)).get();
      if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "이미 가입된 이메일입니다." });
      }

      const passwordHash = await hashPassword(input.password);
      const id = randomUUID();
      await db.insert(users).values({ id, email, nickname, passwordHash, createdAt: Date.now() });

      const token = signToken({ userId: id });
      return { token, user: { id, email, nickname } };
    }),

  login: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const email = input.email.trim().toLowerCase();
      const user = await db.select().from(users).where(eq(users.email, email)).get();
      if (!user) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "이메일 또는 비밀번호가 올바르지 않습니다." });
      }

      const valid = await verifyPassword(input.password, user.passwordHash);
      if (!valid) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "이메일 또는 비밀번호가 올바르지 않습니다." });
      }

      const token = signToken({ userId: user.id });
      return { token, user: { id: user.id, email: user.email, nickname: user.nickname } };
    }),

  me: protectedProcedure.query(async ({ ctx }) => {
    const user = await db.select().from(users).where(eq(users.id, ctx.userId)).get();
    if (!user) {
      throw new TRPCError({ code: "NOT_FOUND", message: "사용자를 찾을 수 없습니다." });
    }
    return { id: user.id, email: user.email, nickname: user.nickname };
  }),
});

const progressRouter = router({
  getWrongAnswers: protectedProcedure.query(async ({ ctx }) => {
    const rows = await db.select().from(wrongAnswers).where(eq(wrongAnswers.userId, ctx.userId));
    return rows.map((r) => ({
      questionId: r.questionId,
      subject: r.subject as Subject,
      selectedOption: r.selectedOption,
      correctOption: r.correctOption,
      timestamp: r.timestamp,
      correctStreak: r.correctStreak,
      nextReviewAt: r.nextReviewAt,
    }));
  }),

  // 문제 풀이 화면들(일반/오답 재풀기)이 답을 고를 때마다 호출한다. 풀이 기록,
  // 통계, 일별 로그, 오답노트 반복 학습을 한 번에 처리하고 문제별 결과를 돌려준다.
  submitAnswers: protectedProcedure
    .input(z.object({ answers: z.array(answerInputSchema).min(1).max(100) }))
    .mutation(async ({ ctx, input }) => {
      const items = input.answers.map((a) => ({
        question: getQuestionOrThrow(a.questionId),
        selectedOption: a.selectedOption,
      }));
      return recordAnswers(ctx.userId, items);
    }),

  // 문제별 누적 풀이 기록. 진도율, 안 푼 문제 우선 출제, 자주 틀리는 문제 순위에 쓴다.
  getQuestionProgress: protectedProcedure.query(async ({ ctx }) => {
    // SQLite는 max()가 딱 하나 있는 집계 쿼리에서, 집계되지 않은 컬럼(correct, timestamp)을
    // max()가 고른 행에서 가져온다. id는 자동 증가라 max(id)가 마지막 풀이이므로,
    // 이걸로 "마지막 풀이의 정답 여부/시각"을 한 번에 구한다. (max/min을 더 넣으면 이 보장이 깨진다.)
    const rows = await db
      .select({
        questionId: questionAttempts.questionId,
        attempts: sql<number>`count(*)`,
        correct: sql<number>`sum(${questionAttempts.correct})`,
        lastId: sql<number>`max(${questionAttempts.id})`,
        lastAt: questionAttempts.timestamp,
        lastCorrect: questionAttempts.correct,
      })
      .from(questionAttempts)
      .where(eq(questionAttempts.userId, ctx.userId))
      .groupBy(questionAttempts.questionId);

    return rows.map((r) => ({
      questionId: r.questionId,
      attempts: Number(r.attempts),
      correct: Number(r.correct),
      lastCorrect: Number(r.lastCorrect) === 1,
      lastAt: Number(r.lastAt),
    }));
  }),

  addWrongAnswer: protectedProcedure
    .input(
      z.object({
        questionId: z.string(),
        subject: subjectSchema,
        selectedOption: z.number(),
        correctOption: z.number(),
        timestamp: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db
        .insert(wrongAnswers)
        .values({ userId: ctx.userId, ...input })
        .onConflictDoUpdate({
          target: [wrongAnswers.userId, wrongAnswers.questionId],
          set: {
            subject: input.subject,
            selectedOption: input.selectedOption,
            correctOption: input.correctOption,
            timestamp: input.timestamp,
            correctStreak: 0,
          },
        });
    }),

  removeWrongAnswer: protectedProcedure
    .input(z.object({ questionId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await db
        .delete(wrongAnswers)
        .where(and(eq(wrongAnswers.userId, ctx.userId), eq(wrongAnswers.questionId, input.questionId)));
    }),

  clearWrongAnswers: protectedProcedure.mutation(async ({ ctx }) => {
    await db.delete(wrongAnswers).where(eq(wrongAnswers.userId, ctx.userId));
  }),

  getStudyStats: protectedProcedure.query(async ({ ctx }) => {
    const stats = await db.select().from(studyStats).where(eq(studyStats.userId, ctx.userId)).get();
    const subjectRows = await db
      .select()
      .from(subjectStats)
      .where(eq(subjectStats.userId, ctx.userId));

    const bySubject = emptySubjectTotals();
    for (const row of subjectRows) {
      bySubject[row.subject as Subject] = { total: row.total, correct: row.correct };
    }

    return {
      totalAnswered: stats?.totalAnswered ?? 0,
      totalCorrect: stats?.totalCorrect ?? 0,
      bySubject,
      lastStudiedAt: stats?.lastStudiedAt ?? null,
      streakDays: stats?.streakDays ?? 0,
      lastStreakDate: stats?.lastStreakDate ?? null,
    };
  }),

  recordAnswer: protectedProcedure
    .input(z.object({ subject: subjectSchema, isCorrect: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      await updateStudyStats(ctx.userId, [input]);
    }),

  resetStudyStats: protectedProcedure.mutation(async ({ ctx }) => {
    await db.delete(studyStats).where(eq(studyStats.userId, ctx.userId));
    await db.delete(subjectStats).where(eq(subjectStats.userId, ctx.userId));
    await db.delete(questionAttempts).where(eq(questionAttempts.userId, ctx.userId));
    await db.delete(mockExamResults).where(eq(mockExamResults.userId, ctx.userId));
  }),

  // 한국 시간 기준 오늘 포함 최근 7일. 마지막 항목이 오늘이다.
  getLast7DaysLog: protectedProcedure.query(async ({ ctx }) => {
    const rows = await db.select().from(dailyLog).where(eq(dailyLog.userId, ctx.userId));
    const byDate = new Map(rows.map((r) => [r.date, r.count]));

    const today = kstDateStr();
    const result: { date: string; count: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const dateStr = addDays(today, -i);
      result.push({ date: dateStr, count: byDate.get(dateStr) ?? 0 });
    }
    return result;
  }),

  incrementDailyLog: protectedProcedure.mutation(async ({ ctx }) => {
    await incrementDailyLog(ctx.userId);
  }),
});

const mockExamRouter = router({
  // 답안 기록(통계/오답노트 반영)과 채점, 결과 저장을 한 번에 한다.
  // 풀지 않은 문제(selectedOption: null)는 오답으로 채점하되 풀이 기록에는 남기지 않는다.
  submit: protectedProcedure
    .input(
      z.object({
        answers: z
          .array(
            z.object({
              questionId: z.string(),
              selectedOption: z.number().int().min(0).nullable(),
            })
          )
          .min(1)
          .max(100),
        durationSeconds: z.number().int().min(0),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const items = input.answers.map((a) => ({
        question: getQuestionOrThrow(a.questionId),
        selected: a.selectedOption,
      }));

      await recordAnswers(
        ctx.userId,
        items.flatMap((i) =>
          i.selected === null ? [] : [{ question: i.question, selectedOption: i.selected }]
        )
      );

      const score = scoreMockExam(items);
      const takenAt = Date.now();
      await db.insert(mockExamResults).values({
        userId: ctx.userId,
        takenAt,
        total: score.total,
        correct: score.correct,
        subjectScores: JSON.stringify(score.bySubject),
        passed: score.passed ? 1 : 0,
        durationSeconds: input.durationSeconds,
      });
      return { ...score, takenAt };
    }),

  // 최근 응시 기록 (최신순)
  list: protectedProcedure
    .input(z.object({ limit: z.number().int().min(1).max(100).default(20) }).optional())
    .query(async ({ ctx, input }) => {
      const rows = await db
        .select()
        .from(mockExamResults)
        .where(eq(mockExamResults.userId, ctx.userId))
        .orderBy(desc(mockExamResults.takenAt))
        .limit(input?.limit ?? 20);

      return rows.map((r) => ({
        id: r.id,
        takenAt: r.takenAt,
        total: r.total,
        correct: r.correct,
        bySubject: JSON.parse(r.subjectScores) as Record<Subject, SubjectScore>,
        passed: r.passed === 1,
        durationSeconds: r.durationSeconds,
      }));
    }),
});

const bookmarkRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const rows = await db
      .select()
      .from(bookmarks)
      .where(eq(bookmarks.userId, ctx.userId))
      .orderBy(desc(bookmarks.createdAt));
    return rows.map((r) => r.questionId);
  }),

  toggle: protectedProcedure
    .input(z.object({ questionId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      getQuestionOrThrow(input.questionId);
      const where = and(eq(bookmarks.userId, ctx.userId), eq(bookmarks.questionId, input.questionId));
      const existing = await db.select().from(bookmarks).where(where).get();
      if (existing) {
        await db.delete(bookmarks).where(where);
        return { bookmarked: false };
      }
      await db
        .insert(bookmarks)
        .values({ userId: ctx.userId, questionId: input.questionId, createdAt: Date.now() });
      return { bookmarked: true };
    }),
});

const settingsRouter = router({
  get: protectedProcedure.query(async ({ ctx }) => {
    const user = await db.select().from(users).where(eq(users.id, ctx.userId)).get();
    return { examDate: user?.examDate ?? null };
  }),

  setExamDate: protectedProcedure
    .input(
      z.object({
        examDate: z
          .string()
          .refine(isValidDateStr, "날짜는 YYYY-MM-DD 형식으로 입력해주세요.")
          .nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db.update(users).set({ examDate: input.examDate }).where(eq(users.id, ctx.userId));
      return { examDate: input.examDate };
    }),
});

export const appRouter = router({
  auth: authRouter,
  progress: progressRouter,
  mockExam: mockExamRouter,
  bookmark: bookmarkRouter,
  settings: settingsRouter,

  // AI Vision API for image recognition
  // 문제 텍스트 추출과 해설 생성을 한 번의 Gemini 호출로 합쳐서 처리한다.
  // (예전엔 OCR 따로, explain.generate 따로 - 사진 한 장당 쿼터 2회씩 썼는데,
  // 무료 쿼터가 하루 20회뿐이라 금방 소진됐다. Gemini는 사진인식과 오답 맞춤
  // 해설(explain.generateForWrongAnswer)에만 쓰기로 했다.)
  vision: router({
    recognizeQuestion: publicProcedure
      .input(z.object({
        base64Image: z.string(),
      }))
      .mutation(async ({ input }) => {
        try {
          console.log("[Server] Recognizing question + generating explanation from image...");
          console.log("[Server] Image size:", input.base64Image.length, "bytes");

          const ai = getGeminiClient();
          const response = await ai.models.generateContent({
            model: GEMINI_MODEL,
            contents: [
              {
                role: "user",
                parts: [
                  {
                    text:
                      "이 이미지에서 보이는 IT 자격증 시험 문제의 모든 텍스트(문제, 선택지)를 정확하게 추출하고, 이어서 정답과 해설을 작성해주세요.\n\n" +
                      "다음 형식을 정확히 지켜서 답변하세요 (대괄호 표시도 그대로 포함):\n" +
                      "[문제]\n(추출한 문제와 선택지 전체)\n\n" +
                      "[해설]\n(정답이 무엇이고 왜 그런지 설명하는 해설. 약 30초 분량의 음성 해설로 읽을 수 있는 길이, 학생을 격려하는 자연스러운 어조)",
                  },
                  {
                    inlineData: {
                      mimeType: "image/jpeg",
                      data: input.base64Image,
                    },
                  },
                ],
              },
            ],
            config: {
              temperature: 0.3,
              maxOutputTokens: 4096,
              thinkingConfig: GEMINI_LOW_THINKING,
            },
          });

          const fullText = response.text ?? "";

          if (!fullText || fullText.trim().length === 0) {
            console.error("[Server] Empty response from Gemini. Full response:", JSON.stringify(response));
            throw new Error("Empty response from Gemini");
          }

          const marker = fullText.match(/\[해설\]/);
          if (!marker || marker.index === undefined) {
            console.error("[Server] Could not find [해설] marker in Gemini response:", fullText);
            throw new Error("해설 구간을 찾을 수 없습니다");
          }

          const text = fullText.slice(0, marker.index).replace(/^\[문제\]\s*/, "").trim();
          const explanation = fullText.slice(marker.index + marker[0].length).trim();

          if (!text || !explanation) {
            console.error("[Server] Question or explanation parsing failed. Full response:", fullText);
            throw new Error("문제 또는 해설 파싱 실패");
          }

          console.log("[Server] Question + explanation recognized successfully");
          return {
            success: true,
            text,
            explanation,
          };
        } catch (error) {
          console.error("[Server] Vision API error:", error);
          console.error("[Server] Error details:", error instanceof Error ? error.message : String(error));
          throw error;
        }
      }),
  }),

  explain: router({
    // 오답노트 전용: 문제은행의 고정 해설 대신, 학생이 실제로 고른 오답을
    // 콕 집어서 "왜 그게 틀렸고 정답은 왜 맞는지"를 설명한다.
    generateForWrongAnswer: publicProcedure
      .input(
        z.object({
          question: z.string(),
          options: z.array(z.string()),
          selectedOption: z.number(),
          correctOption: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const optionsList = input.options
            .map((opt, idx) => `${idx + 1}. ${opt}`)
            .join("\n");

          const ai = getGeminiClient();
          const response = await ai.models.generateContent({
            model: GEMINI_MODEL,
            contents: [
              {
                role: "user",
                parts: [
                  {
                    text: `문제: ${input.question}\n\n선택지:\n${optionsList}\n\n학생이 선택한 답: ${
                      input.options[input.selectedOption]
                    }\n정답: ${
                      input.options[input.correctOption]
                    }\n\n학생이 왜 이 선택지를 오답으로 골랐을지 짚어주고, 그 선택지가 왜 틀렸는지, 그리고 정답이 왜 맞는지 설명해주세요.`,
                  },
                ],
              },
            ],
            config: {
              systemInstruction:
                "당신은 IT 자격증 시험 문제 해설 전문가입니다. 학생이 실제로 고른 오답을 기준으로, 그 오답이 왜 틀렸는지와 정답이 왜 맞는지를 자연스러운 음성 해설처럼 설명하세요. 약 30초 분량으로 읽을 수 있는 길이로 작성하고, 학생을 탓하지 말고 격려하는 어조를 쓰세요.",
              temperature: 0.7,
              maxOutputTokens: 2048,
              thinkingConfig: GEMINI_LOW_THINKING,
            },
          });

          const explanation = response.text ?? "";

          if (!explanation || explanation.trim().length === 0) {
            console.error(
              "[Server] Empty personalized explanation from Gemini. Full response:",
              JSON.stringify(response)
            );
            throw new Error("Empty explanation from Gemini");
          }

          return { success: true, explanation: explanation.trim() };
        } catch (error) {
          console.error("[Server] Personalized wrong-answer explanation error:", error);
          console.error("[Server] Error details:", error instanceof Error ? error.message : String(error));
          throw error;
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
