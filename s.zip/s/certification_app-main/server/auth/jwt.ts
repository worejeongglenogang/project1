import jwt from "jsonwebtoken";

const DEV_FALLBACK_SECRET = "adsp-quiz-app-dev-only-secret-do-not-use-in-production";

function getSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    console.warn(
      "[auth] JWT_SECRET is not set — using an insecure development default. " +
        "Set JWT_SECRET in .env before deploying anywhere real users can reach."
    );
    return DEV_FALLBACK_SECRET;
  }
  return secret;
}

export interface AuthTokenPayload {
  userId: string;
}

export function signToken(payload: AuthTokenPayload): string {
  return jwt.sign(payload, getSecret(), { expiresIn: "30d" });
}

export function verifyToken(token: string): AuthTokenPayload | null {
  try {
    const decoded = jwt.verify(token, getSecret());
    if (typeof decoded === "object" && decoded && "userId" in decoded) {
      return { userId: String((decoded as Record<string, unknown>).userId) };
    }
    return null;
  } catch {
    return null;
  }
}
