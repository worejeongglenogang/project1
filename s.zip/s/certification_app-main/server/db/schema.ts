import { sqliteTable, text, integer, primaryKey } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  nickname: text("nickname").notNull(),
  passwordHash: text("password_hash").notNull(),
  createdAt: integer("created_at").notNull(),
  // 시험일(YYYY-MM-DD, KST). 홈 화면 D-day 표시에 쓴다.
  examDate: text("exam_date"),
});

export const wrongAnswers = sqliteTable(
  "wrong_answers",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    questionId: text("question_id").notNull(),
    subject: text("subject").notNull(),
    selectedOption: integer("selected_option").notNull(),
    correctOption: integer("correct_option").notNull(),
    timestamp: integer("timestamp").notNull(),
    // 반복 학습: 복습일에 맞힌 횟수(연속). WRONG_GRADUATE_STREAK에 도달하면 오답노트에서 졸업.
    correctStreak: integer("correct_streak").notNull().default(0),
    // 다음 복습 예정 시각(ms). 이 시각 이후에 맞혀야 correctStreak가 올라간다.
    nextReviewAt: integer("next_review_at").notNull().default(0),
  },
  (table) => [primaryKey({ columns: [table.userId, table.questionId] })]
);

// 문제별 풀이 기록 (한 번 풀 때마다 한 줄). 진도율, 안 푼 문제 우선 출제,
// 자주 틀리는 문제 순위를 여기서 계산한다.
export const questionAttempts = sqliteTable("question_attempts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  questionId: text("question_id").notNull(),
  subject: text("subject").notNull(),
  correct: integer("correct").notNull(), // 0 | 1
  timestamp: integer("timestamp").notNull(),
});

export const mockExamResults = sqliteTable("mock_exam_results", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  takenAt: integer("taken_at").notNull(),
  total: integer("total").notNull(),
  correct: integer("correct").notNull(),
  // 과목별 점수 JSON: { [subject]: { total, correct } }
  subjectScores: text("subject_scores").notNull(),
  passed: integer("passed").notNull(), // 0 | 1
  durationSeconds: integer("duration_seconds").notNull(),
});

export const bookmarks = sqliteTable(
  "bookmarks",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    questionId: text("question_id").notNull(),
    createdAt: integer("created_at").notNull(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.questionId] })]
);

export const studyStats = sqliteTable("study_stats", {
  userId: text("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  totalAnswered: integer("total_answered").notNull().default(0),
  totalCorrect: integer("total_correct").notNull().default(0),
  lastStudiedAt: integer("last_studied_at"),
  streakDays: integer("streak_days").notNull().default(0),
  lastStreakDate: text("last_streak_date"),
});

export const subjectStats = sqliteTable(
  "subject_stats",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    subject: text("subject").notNull(),
    total: integer("total").notNull().default(0),
    correct: integer("correct").notNull().default(0),
  },
  (table) => [primaryKey({ columns: [table.userId, table.subject] })]
);

export const dailyLog = sqliteTable(
  "daily_log",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    date: text("date").notNull(),
    count: integer("count").notNull().default(0),
  },
  (table) => [primaryKey({ columns: [table.userId, table.date] })]
);
