import { createClient } from "@libsql/client";
import { drizzle } from "drizzle-orm/libsql";
import * as schema from "./schema";

// 로컬 파일 기반 SQLite. Turso 등 원격 DB로 옮기려면 DATABASE_URL만 바꾸면 된다.
const url = process.env.DATABASE_URL || "file:local.db";

const client = createClient({ url });

export const db = drizzle(client, { schema });
