import { db } from "./client";

// 이미 존재하던 로컬 DB에 컬럼을 추가한다. 컬럼이 이미 있으면 SQLite가 에러를 던지는데, 그건 무시한다.
async function addColumnIfMissing(statement: string): Promise<void> {
  try {
    await db.run(statement);
  } catch {
    // 컬럼이 이미 존재함 - 정상.
  }
}

/**
 * schema.ts와 동일한 테이블을 만드는 부트스트랩. drizzle-kit 마이그레이션 없이
 * `pnpm dev`만으로 로컬 DB가 바로 준비되도록 서버 시작 시 한 번 실행한다.
 * 컬럼을 바꿀 때는 이 파일도 schema.ts와 같이 수정해야 한다.
 */
export async function initDb(): Promise<void> {
  await db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      nickname TEXT NOT NULL DEFAULT '',
      password_hash TEXT NOT NULL,
      created_at INTEGER NOT NULL
    )
  `);

  // 이미 존재하던 로컬 DB(nickname/exam_date 컬럼 추가 전에 만들어진)를 위한 마이그레이션.
  await addColumnIfMissing(`ALTER TABLE users ADD COLUMN nickname TEXT NOT NULL DEFAULT ''`);
  await addColumnIfMissing(`ALTER TABLE users ADD COLUMN exam_date TEXT`);

  await db.run(`
    CREATE TABLE IF NOT EXISTS wrong_answers (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id TEXT NOT NULL,
      subject TEXT NOT NULL,
      selected_option INTEGER NOT NULL,
      correct_option INTEGER NOT NULL,
      timestamp INTEGER NOT NULL,
      correct_streak INTEGER NOT NULL DEFAULT 0,
      next_review_at INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, question_id)
    )
  `);
  // 반복 학습 컬럼 추가 전의 DB. 기존 오답은 next_review_at=0이라 바로 복습 대상이 된다.
  await addColumnIfMissing(
    `ALTER TABLE wrong_answers ADD COLUMN correct_streak INTEGER NOT NULL DEFAULT 0`
  );
  await addColumnIfMissing(
    `ALTER TABLE wrong_answers ADD COLUMN next_review_at INTEGER NOT NULL DEFAULT 0`
  );

  await db.run(`
    CREATE TABLE IF NOT EXISTS question_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id TEXT NOT NULL,
      subject TEXT NOT NULL,
      correct INTEGER NOT NULL,
      timestamp INTEGER NOT NULL
    )
  `);
  await db.run(
    `CREATE INDEX IF NOT EXISTS idx_question_attempts_user ON question_attempts (user_id, question_id)`
  );

  await db.run(`
    CREATE TABLE IF NOT EXISTS mock_exam_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      taken_at INTEGER NOT NULL,
      total INTEGER NOT NULL,
      correct INTEGER NOT NULL,
      subject_scores TEXT NOT NULL,
      passed INTEGER NOT NULL,
      duration_seconds INTEGER NOT NULL
    )
  `);

  await db.run(`
    CREATE TABLE IF NOT EXISTS bookmarks (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      PRIMARY KEY (user_id, question_id)
    )
  `);

  await db.run(`
    CREATE TABLE IF NOT EXISTS study_stats (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      total_answered INTEGER NOT NULL DEFAULT 0,
      total_correct INTEGER NOT NULL DEFAULT 0,
      last_studied_at INTEGER,
      streak_days INTEGER NOT NULL DEFAULT 0,
      last_streak_date TEXT
    )
  `);

  await db.run(`
    CREATE TABLE IF NOT EXISTS subject_stats (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject TEXT NOT NULL,
      total INTEGER NOT NULL DEFAULT 0,
      correct INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, subject)
    )
  `);

  await db.run(`
    CREATE TABLE IF NOT EXISTS daily_log (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      count INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, date)
    )
  `);
}
