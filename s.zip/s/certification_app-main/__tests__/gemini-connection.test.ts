import { describe, it, expect } from "vitest";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";

/**
 * Gemini API 키 연결 테스트.
 * 키 형식은 AIzaSy.../AQ. 등으로 계속 바뀌어왔기 때문에(구글 쪽 마이그레이션 진행 중)
 * 접두어를 강제로 검사하지 않고, 실제로 호출이 되는지만 확인한다.
 */
describe("Gemini API Connection", () => {
  it("should have GEMINI_API_KEY environment variable set", () => {
    const apiKey = process.env.GEMINI_API_KEY;
    expect(apiKey).toBeDefined();
    expect(apiKey).not.toBe("");
    expect(apiKey?.length).toBeGreaterThan(0);
  });

  it("should test basic API connectivity", async () => {
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not set");
    }

    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [{ role: "user", parts: [{ text: "Say OK" }] }],
      // gemini-3.8-flash always spends some tokens "thinking" before answering
      // (it can't fully disable it) - low thinking + enough headroom avoids
      // finishReason: MAX_TOKENS with empty text.
      config: { maxOutputTokens: 64, thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } },
    });

    expect(response.text).toBeDefined();
    expect(response.text?.length).toBeGreaterThan(0);
  });
});
