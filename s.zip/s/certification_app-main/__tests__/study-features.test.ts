import { describe, it, expect, beforeAll, beforeEach } from "vitest";

/**
 * 풀이 기록/반복 학습 오답노트/모의고사 기록/북마크/시험일 설정과
 * KST 날짜 처리 테스트. 서버 라우터는 인메모리 SQLite로 직접 호출한다 (storage.test.ts와 동일).
 */
process.env.DATABASE_URL = ":memory:";

let appRouter: (typeof import("../server/routers"))["appRouter"];
let progressLib: typeof import("../server/lib/progress");

function createCaller(userId: string | null) {
  return appRouter.createCaller({ req: {} as never, res: {} as never, userId });
}

async function createTestUser() {
  const { user } = await createCaller(null).auth.signup({
    email: `feat-${Date.now()}-${Math.random()}@example.com`,
    nickname: "기능테스트",
    password: "password123",
  });
  return user.id;
}

beforeAll(async () => {
  const { initDb } = await import("../server/db/init");
  await initDb();
  ({ appRouter } = await import("../server/routers"));
  progressLib = await import("../server/lib/progress");
});

describe("KST dates", () => {
  it("uses Korean date even before 9am KST", async () => {
    const { kstDateStr } = await import("../lib/kst-date");
    // 2026-09-28 23:30 UTC = 2026-09-29 08:30 KST
    expect(kstDateStr(new Date("2026-09-28T23:30:00Z"))).toBe("2026-09-29");
  });

  it("keeps the streak when studying early in the morning on consecutive days", async () => {
    const userId = await createTestUser();
    const subject = "1과목(데이터 이해)" as const;
    // KST 9/29 08:30, KST 9/30 05:00 - UTC로는 둘 다 전날이라 예전 로직이면 날짜가 어긋났다
    await progressLib.updateStudyStats(userId, [{ subject, isCorrect: true }], new Date("2026-09-28T23:30:00Z"));
    await progressLib.updateStudyStats(userId, [{ subject, isCorrect: true }], new Date("2026-09-29T20:00:00Z"));
    const stats = await createCaller(userId).progress.getStudyStats();
    expect(stats.streakDays).toBe(2);
    expect(stats.lastStreakDate).toBe("2026-09-30");
  });

  it("last 7 days log ends with today in KST", async () => {
    const { kstDateStr } = await import("../lib/kst-date");
    const userId = await createTestUser();
    const log = await createCaller(userId).progress.getLast7DaysLog();
    expect(log).toHaveLength(7);
    expect(log[6].date).toBe(kstDateStr());
  });
});

describe("Question progress", () => {
  let userId: string;
  beforeEach(async () => {
    userId = await createTestUser();
  });

  it("counts distinct questions and tracks the last result", async () => {
    const caller = createCaller(userId);
    // di-001 정답은 3
    await caller.progress.submitAnswers({ answers: [{ questionId: "di-001", selectedOption: 0 }] });
    await caller.progress.submitAnswers({ answers: [{ questionId: "di-001", selectedOption: 3 }] });
    await caller.progress.submitAnswers({ answers: [{ questionId: "di-002", selectedOption: 0 }] });

    const progress = await caller.progress.getQuestionProgress();
    expect(progress).toHaveLength(2);
    const di001 = progress.find((p) => p.questionId === "di-001")!;
    expect(di001.attempts).toBe(2);
    expect(di001.correct).toBe(1);
    expect(di001.lastCorrect).toBe(true);
    expect(progress.find((p) => p.questionId === "di-002")!.lastCorrect).toBe(false);

    const stats = await caller.progress.getStudyStats();
    expect(stats.totalAnswered).toBe(3);
  });

  it("rejects unknown question ids", async () => {
    await expect(
      createCaller(userId).progress.submitAnswers({ answers: [{ questionId: "nope", selectedOption: 0 }] })
    ).rejects.toThrow();
  });

  it("pickQuestions puts unseen questions first", async () => {
    const { pickQuestions } = await import("../lib/question-picker");
    const { getQuestionsBySubject } = await import("../data/questions");
    const pool = getQuestionsBySubject("1과목(데이터 이해)");
    const seen = pool.slice(0, 195).map((q) => ({
      questionId: q.id,
      attempts: 1,
      correct: 1,
      lastCorrect: true,
      lastAt: 1,
    }));
    const picked = pickQuestions(pool, 10, seen);
    const unseenIds = new Set(pool.slice(195).map((q) => q.id));
    expect(picked).toHaveLength(10);
    expect(picked.filter((q) => unseenIds.has(q.id))).toHaveLength(5);
  });
});

describe("Spaced repetition wrong answers", () => {
  const DAY = 24 * 60 * 60 * 1000;
  let userId: string;
  let question: import("../data/questions").Question;

  beforeAll(async () => {
    const { questions } = await import("../data/questions");
    question = questions.find((q) => q.id === "di-001")!;
  });
  beforeEach(async () => {
    userId = await createTestUser();
  });

  const answer = (correct: boolean, at: number) =>
    progressLib.recordAnswers(
      userId,
      [{ question, selectedOption: correct ? question.answer : (question.answer + 1) % 4 }],
      new Date(at)
    );

  it("needs 3 correct reviews on due days to graduate", async () => {
    const t0 = Date.parse("2026-09-29T12:00:00+09:00");
    expect((await answer(false, t0))[0].reviewStatus).toBe("added");

    // 같은 날 맞힌 건 복습일 전이라 반영 안 됨
    expect((await answer(true, t0 + 60_000))[0].reviewStatus).toBe("not_due");

    const r1 = await answer(true, t0 + 1 * DAY);
    expect(r1[0]).toMatchObject({ reviewStatus: "advanced", correctStreak: 1 });

    // 3일 간격 전에는 반영 안 됨
    expect((await answer(true, t0 + 2 * DAY))[0].reviewStatus).toBe("not_due");

    const r2 = await answer(true, t0 + 4 * DAY);
    expect(r2[0]).toMatchObject({ reviewStatus: "advanced", correctStreak: 2 });

    const r3 = await answer(true, t0 + 11 * DAY);
    expect(r3[0].reviewStatus).toBe("graduated");

    expect(await createCaller(userId).progress.getWrongAnswers()).toHaveLength(0);
  });

  it("resets progress when answered wrong again", async () => {
    const t0 = Date.parse("2026-09-29T12:00:00+09:00");
    await answer(false, t0);
    await answer(true, t0 + DAY);
    const reset = await answer(false, t0 + 2 * DAY);
    expect(reset[0]).toMatchObject({ reviewStatus: "reset", correctStreak: 0 });

    const [wrong] = await createCaller(userId).progress.getWrongAnswers();
    expect(wrong.correctStreak).toBe(0);
    // 다음 날 KST 자정에 복습 대상
    expect(wrong.nextReviewAt).toBe(Date.parse("2026-10-02T00:00:00+09:00"));
  });

  it("becomes due at KST midnight, not 24 hours later", async () => {
    const { applyReview } = await import("../lib/review-schedule");
    const lateNight = Date.parse("2026-09-29T23:00:00+09:00");
    const update = applyReview(null, false, lateNight);
    expect(update.kind).toBe("upsert");
    if (update.kind === "upsert") {
      expect(update.state.nextReviewAt).toBe(Date.parse("2026-09-30T00:00:00+09:00"));
    }
  });
});

describe("Mock exam results", () => {
  it("scores, saves, and lists results; unanswered questions are not recorded as attempts", async () => {
    const userId = await createTestUser();
    const caller = createCaller(userId);
    const { getMockExamQuestions } = await import("../data/questions");
    const exam = getMockExamQuestions();

    // 전부 정답, 마지막 문제만 안 풂
    const result = await caller.mockExam.submit({
      answers: exam.map((q, i) => ({
        questionId: q.id,
        selectedOption: i === exam.length - 1 ? null : q.answer,
      })),
      durationSeconds: 1234,
    });
    expect(result.total).toBe(50);
    expect(result.correct).toBe(49);
    expect(result.passed).toBe(true);

    const list = await caller.mockExam.list();
    expect(list).toHaveLength(1);
    expect(list[0]).toMatchObject({ correct: 49, total: 50, passed: true, durationSeconds: 1234 });
    expect(list[0].bySubject["3과목(데이터 분석)"].total).toBe(30);

    expect(await caller.progress.getQuestionProgress()).toHaveLength(49);
  });

  it("fails when one subject is below 40% even if overall is 60%+", async () => {
    const { scoreMockExam } = await import("../lib/mock-exam-scoring");
    const { getMockExamQuestions } = await import("../data/questions");
    const exam = getMockExamQuestions();
    // 1과목(앞 10문제)만 전부 틀리고 나머지 40문제 정답 → 80%지만 과락
    const score = scoreMockExam(
      exam.map((q, i) => ({ question: q, selected: i < 10 ? (q.answer + 1) % 4 : q.answer }))
    );
    expect(score.correct).toBe(40);
    expect(score.passed).toBe(false);
  });
});

describe("Bookmarks and settings", () => {
  it("toggles bookmarks", async () => {
    const caller = createCaller(await createTestUser());
    expect((await caller.bookmark.toggle({ questionId: "di-001" })).bookmarked).toBe(true);
    expect(await caller.bookmark.list()).toEqual(["di-001"]);
    expect((await caller.bookmark.toggle({ questionId: "di-001" })).bookmarked).toBe(false);
    expect(await caller.bookmark.list()).toEqual([]);
  });

  it("saves and validates the exam date", async () => {
    const caller = createCaller(await createTestUser());
    expect((await caller.settings.get()).examDate).toBeNull();
    await caller.settings.setExamDate({ examDate: "2026-11-15" });
    expect((await caller.settings.get()).examDate).toBe("2026-11-15");
    await expect(caller.settings.setExamDate({ examDate: "2026-13-40" })).rejects.toThrow();
    await caller.settings.setExamDate({ examDate: null });
    expect((await caller.settings.get()).examDate).toBeNull();
  });
});
