import * as ReactNative from "react-native";

/**
 * 로컬 개발 환경 전용 API 베이스 URL 해석.
 *
 * 이 프로젝트는 더 이상 Manus 플랫폼을 쓰지 않는다 (ADSP_퀴즈앱_재기획서.md
 * "인프라 전환" 참고). 예전에는 Manus 샌드박스가 "8081-xxx.region.domain"
 * (Expo 웹 미리보기) 같은 호스트명을 "3000-xxx..."로 바꿔주는 프록시를 앞단에
 * 뒀는데, 그 규칙에 맞춰 호스트명을 문자열 치환하는 코드가 있었다. 이제는
 * 평범한 로컬 개발 환경(내 컴퓨터에서 서버 + Metro를 같이 띄우는 상황)을
 * 기준으로 API 서버 주소를 찾는다.
 *
 * 우선순위:
 * 1. `EXPO_PUBLIC_API_BASE_URL` 환경변수 — 명시적으로 지정한 경우. 같은
 *    와이파이의 실기기에서 Expo Go로 테스트할 때는 이걸로 내 컴퓨터의 LAN IP를
 *    지정해야 한다 (예: `http://192.168.0.5:3000`) — 실기기 입장에서
 *    "localhost"는 자기 자신이라 컴퓨터의 서버에 닿지 못하기 때문.
 * 2. 웹: 현재 브라우저 호스트명 + 3000번 포트 (Metro 웹은 8081, API 서버는
 *    3000번 포트를 쓴다 — package.json 참고)
 * 3. 네이티브(Expo Go 등): Expo가 알려주는 개발 서버 호스트(`hostUri`)에서
 *    IP만 뽑아 3000번 포트로 재사용 (시뮬레이터/에뮬레이터에서 자동으로 맞는
 *    경우가 많지만, 실기기는 1번 환경변수를 직접 지정하는 게 가장 확실하다)
 * 4. 그래도 못 찾으면 `http://localhost:3000`으로 폴백 (iOS 시뮬레이터 등)
 */

const envApiBaseUrl = process.env.EXPO_PUBLIC_API_BASE_URL ?? "";

export function getApiBaseUrl(): string {
  if (envApiBaseUrl) {
    return envApiBaseUrl.replace(/\/$/, "");
  }

  if (ReactNative.Platform.OS === "web" && typeof window !== "undefined" && window.location) {
    const { protocol, hostname } = window.location;
    return `${protocol}//${hostname}:3000`;
  }

  if (ReactNative.Platform.OS !== "web") {
    try {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const Constants = require("expo-constants").default;
      const hostUri: string | undefined =
        Constants?.expoConfig?.hostUri ??
        Constants?.expoGoConfig?.debuggerHost ??
        Constants?.manifest?.debuggerHost;
      if (hostUri && typeof hostUri === "string") {
        const hostname = hostUri.split(":")[0];
        if (hostname) {
          return `http://${hostname}:3000`;
        }
      }
    } catch (error) {
      console.warn("[API] Could not determine API URL from Expo constants", error);
    }
  }

  console.warn(
    "[API] Could not auto-detect the API server address — falling back to http://localhost:3000. " +
      "실기기에서 테스트 중이라면 EXPO_PUBLIC_API_BASE_URL 환경변수로 컴퓨터의 LAN IP를 직접 지정하세요 " +
      "(예: EXPO_PUBLIC_API_BASE_URL=http://192.168.0.5:3000)."
  );
  return "http://localhost:3000";
}
