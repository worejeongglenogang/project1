# 테스트 실행 방법

이 프로젝트는 [Vitest](https://vitest.dev)로 테스트를 작성합니다. 테스트 파일은 [`__tests__/`](__tests__) 폴더에 있습니다.

## 1. pnpm 설치

이 프로젝트는 `pnpm@9.12.0`을 사용합니다 (`package.json`의 `packageManager` 필드). 아직 설치되어 있지 않다면 아래 중 하나로 설치하세요.

```
npm install -g pnpm@9.12.0
```

또는 (Node의 corepack이 정상 동작하는 환경이라면)

```
corepack enable
corepack prepare pnpm@9.12.0 --activate
```

## 2. 의존성 설치

```
cd adsp-quiz-app
pnpm install
```

## 3. 환경변수 설정 (선택)

`__tests__/gemini-connection.test.ts`는 Gemini API 연결을 확인하는 테스트로, `GEMINI_API_KEY` 환경변수가 없으면 2개 테스트가 모두 실패합니다. 이 키가 필요한 테스트까지 통과시키려면 아래처럼 `.env` 파일을 만들고 키를 채우세요.

```
cp .env.example .env
```

`.env` 파일에 https://aistudio.google.com/apikey 에서 무료로 발급받은 Gemini API 키를 입력합니다.

```
GEMINI_API_KEY=...
```

키가 없어도 나머지 테스트(`ai-service`, `photo-recognition`, `storage`)는 정상적으로 통과합니다.

## 4. 테스트 실행

전체 테스트 실행:

```
pnpm test
```

특정 파일만 실행:

```
pnpm test __tests__/storage.test.ts
```

## 참고: 확인된 실행 결과

`GEMINI_API_KEY` 없이 실행한 결과 (2026-09-07 기준):

- 통과: 47개 (`photo-recognition`, `ai-service`, `storage`)
- 실패: 2개 (`gemini-connection` — 전부 `GEMINI_API_KEY`가 없어서 발생하는 실패이며, 실제 코드 문제는 아님)
