import React, { useState, useCallback, useRef } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Animated,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { BookmarkButton } from "@/components/bookmark-button";
import { DonguraeExplainButton } from "@/components/dongurae-explain-button";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { useBookmarks } from "@/hooks/use-bookmarks";
import { questions, Question, SUBJECT_COLORS } from "@/data/questions";
import { shuffle } from "@/lib/question-picker";
import {
  isDueForReview,
  REVIEW_INTERVAL_DAYS,
  WRONG_GRADUATE_STREAK,
} from "@/lib/review-schedule";
import { getWrongAnswers, submitAnswer, AnswerOutcome } from "@/lib/storage";

/** 답을 고른 뒤 오답노트 반복 학습 진행 상황을 한 줄로 알려준다. */
function reviewMessage(outcome: AnswerOutcome): string | null {
  switch (outcome.reviewStatus) {
    case "graduated":
      return `🎓 ${WRONG_GRADUATE_STREAK}번 복습 완료! 오답노트에서 졸업했어요`;
    case "advanced": {
      const streak = outcome.correctStreak ?? 0;
      return `복습 ${streak}/${WRONG_GRADUATE_STREAK} 완료 · ${REVIEW_INTERVAL_DAYS[streak]}일 뒤 다시 나와요`;
    }
    case "not_due":
      return "아직 복습일이 아니라서 복습 진도에는 반영되지 않았어요";
    case "reset":
    case "added":
      return `복습 진도가 처음부터 다시 시작돼요 · ${REVIEW_INTERVAL_DAYS[0]}일 뒤 다시 나와요`;
    default:
      return null;
  }
}

export default function WrongSessionScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();
  // mode: "due"면 오늘 복습할 문제만, 그 외엔 필터에 해당하는 오답 전체
  const { filter, mode } = useLocalSearchParams<{ filter: string; mode?: string }>();
  const bookmarks = useBookmarks();

  const [sessionQuestions, setSessionQuestions] = useState<Question[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [outcome, setOutcome] = useState<AnswerOutcome | null>(null);
  const [graduatedCount, setGraduatedCount] = useState(0);
  const [phase, setPhase] = useState<"quiz" | "result">("quiz");
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const dueOnly = mode === "due";

  // Load wrong answers on mount
  React.useEffect(() => {
    (async () => {
      const wrongAnswers = await getWrongAnswers();
      const now = Date.now();
      const filtered = wrongAnswers.filter(
        (w) =>
          (!filter || filter === "오답_전체" || w.subject === filter) &&
          (!dueOnly || isDueForReview(w, now))
      );

      const qMap = new Map<string, Question>(questions.map((q) => [q.id, q]));
      const qs = filtered
        .map((w) => qMap.get(w.questionId))
        .filter((q): q is Question => q !== undefined);

      const shuffled = shuffle(qs);
      setSessionQuestions(shuffled);
      setAnswers(Array(shuffled.length).fill(null));
      setLoaded(true);
    })();
  }, [filter, dueOnly]);

  const currentQ = sessionQuestions[currentIndex];
  const isAnswered = selectedOption !== null;
  const isCorrect = selectedOption === currentQ?.answer;
  const correctCount = answers.filter(
    (a, i) => a !== null && a === sessionQuestions[i]?.answer
  ).length;

  const handleSelect = useCallback(
    async (optionIndex: number) => {
      if (isAnswered || !currentQ) return;
      setSelectedOption(optionIndex);

      const correct = optionIndex === currentQ.answer;
      if (Platform.OS !== "web") {
        if (correct) {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        } else {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        }
      }

      setAnswers((prev) => {
        const next = [...prev];
        next[currentIndex] = optionIndex;
        return next;
      });

      try {
        const result = await submitAnswer(currentQ.id, optionIndex);
        setOutcome(result);
        if (result.reviewStatus === "graduated") setGraduatedCount((n) => n + 1);
      } catch (error) {
        console.warn("[WrongSession] Failed to save answer:", error);
      }
    },
    [isAnswered, currentIndex, currentQ]
  );

  const handleNext = useCallback(() => {
    if (currentIndex + 1 >= sessionQuestions.length) {
      setPhase("result");
      return;
    }
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0, duration: 120, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 180, useNativeDriver: true }),
    ]).start();
    setCurrentIndex((prev) => prev + 1);
    setSelectedOption(null);
    setShowExplanation(false);
    setOutcome(null);
  }, [currentIndex, sessionQuestions.length, fadeAnim]);

  if (!loaded) {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <View style={styles.center}>
          <Text style={[styles.loadingText, { color: colors.muted }]}>불러오는 중...</Text>
        </View>
      </ScreenContainer>
    );
  }

  if (sessionQuestions.length === 0) {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <View style={styles.center}>
          <IconSymbol name="checkmark.circle.fill" size={56} color={colors.success} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            {dueOnly ? "오늘 복습할 문제가 없어요!" : "오답이 없습니다!"}
          </Text>
          <Text style={[styles.emptyDesc, { color: colors.muted }]}>
            {dueOnly ? "복습일이 되면 다시 알려드릴게요" : "모든 문제를 맞혔습니다"}
          </Text>
          <Pressable
            style={({ pressed }) => [
              styles.backBtn2,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85 },
            ]}
            onPress={() => router.back()}
          >
            <Text style={styles.backBtn2Text}>돌아가기</Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  if (phase === "result") {
    const rate = Math.round((correctCount / sessionQuestions.length) * 100);
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <ScrollView
          contentContainerStyle={styles.resultContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.resultIconWrap}>
            <IconSymbol
              name={rate >= 60 ? "trophy.fill" : "arrow.clockwise"}
              size={56}
              color={rate >= 60 ? colors.warning : colors.primary}
            />
          </View>
          <Text style={[styles.resultTitle, { color: colors.foreground }]}>
            {rate >= 80 ? "훌륭해요! 🎉" : rate >= 60 ? "잘 하고 있어요!" : "다시 복습해요!"}
          </Text>
          <Text style={[styles.resultSubject, { color: colors.muted }]}>
            {dueOnly ? "오늘의 복습 완료" : "오답 재풀기 완료"}
          </Text>
          <View style={[styles.resultScoreCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.resultRate, { color: rate >= 60 ? colors.success : colors.primary }]}>
              {rate}%
            </Text>
            <Text style={[styles.resultScore, { color: colors.muted }]}>
              {sessionQuestions.length}문제 중 {correctCount}문제 정답
            </Text>
            {graduatedCount > 0 && (
              <Text style={[styles.resultGraduated, { color: colors.success }]}>
                🎓 {graduatedCount}문제가 오답노트에서 졸업했어요
              </Text>
            )}
          </View>
          <View style={styles.resultBtns}>
            <Pressable
              style={({ pressed }) => [
                styles.resultBtn,
                { borderColor: colors.primary, borderWidth: 1.5 },
                pressed && { opacity: 0.75 },
              ]}
              onPress={() => router.replace("/(tabs)/wrong")}
            >
              <Text style={[styles.resultBtnText, { color: colors.primary }]}>오답 노트</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [
                styles.resultBtn,
                { backgroundColor: colors.primary },
                pressed && { opacity: 0.85 },
              ]}
              onPress={() => router.replace("/")}
            >
              <Text style={[styles.resultBtnText, { color: "#FFFFFF" }]}>홈으로</Text>
            </Pressable>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  const progress = (currentIndex + (isAnswered ? 1 : 0)) / sessionQuestions.length;

  return (
    <ScreenContainer {...swipeBackHandlers}>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <Pressable
          style={({ pressed }) => [styles.backBtnTop, pressed && { opacity: 0.6 }]}
          onPress={() => router.back()}
        >
          <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
        </Pressable>
        <View style={styles.topCenter}>
          <Text style={[styles.topSubject, { color: colors.error }]}>
            {dueOnly ? "오늘의 복습" : "오답 재풀기"}
          </Text>
          <Text style={[styles.topProgress, { color: colors.muted }]}>
            {currentIndex + 1} / {sessionQuestions.length}
          </Text>
        </View>
        <BookmarkButton
          bookmarked={bookmarks.isBookmarked(currentQ.id)}
          onPress={() => bookmarks.toggle(currentQ.id)}
        />
      </View>

      {/* Progress Bar */}
      <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
        <View
          style={[
            styles.progressFill,
            { backgroundColor: colors.error, width: `${progress * 100}%` },
          ]}
        />
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          {/* Subject Badge */}
          <View style={styles.subjectBadgeRow}>
            <View
              style={[
                styles.subjectBadge,
                { backgroundColor: SUBJECT_COLORS[currentQ.subject] + "18" },
              ]}
            >
              <Text
                style={[
                  styles.subjectBadgeText,
                  { color: SUBJECT_COLORS[currentQ.subject] },
                ]}
              >
                {currentQ.subject}
              </Text>
            </View>
          </View>

          {/* Question */}
          <View
            style={[
              styles.questionCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
          >
            <Text style={[styles.questionText, { color: colors.foreground }]}>
              {currentQ.question}
            </Text>
          </View>

          {/* Options */}
          <View style={styles.optionsContainer}>
            {currentQ.options.map((option, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrectOption = idx === currentQ.answer;
              let bgColor = colors.surface;
              let borderColor = colors.border;
              let textColor = colors.foreground;

              if (isAnswered) {
                if (isCorrectOption) {
                  bgColor = colors.success + "18";
                  borderColor = colors.success;
                  textColor = colors.success;
                } else if (isSelected && !isCorrectOption) {
                  bgColor = colors.error + "18";
                  borderColor = colors.error;
                  textColor = colors.error;
                }
              }

              return (
                <Pressable
                  key={idx}
                  style={({ pressed }) => [
                    styles.optionBtn,
                    { backgroundColor: bgColor, borderColor },
                    pressed && !isAnswered && { opacity: 0.75 },
                  ]}
                  onPress={() => handleSelect(idx)}
                  disabled={isAnswered}
                >
                  <View style={[styles.optionLabel, { backgroundColor: borderColor + "30" }]}>
                    <Text style={[styles.optionLabelText, { color: textColor }]}>
                      {["①", "②", "③", "④"][idx]}
                    </Text>
                  </View>
                  <Text style={[styles.optionText, { color: textColor }]} numberOfLines={3}>
                    {option}
                  </Text>
                  {isAnswered && isCorrectOption && (
                    <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                  )}
                  {isAnswered && isSelected && !isCorrectOption && (
                    <IconSymbol name="xmark.circle.fill" size={20} color={colors.error} />
                  )}
                </Pressable>
              );
            })}
          </View>

          {/* Feedback */}
          {isAnswered && (
            <View
              style={[
                styles.feedbackCard,
                {
                  backgroundColor: isCorrect ? colors.success + "12" : colors.error + "12",
                  borderColor: isCorrect ? colors.success + "40" : colors.error + "40",
                },
              ]}
            >
              <View style={styles.feedbackHeader}>
                <IconSymbol
                  name={isCorrect ? "checkmark.circle.fill" : "xmark.circle.fill"}
                  size={22}
                  color={isCorrect ? colors.success : colors.error}
                />
                <Text style={[styles.feedbackTitle, { color: isCorrect ? colors.success : colors.error }]}>
                  {isCorrect ? "정답입니다!" : "오답입니다"}
                </Text>
                <Pressable
                  style={({ pressed }) => [
                    styles.explanationToggle,
                    { borderColor: isCorrect ? colors.success : colors.error },
                    pressed && { opacity: 0.7 },
                  ]}
                  onPress={() => setShowExplanation((v) => !v)}
                >
                  <Text style={[styles.explanationToggleText, { color: isCorrect ? colors.success : colors.error }]}>
                    {showExplanation ? "해설 닫기" : "해설 보기"}
                  </Text>
                </Pressable>
              </View>
              {outcome && reviewMessage(outcome) && (
                <Text style={[styles.reviewMessage, { color: colors.muted }]}>
                  {reviewMessage(outcome)}
                </Text>
              )}
              {showExplanation && (
                <Text style={[styles.explanationText, { color: colors.foreground }]}>
                  {currentQ.explanation}
                </Text>
              )}
              {selectedOption !== null && (
                <DonguraeExplainButton
                  key={currentQ.id}
                  question={currentQ}
                  selectedOption={selectedOption}
                />
              )}
            </View>
          )}

          {isAnswered && (
            <Pressable
              style={({ pressed }) => [
                styles.nextBtn,
                { backgroundColor: colors.error },
                pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
              ]}
              onPress={handleNext}
            >
              <Text style={styles.nextBtnText}>
                {currentIndex + 1 >= sessionQuestions.length ? "결과 보기" : "다음 문제"}
              </Text>
              <IconSymbol
                name={currentIndex + 1 >= sessionQuestions.length ? "trophy.fill" : "arrow.right"}
                size={18}
                color="#FFFFFF"
              />
            </Pressable>
          )}
        </Animated.View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
    padding: 24,
  },
  loadingText: { fontSize: 16 },
  emptyTitle: { fontSize: 22, fontWeight: "700" },
  emptyDesc: { fontSize: 14, textAlign: "center" },
  backBtn2: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: 8,
  },
  backBtn2Text: { color: "#FFFFFF", fontWeight: "700", fontSize: 15 },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  backBtnTop: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  topCenter: { flex: 1, alignItems: "center" },
  topSubject: { fontSize: 14, fontWeight: "700" },
  topProgress: { fontSize: 12, marginTop: 1 },
  progressBg: { height: 4 },
  progressFill: { height: 4, borderRadius: 2 },
  scrollContent: { padding: 20, paddingBottom: 40 },
  subjectBadgeRow: { marginBottom: 12 },
  subjectBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, alignSelf: "flex-start" },
  subjectBadgeText: { fontSize: 12, fontWeight: "700" },
  questionCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    marginBottom: 16,
  },
  questionText: { fontSize: 16, fontWeight: "600", lineHeight: 26 },
  optionsContainer: { gap: 10, marginBottom: 16 },
  optionBtn: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1.5,
    padding: 14,
    gap: 12,
  },
  optionLabel: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  optionLabelText: { fontSize: 14, fontWeight: "700" },
  optionText: { flex: 1, fontSize: 14, lineHeight: 22, fontWeight: "500" },
  feedbackCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 16,
    gap: 10,
  },
  feedbackHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  feedbackTitle: { fontSize: 15, fontWeight: "700", flex: 1 },
  explanationToggle: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
  },
  explanationToggleText: { fontSize: 12, fontWeight: "600" },
  explanationText: { fontSize: 13, lineHeight: 22 },
  reviewMessage: { fontSize: 12, fontWeight: "600", lineHeight: 18 },
  nextBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 14,
    paddingVertical: 16,
    marginTop: 4,
  },
  nextBtnText: { fontSize: 16, fontWeight: "700", color: "#FFFFFF" },
  // Result
  resultContent: { padding: 24, alignItems: "center", paddingBottom: 48 },
  resultIconWrap: { marginTop: 32, marginBottom: 16 },
  resultTitle: { fontSize: 26, fontWeight: "800", letterSpacing: -0.5, marginBottom: 4 },
  resultSubject: { fontSize: 14, marginBottom: 28 },
  resultScoreCard: {
    width: "100%",
    borderRadius: 18,
    borderWidth: 1,
    padding: 24,
    alignItems: "center",
    gap: 8,
    marginBottom: 32,
  },
  resultRate: { fontSize: 52, fontWeight: "900", letterSpacing: -2 },
  resultScore: { fontSize: 15 },
  resultGraduated: { fontSize: 14, fontWeight: "700", marginTop: 4 },
  resultBtns: { flexDirection: "row", gap: 12, width: "100%" },
  resultBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 15,
    borderRadius: 14,
  },
  resultBtnText: { fontSize: 15, fontWeight: "700" },
});
