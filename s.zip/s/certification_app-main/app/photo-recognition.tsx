import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import { Image } from "expo-image";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { DmuExplanationPlayer as DongguraeExplanationPlayer } from "@/components/dmu-explanation-player";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import {
  pickImageFromGallery,
  takeCameraPhoto,
  requestCameraPermission,
  imageToBase64,
} from "@/lib/camera-utils";
import { type ExplanationResult } from "@/lib/ai-service";
import { trpc } from "@/lib/trpc";

type Phase = "initial" | "loading" | "result" | "video";

const EXPLANATION_TARGET_DURATION = 30;

export default function PhotoRecognitionScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();
  const recognizeQuestionMutation = trpc.vision.recognizeQuestion.useMutation();

  const [phase, setPhase] = useState<Phase>("initial");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [recognizedText, setRecognizedText] = useState<string>("");
  const [explanationResult, setExplanationResult] = useState<ExplanationResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleTakePhoto = useCallback(async () => {
    const hasPermission = await requestCameraPermission();
    if (!hasPermission) {
      Alert.alert("권한 필요", "카메라 접근 권한이 필요합니다");
      return;
    }

    const photo = await takeCameraPhoto();
    if (photo) {
      await processImage(photo.uri, photo.base64);
    }
  }, []);

  const handlePickImage = useCallback(async () => {
    const image = await pickImageFromGallery();
    if (image) {
      await processImage(image.uri, image.base64);
    }
  }, []);

  const processImage = useCallback(async (imageUri: string, base64FromPicker?: string) => {
    try {
      setSelectedImage(imageUri);
      setPhase("loading");
      setLoading(true);

      // 카메라/갤러리 피커가 이미 base64를 넘겨주면 그대로 쓰고, 없을 때만
      // expo-file-system으로 변환한다. expo-file-system의 readAsStringAsync는
      // 웹에서 지원되지 않아서, 피커의 base64를 그냥 버리고 여기로만 넘기면
      // 웹에서는 항상 "이미지 변환 실패"가 난다.
      const base64 = base64FromPicker ?? (await imageToBase64(imageUri));
      if (!base64) {
        throw new Error("이미지 변환 실패");
      }

      // 문제 인식 + 해설 생성을 한 번의 서버 호출(vision.recognizeQuestion)로
      // 같이 받아온다 (Gemini 무료 쿼터를 아끼기 위해 두 번 호출하던 걸 합침).
      const ocrResult = await recognizeQuestionMutation.mutateAsync({
        base64Image: base64,
      });
      if (!ocrResult || !ocrResult.text || !ocrResult.explanation) {
        throw new Error("문제 인식 실패");
      }

      setRecognizedText(ocrResult.text);

      const result: ExplanationResult = {
        question: ocrResult.text,
        answer: "",
        explanation: ocrResult.explanation,
        duration: EXPLANATION_TARGET_DURATION,
      };

      setExplanationResult(result);
      setPhase("result");

      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      console.error("Error processing image:", error);
      Alert.alert("오류", "이미지 처리 중 오류가 발생했습니다");
      setPhase("initial");
    } finally {
      setLoading(false);
    }
  }, []);

  const handlePlayVideo = useCallback(() => {
    setPhase("video");
  }, []);

  // === 초기 화면 ===
  if (phase === "initial") {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.header}>
            <Pressable
              style={({ pressed }) => [pressed && { opacity: 0.6 }]}
              onPress={() => router.back()}
            >
              <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
            </Pressable>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>
              사진으로 풀기
            </Text>
            <View style={{ width: 22 }} />
          </View>

          <View style={styles.content}>
            <View style={styles.iconWrap}>
              <IconSymbol name="camera.fill" size={56} color={colors.primary} />
            </View>
            <Text style={[styles.title, { color: colors.foreground }]}>
              문제 사진을 촬영하세요
            </Text>
            <Text style={[styles.subtitle, { color: colors.muted }]}>
              카메라로 촬영하거나 갤러리에서 선택하면{"\n"}AI가 문제를 인식하고 해설을 생성합니다
            </Text>

            <View style={styles.buttonGroup}>
              <Pressable
                style={({ pressed }) => [
                  styles.btn,
                  { backgroundColor: colors.primary },
                  pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                ]}
                onPress={handleTakePhoto}
              >
                <IconSymbol name="camera.fill" size={20} color="#FFFFFF" />
                <Text style={styles.btnText}>카메라로 촬영</Text>
              </Pressable>

              <Pressable
                style={({ pressed }) => [
                  styles.btn,
                  { backgroundColor: colors.surface, borderColor: colors.primary, borderWidth: 1.5 },
                  pressed && { opacity: 0.75 },
                ]}
                onPress={handlePickImage}
              >
                <IconSymbol name="photo.fill" size={20} color={colors.primary} />
                <Text style={[styles.btnText, { color: colors.primary }]}>갤러리에서 선택</Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // === 로딩 화면 ===
  if (phase === "loading") {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.foreground }]}>
            문제를 인식하고 해설을 생성 중입니다...
          </Text>
          <Text style={[styles.loadingSubtext, { color: colors.muted }]}>
            잠시만 기다려주세요
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  // === 동그래 해설 재생 화면 ===
  if (phase === "video" && explanationResult) {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <DongguraeExplanationPlayer
          explanation={explanationResult.explanation}
          onClose={() => setPhase("result")}
        />
      </ScreenContainer>
    );
  }

  // === 결과 화면 ===
  return (
    <ScreenContainer {...swipeBackHandlers}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Pressable
            style={({ pressed }) => [pressed && { opacity: 0.6 }]}
            onPress={() => setPhase("initial")}
          >
            <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
          </Pressable>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            인식 결과
          </Text>
          <View style={{ width: 22 }} />
        </View>

        {selectedImage && (
          <View style={[styles.imagePreview, { borderColor: colors.border }]}>
            <Image
              source={{ uri: selectedImage }}
              style={styles.previewImage}
              contentFit="cover"
            />
          </View>
        )}

        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.cardTitle, { color: colors.foreground }]}>
            인식된 문제
          </Text>
          <Text style={[styles.cardText, { color: colors.foreground }]}>
            {recognizedText || "문제를 인식하지 못했습니다"}
          </Text>
        </View>

        {explanationResult && (
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>
              AI 해설
            </Text>
            <Text style={[styles.cardText, { color: colors.foreground }]}>
              {explanationResult.explanation}
            </Text>
          </View>
        )}

        {/* 동그래 해설 동영상 버튼 */}
        {explanationResult && (
          <Pressable
            style={({ pressed }) => [
              styles.videoBtn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
            onPress={handlePlayVideo}
          >
            <IconSymbol name="play.fill" size={20} color="#FFFFFF" />
            <Text style={styles.videoBtnText}>동그래 해설 보기</Text>
          </Pressable>
        )}

        <View style={styles.buttonGroup}>
          <Pressable
            style={({ pressed }) => [
              styles.btn,
              { backgroundColor: colors.surface, borderColor: colors.primary, borderWidth: 1.5 },
              pressed && { opacity: 0.75 },
            ]}
            onPress={() => setPhase("initial")}
          >
            <IconSymbol name="arrow.clockwise" size={20} color={colors.primary} />
            <Text style={[styles.btnText, { color: colors.primary }]}>다시 촬영</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.btn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
            onPress={() => router.back()}
          >
            <IconSymbol name="checkmark" size={20} color="#FFFFFF" />
            <Text style={styles.btnText}>완료</Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    padding: 20,
    paddingBottom: 32,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  content: {
    alignItems: "center",
    gap: 16,
    paddingVertical: 40,
  },
  iconWrap: {
    marginBottom: 8,
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 22,
  },
  buttonGroup: {
    width: "100%",
    gap: 12,
    marginTop: 24,
  },
  btn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 14,
    paddingVertical: 14,
  },
  btnText: {
    fontSize: 15,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
  },
  loadingText: {
    fontSize: 16,
    fontWeight: "600",
  },
  loadingSubtext: {
    fontSize: 13,
  },
  imagePreview: {
    width: "100%",
    height: 200,
    borderRadius: 14,
    borderWidth: 1,
    overflow: "hidden",
    marginBottom: 16,
  },
  previewImage: {
    width: "100%",
    height: "100%",
  },
  card: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: "700",
    marginBottom: 8,
  },
  cardText: {
    fontSize: 14,
    lineHeight: 22,
  },
  videoBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 14,
    paddingVertical: 14,
    marginBottom: 16,
  },
  videoBtnText: {
    fontSize: 15,
    fontWeight: "700",
    color: "#FFFFFF",
  },
});
