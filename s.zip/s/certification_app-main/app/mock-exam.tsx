import React, { useState, useCallback, useRef, useEffect } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Alert,
  Platform,
} from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { BookmarkButton } from "@/components/bookmark-button";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { useBookmarks } from "@/hooks/use-bookmarks";
import {
  getMockExamQuestions,
  MOCK_EXAM_COUNTS,
  Question,
  SUBJECTS,
  SUBJECT_COLORS,
} from "@/data/questions";
import { scoreMockExam, subjectPassed } from "@/lib/mock-exam-scoring";
import { getMockExamResults, submitMockExam, MockExamRecord } from "@/lib/storage";

const EXAM_DURATION_SECONDS = 90 * 60; // 실제 ADsP 시험과 동일하게 90분
const TOTAL_QUESTIONS = SUBJECTS.reduce((sum, s) => sum + MOCK_EXAM_COUNTS[s], 0);

type Phase = "intro" | "exam" | "result" | "review";

function formatTime(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function MockExamScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();

  const [phase, setPhase] = useState<Phase>("intro");
  const [examQuestions, setExamQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [showExplanation, setShowExplanation] = useState(false);
  const [timeLeft, setTimeLeft] = useState(EXAM_DURATION_SECONDS);
  const [submitting, setSubmitting] = useState(false);
  const [history, setHistory] = useState<MockExamRecord[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startedAtRef = useRef(0);
  const bookmarks = useBookmarks();

  useEffect(() => {
    getMockExamResults(5).then(setHistory).catch(() => {});
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const submitExam = useCallback(async () => {
    stopTimer();
    setSubmitting(true);
    try {
      const durationSeconds = Math.min(
        EXAM_DURATION_SECONDS,
        Math.round((Date.now() - startedAtRef.current) / 1000)
      );
      await submitMockExam(
        examQuestions.map((q, i) => ({ questionId: q.id, selectedOption: answers[i] })),
        durationSeconds
      );
    } catch (error) {
      console.warn("[MockExam] Failed to save result:", error);
    } finally {
      setSubmitting(false);
      setPhase("result");
    }
  }, [examQuestions, answers, stopTimer]);

  useEffect(() => {
    if (phase !== "exam") return;
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          timerRef.current = null;
          submitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => stopTimer();
  }, [phase, submitExam, stopTimer]);

  const handleStart = useCallback(() => {
    const qs = getMockExamQuestions();
    setExamQuestions(qs);
    setAnswers(Array(qs.length).fill(null));
    setCurrentIndex(0);
    setTimeLeft(EXAM_DURATION_SECONDS);
    startedAtRef.current = Date.now();
    setPhase("exam");
  }, []);

  const handleSelect = useCallback(
    (optionIndex: number) => {
      if (Platform.OS !== "web") {
        Haptics.selectionAsync();
      }
      setAnswers((prev) => {
        const next = [...prev];
        next[currentIndex] = optionIndex;
        return next;
      });
    },
    [currentIndex]
  );

  const handleSubmitPress = useCallback(() => {
    const unansweredCount = answers.filter((a) => a === null).length;
    Alert.alert(
      "답안을 제출할까요?",
      unansweredCount > 0
        ? `아직 풀지 않은 문제가 ${unansweredCount}개 있습니다. 그래도 제출하시겠어요?`
        : "모든 문제를 다 풀었습니다. 제출하시겠어요?",
      [
        { text: "취소", style: "cancel" },
        { text: "제출", style: "destructive", onPress: submitExam },
      ]
    );
  }, [answers, submitExam]);

  const handleExit = useCallback(() => {
    Alert.alert("모의고사를 종료할까요?", "지금까지 푼 내용은 저장되지 않습니다.", [
      { text: "취소", style: "cancel" },
      { text: "종료", style: "destructive", onPress: () => router.back() },
    ]);
  }, [router]);

  // ─── Intro ──────────────────────────────────────────────────────────────
  if (phase === "intro") {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <View style={styles.topBar}>
          <Pressable
            style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
            onPress={() => router.back()}
          >
            <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
          </Pressable>
        </View>
        <ScrollView contentContainerStyle={styles.introContent} showsVerticalScrollIndicator={false}>
          <View style={[styles.introIconWrap, { backgroundColor: colors.primary + "18" }]}>
            <IconSymbol name="clock.fill" size={40} color={colors.primary} />
          </View>
          <Text style={[styles.introTitle, { color: colors.foreground }]}>실전 모의고사</Text>
          <Text style={[styles.introDesc, { color: colors.muted }]}>
            실제 ADsP 시험과 동일한 구성으로 응시합니다
          </Text>

          <View style={[styles.introCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {SUBJECTS.map((subject) => (
              <View key={subject} style={styles.introRow}>
                <View style={styles.introRowLeft}>
                  <View style={[styles.subjectDot, { backgroundColor: SUBJECT_COLORS[subject] }]} />
                  <Text style={[styles.introRowLabel, { color: colors.foreground }]}>{subject}</Text>
                </View>
                <Text style={[styles.introRowValue, { color: colors.muted }]}>
                  {MOCK_EXAM_COUNTS[subject]}문항
                </Text>
              </View>
            ))}
            <View style={[styles.introDivider, { backgroundColor: colors.border }]} />
            <View style={styles.introRow}>
              <Text style={[styles.introRowLabel, { color: colors.foreground, fontWeight: "700" }]}>
                총 문항수
              </Text>
              <Text style={[styles.introRowValue, { color: colors.foreground, fontWeight: "700" }]}>
                {TOTAL_QUESTIONS}문항
              </Text>
            </View>
            <View style={styles.introRow}>
              <Text style={[styles.introRowLabel, { color: colors.foreground, fontWeight: "700" }]}>
                제한 시간
              </Text>
              <Text style={[styles.introRowValue, { color: colors.foreground, fontWeight: "700" }]}>
                90분
              </Text>
            </View>
          </View>

          <View style={[styles.introNote, { backgroundColor: colors.primary + "10", borderColor: colors.primary + "30" }]}>
            <IconSymbol name="info.circle" size={16} color={colors.primary} />
            <Text style={[styles.introNoteText, { color: colors.primary }]}>
              문제는 매번 전체 문제은행에서 무작위로 출제됩니다. 합격 기준은 과목별 40% 이상 + 전체
              60% 이상입니다.
            </Text>
          </View>

          {history.length > 0 && (
            <View style={[styles.introCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.introRowLabel, { color: colors.foreground, fontWeight: "700" }]}>
                최근 응시 기록
              </Text>
              {history.map((h) => (
                <View key={h.id} style={styles.introRow}>
                  <Text style={[styles.introRowLabel, { color: colors.muted }]}>
                    {new Date(h.takenAt).toLocaleDateString("ko-KR", { month: "numeric", day: "numeric" })}
                  </Text>
                  <View style={styles.subjectResultRight}>
                    <Text style={[styles.introRowValue, { color: colors.foreground }]}>
                      {Math.round((h.correct / h.total) * 100)}점
                    </Text>
                    <Text
                      style={[styles.introRowValue, { color: h.passed ? colors.success : colors.error }]}
                    >
                      {h.passed ? "합격" : "불합격"}
                    </Text>
                  </View>
                </View>
              ))}
            </View>
          )}

          <Pressable
            style={({ pressed }) => [
              styles.startBtn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
            onPress={handleStart}
          >
            <IconSymbol name="play.fill" size={18} color="#FFFFFF" />
            <Text style={styles.startBtnText}>모의고사 시작하기</Text>
          </Pressable>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // ─── Result ─────────────────────────────────────────────────────────────
  if (phase === "result" || phase === "review") {
    const score = scoreMockExam(
      examQuestions.map((q, i) => ({ question: q, selected: answers[i] }))
    );
    const bySubject = SUBJECTS.map((subject) => {
      const s = score.bySubject[subject];
      const rate = s.total > 0 ? s.correct / s.total : 0;
      return { subject, ...s, rate, passed: subjectPassed(s) };
    });
    const totalCorrect = score.correct;
    const overallRate = score.total > 0 ? score.correct / score.total : 0;
    const overallPassed = score.passed;

    if (phase === "review") {
      const q = examQuestions[currentIndex];
      const selected = answers[currentIndex];
      const isCorrect = selected === q.answer;
      return (
        <ScreenContainer {...swipeBackHandlers}>
          <View style={styles.topBar}>
            <Pressable
              style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
              onPress={() => setPhase("result")}
            >
              <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
            </Pressable>
            <View style={styles.topCenter}>
              <Text style={[styles.topSubject, { color: colors.primary }]}>전체 리뷰</Text>
              <Text style={[styles.topProgress, { color: colors.muted }]}>
                {currentIndex + 1} / {examQuestions.length}
              </Text>
            </View>
            <BookmarkButton
              bookmarked={bookmarks.isBookmarked(q.id)}
              onPress={() => bookmarks.toggle(q.id)}
            />
          </View>
          <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
            <View style={styles.subjectBadgeRow}>
              <View style={[styles.subjectBadge, { backgroundColor: SUBJECT_COLORS[q.subject] + "18" }]}>
                <Text style={[styles.subjectBadgeText, { color: SUBJECT_COLORS[q.subject] }]}>
                  {q.subject}
                </Text>
              </View>
            </View>
            <View style={[styles.questionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.questionText, { color: colors.foreground }]}>{q.question}</Text>
            </View>
            <View style={styles.optionsContainer}>
              {q.options.map((option, idx) => {
                const isSelected = selected === idx;
                const isCorrectOption = idx === q.answer;
                let bgColor = colors.surface;
                let borderColor = colors.border;
                let textColor = colors.foreground;
                if (isCorrectOption) {
                  bgColor = colors.success + "18";
                  borderColor = colors.success;
                  textColor = colors.success;
                } else if (isSelected && !isCorrectOption) {
                  bgColor = colors.error + "18";
                  borderColor = colors.error;
                  textColor = colors.error;
                }
                return (
                  <View
                    key={idx}
                    style={[styles.optionBtn, { backgroundColor: bgColor, borderColor }]}
                  >
                    <View style={[styles.optionLabel, { backgroundColor: borderColor + "30" }]}>
                      <Text style={[styles.optionLabelText, { color: textColor }]}>
                        {["①", "②", "③", "④"][idx]}
                      </Text>
                    </View>
                    <Text style={[styles.optionText, { color: textColor }]} numberOfLines={3}>
                      {option}
                    </Text>
                    {isCorrectOption && (
                      <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                    )}
                    {isSelected && !isCorrectOption && (
                      <IconSymbol name="xmark.circle.fill" size={20} color={colors.error} />
                    )}
                  </View>
                );
              })}
            </View>
            {selected === null && (
              <Text style={[styles.unansweredNote, { color: colors.muted }]}>
                이 문제는 풀지 않고 제출했습니다.
              </Text>
            )}
            <View
              style={[
                styles.feedbackCard,
                {
                  backgroundColor: isCorrect ? colors.success + "12" : colors.error + "12",
                  borderColor: isCorrect ? colors.success + "40" : colors.error + "40",
                },
              ]}
            >
              <View style={styles.feedbackHeader}>
                <IconSymbol
                  name={isCorrect ? "checkmark.circle.fill" : "xmark.circle.fill"}
                  size={22}
                  color={isCorrect ? colors.success : colors.error}
                />
                <Text style={[styles.feedbackTitle, { color: isCorrect ? colors.success : colors.error }]}>
                  {isCorrect ? "정답입니다!" : "오답입니다"}
                </Text>
              </View>
              <Text style={[styles.explanationText, { color: colors.foreground }]}>
                {q.explanation}
              </Text>
            </View>
            <View style={styles.reviewNavRow}>
              <Pressable
                style={({ pressed }) => [
                  styles.navBtn,
                  { borderColor: colors.border },
                  pressed && { opacity: 0.7 },
                  currentIndex === 0 && styles.navBtnDisabled,
                ]}
                disabled={currentIndex === 0}
                onPress={() => setCurrentIndex((i) => Math.max(0, i - 1))}
              >
                <IconSymbol name="arrow.left" size={16} color={colors.foreground} />
                <Text style={[styles.navBtnText, { color: colors.foreground }]}>이전</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [
                  styles.navBtn,
                  { borderColor: colors.border },
                  pressed && { opacity: 0.7 },
                  currentIndex === examQuestions.length - 1 && styles.navBtnDisabled,
                ]}
                disabled={currentIndex === examQuestions.length - 1}
                onPress={() => setCurrentIndex((i) => Math.min(examQuestions.length - 1, i + 1))}
              >
                <Text style={[styles.navBtnText, { color: colors.foreground }]}>다음</Text>
                <IconSymbol name="arrow.right" size={16} color={colors.foreground} />
              </Pressable>
            </View>
          </ScrollView>
        </ScreenContainer>
      );
    }

    return (
      <ScreenContainer {...swipeBackHandlers}>
        <ScrollView contentContainerStyle={styles.resultContent} showsVerticalScrollIndicator={false}>
          <View style={styles.resultIconWrap}>
            <IconSymbol
              name={overallPassed ? "trophy.fill" : "arrow.clockwise"}
              size={56}
              color={overallPassed ? colors.warning : colors.primary}
            />
          </View>
          <Text style={[styles.resultTitle, { color: colors.foreground }]}>
            {overallPassed ? "합격 기준 달성! 🎉" : "조금 더 준비해요!"}
          </Text>
          <Text style={[styles.resultSubject, { color: colors.muted }]}>실전 모의고사 결과</Text>

          <View style={[styles.resultScoreCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.resultRate, { color: overallPassed ? colors.success : colors.primary }]}>
              {Math.round(overallRate * 100)}%
            </Text>
            <Text style={[styles.resultScore, { color: colors.muted }]}>
              {TOTAL_QUESTIONS}문제 중 {totalCorrect}문제 정답
            </Text>
          </View>

          <View style={[styles.subjectResultCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {bySubject.map((s, idx) => (
              <View key={s.subject}>
                {idx > 0 && <View style={[styles.introDivider, { backgroundColor: colors.border }]} />}
                <View style={styles.subjectResultRow}>
                  <View style={styles.introRowLeft}>
                    <View style={[styles.subjectDot, { backgroundColor: SUBJECT_COLORS[s.subject] }]} />
                    <Text style={[styles.introRowLabel, { color: colors.foreground }]}>{s.subject}</Text>
                  </View>
                  <View style={styles.subjectResultRight}>
                    <Text style={[styles.introRowValue, { color: colors.muted }]}>
                      {s.correct}/{s.total} · {Math.round(s.rate * 100)}%
                    </Text>
                    <IconSymbol
                      name={s.passed ? "checkmark.circle.fill" : "xmark.circle.fill"}
                      size={16}
                      color={s.passed ? colors.success : colors.error}
                    />
                  </View>
                </View>
              </View>
            ))}
          </View>

          <View style={styles.resultBtns}>
            <Pressable
              style={({ pressed }) => [
                styles.resultBtn,
                styles.resultBtnOutline,
                { borderColor: colors.primary },
                pressed && { opacity: 0.75 },
              ]}
              onPress={() => {
                setCurrentIndex(0);
                setPhase("review");
              }}
            >
              <IconSymbol name="list.bullet" size={18} color={colors.primary} />
              <Text style={[styles.resultBtnText, { color: colors.primary }]}>전체 리뷰</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [
                styles.resultBtn,
                { backgroundColor: colors.primary },
                pressed && { opacity: 0.85 },
              ]}
              onPress={() => router.replace("/")}
            >
              <IconSymbol name="house.fill" size={18} color="#FFFFFF" />
              <Text style={[styles.resultBtnText, { color: "#FFFFFF" }]}>홈으로</Text>
            </Pressable>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // ─── Exam ───────────────────────────────────────────────────────────────
  const currentQ = examQuestions[currentIndex];
  const answeredCount = answers.filter((a) => a !== null).length;
  const isLowTime = timeLeft <= 5 * 60;

  return (
    <ScreenContainer {...swipeBackHandlers}>
      <View style={styles.topBar}>
        <Pressable style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]} onPress={handleExit}>
          <IconSymbol name="xmark" size={22} color={colors.foreground} />
        </Pressable>
        <View style={styles.topCenter}>
          <Text style={[styles.topProgress, { color: colors.muted }]}>
            {answeredCount} / {examQuestions.length}문제 풀이
          </Text>
        </View>
        <View style={[styles.timerBadge, { backgroundColor: (isLowTime ? colors.error : colors.primary) + "18" }]}>
          <IconSymbol name="clock.fill" size={14} color={isLowTime ? colors.error : colors.primary} />
          <Text style={[styles.timerText, { color: isLowTime ? colors.error : colors.primary }]}>
            {formatTime(timeLeft)}
          </Text>
        </View>
      </View>

      {/* Question Navigator */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.navigatorScroll}
        contentContainerStyle={styles.navigatorContent}
      >
        {examQuestions.map((q, idx) => {
          const isAnswered = answers[idx] !== null;
          const isCurrent = idx === currentIndex;
          return (
            <Pressable
              key={q.id}
              style={[
                styles.navChip,
                { borderColor: SUBJECT_COLORS[q.subject] },
                isAnswered && { backgroundColor: SUBJECT_COLORS[q.subject] },
                isCurrent && styles.navChipCurrent,
                isCurrent && { borderColor: colors.foreground },
              ]}
              onPress={() => setCurrentIndex(idx)}
            >
              <Text
                style={[
                  styles.navChipText,
                  { color: isAnswered ? "#FFFFFF" : SUBJECT_COLORS[q.subject] },
                ]}
              >
                {idx + 1}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.subjectBadgeRow}>
          <View style={[styles.subjectBadge, { backgroundColor: SUBJECT_COLORS[currentQ.subject] + "18" }]}>
            <Text style={[styles.subjectBadgeText, { color: SUBJECT_COLORS[currentQ.subject] }]}>
              {currentQ.subject}
            </Text>
          </View>
        </View>

        <View style={[styles.questionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.questionBadge}>
            <Text style={[styles.questionBadgeText, { color: colors.primary }]}>
              Q{currentIndex + 1}
            </Text>
          </View>
          <Text style={[styles.questionText, { color: colors.foreground }]}>{currentQ.question}</Text>
        </View>

        <View style={styles.optionsContainer}>
          {currentQ.options.map((option, idx) => {
            const isSelected = answers[currentIndex] === idx;
            return (
              <Pressable
                key={idx}
                style={({ pressed }) => [
                  styles.optionBtn,
                  {
                    backgroundColor: isSelected ? colors.primary + "18" : colors.surface,
                    borderColor: isSelected ? colors.primary : colors.border,
                  },
                  pressed && { opacity: 0.75 },
                ]}
                onPress={() => handleSelect(idx)}
              >
                <View
                  style={[
                    styles.optionLabel,
                    { backgroundColor: (isSelected ? colors.primary : colors.border) + "30" },
                  ]}
                >
                  <Text style={[styles.optionLabelText, { color: isSelected ? colors.primary : colors.foreground }]}>
                    {["①", "②", "③", "④"][idx]}
                  </Text>
                </View>
                <Text
                  style={[styles.optionText, { color: isSelected ? colors.primary : colors.foreground }]}
                  numberOfLines={3}
                >
                  {option}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <View style={styles.examNavRow}>
          <Pressable
            style={({ pressed }) => [
              styles.navBtn,
              { borderColor: colors.border },
              pressed && { opacity: 0.7 },
              currentIndex === 0 && styles.navBtnDisabled,
            ]}
            disabled={currentIndex === 0}
            onPress={() => setCurrentIndex((i) => Math.max(0, i - 1))}
          >
            <IconSymbol name="arrow.left" size={16} color={colors.foreground} />
            <Text style={[styles.navBtnText, { color: colors.foreground }]}>이전</Text>
          </Pressable>
          {currentIndex === examQuestions.length - 1 ? (
            <Pressable
              style={({ pressed }) => [
                styles.navBtn,
                styles.navBtnPrimary,
                { backgroundColor: colors.primary },
                pressed && { opacity: 0.85 },
              ]}
              disabled={submitting}
              onPress={handleSubmitPress}
            >
              <Text style={[styles.navBtnText, { color: "#FFFFFF" }]}>제출하기</Text>
              <IconSymbol name="flag.checkered" size={16} color="#FFFFFF" />
            </Pressable>
          ) : (
            <Pressable
              style={({ pressed }) => [
                styles.navBtn,
                { borderColor: colors.border },
                pressed && { opacity: 0.7 },
              ]}
              onPress={() => setCurrentIndex((i) => Math.min(examQuestions.length - 1, i + 1))}
            >
              <Text style={[styles.navBtnText, { color: colors.foreground }]}>다음</Text>
              <IconSymbol name="arrow.right" size={16} color={colors.foreground} />
            </Pressable>
          )}
        </View>

        <Pressable
          style={({ pressed }) => [styles.submitAnytimeBtn, pressed && { opacity: 0.7 }]}
          onPress={handleSubmitPress}
          disabled={submitting}
        >
          <Text style={[styles.submitAnytimeText, { color: colors.muted }]}>
            {submitting ? "채점 중..." : "지금 바로 제출하기"}
          </Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  backBtn: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  topCenter: { flex: 1, alignItems: "center" },
  topSubject: { fontSize: 14, fontWeight: "700" },
  topProgress: { fontSize: 12 },
  timerBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
  },
  timerText: { fontSize: 13, fontWeight: "800", fontVariant: ["tabular-nums"] },
  navigatorScroll: { flexGrow: 0, marginBottom: 4 },
  navigatorContent: { paddingHorizontal: 16, gap: 6, paddingVertical: 4 },
  navChip: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
  },
  navChipCurrent: { borderWidth: 2.5 },
  navChipText: { fontSize: 12, fontWeight: "700" },
  scrollContent: { padding: 20, paddingBottom: 40 },
  subjectBadgeRow: { marginBottom: 12 },
  subjectBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, alignSelf: "flex-start" },
  subjectBadgeText: { fontSize: 12, fontWeight: "700" },
  questionCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    marginBottom: 16,
  },
  questionBadge: { marginBottom: 10 },
  questionBadgeText: { fontSize: 13, fontWeight: "700" },
  questionText: { fontSize: 16, fontWeight: "600", lineHeight: 26 },
  optionsContainer: { gap: 10, marginBottom: 16 },
  optionBtn: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1.5,
    padding: 14,
    gap: 12,
  },
  optionLabel: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  optionLabelText: { fontSize: 14, fontWeight: "700" },
  optionText: { flex: 1, fontSize: 14, lineHeight: 22, fontWeight: "500" },
  unansweredNote: { fontSize: 13, marginBottom: 12, fontStyle: "italic" },
  feedbackCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 16,
    gap: 10,
  },
  feedbackHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  feedbackTitle: { fontSize: 15, fontWeight: "700", flex: 1 },
  explanationText: { fontSize: 13, lineHeight: 22 },
  examNavRow: { flexDirection: "row", gap: 10, marginTop: 4 },
  reviewNavRow: { flexDirection: "row", gap: 10, marginTop: 4 },
  navBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderRadius: 14,
    borderWidth: 1.5,
    paddingVertical: 14,
  },
  navBtnPrimary: { borderWidth: 0 },
  navBtnDisabled: { opacity: 0.35 },
  navBtnText: { fontSize: 14, fontWeight: "700" },
  submitAnytimeBtn: { alignItems: "center", marginTop: 16, padding: 8 },
  submitAnytimeText: { fontSize: 13, textDecorationLine: "underline" },
  // Intro
  introContent: { padding: 24, alignItems: "center", paddingBottom: 48 },
  introIconWrap: {
    width: 76,
    height: 76,
    borderRadius: 38,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  introTitle: { fontSize: 24, fontWeight: "800", letterSpacing: -0.5, marginBottom: 4 },
  introDesc: { fontSize: 14, marginBottom: 24, textAlign: "center" },
  introCard: {
    width: "100%",
    borderRadius: 16,
    borderWidth: 1,
    padding: 18,
    marginBottom: 16,
  },
  introRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
  },
  introRowLeft: { flexDirection: "row", alignItems: "center", gap: 8 },
  subjectDot: { width: 8, height: 8, borderRadius: 4 },
  introRowLabel: { fontSize: 14 },
  introRowValue: { fontSize: 14 },
  introDivider: { height: 1, marginVertical: 4 },
  introNote: {
    flexDirection: "row",
    gap: 8,
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    marginBottom: 28,
    width: "100%",
  },
  introNoteText: { fontSize: 12, lineHeight: 18, flex: 1 },
  startBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 14,
    paddingVertical: 16,
    width: "100%",
  },
  startBtnText: { fontSize: 16, fontWeight: "700", color: "#FFFFFF" },
  // Result
  resultContent: { padding: 24, alignItems: "center", paddingBottom: 48 },
  resultIconWrap: { marginTop: 24, marginBottom: 16 },
  resultTitle: { fontSize: 26, fontWeight: "800", letterSpacing: -0.5, marginBottom: 4 },
  resultSubject: { fontSize: 14, marginBottom: 24 },
  resultScoreCard: {
    width: "100%",
    borderRadius: 18,
    borderWidth: 1,
    padding: 24,
    alignItems: "center",
    gap: 8,
    marginBottom: 20,
  },
  resultRate: { fontSize: 52, fontWeight: "900", letterSpacing: -2 },
  resultScore: { fontSize: 15 },
  subjectResultCard: {
    width: "100%",
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 32,
  },
  subjectResultRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
  },
  subjectResultRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  resultBtns: { flexDirection: "row", gap: 12, width: "100%" },
  resultBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 15,
    borderRadius: 14,
  },
  resultBtnOutline: { borderWidth: 1.5, backgroundColor: "transparent" },
  resultBtnText: { fontSize: 15, fontWeight: "700" },
});
