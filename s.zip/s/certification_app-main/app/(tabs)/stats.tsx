import React, { useCallback, useState } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
} from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import {
  getStudyStats,
  getLast7DaysLog,
  getQuestionProgress,
  getMockExamResults,
  resetStudyStats,
  clearWrongAnswers,
  MockExamRecord,
  QuestionProgress,
  StudyStats,
} from "@/lib/storage";
import { OVERALL_PASS_RATE } from "@/lib/mock-exam-scoring";
import { questions, Question, SUBJECTS, Subject, SUBJECT_COLORS } from "@/data/questions";

interface DayLog {
  date: string;
  count: number;
}

// 약한 과목 추천은 이만큼은 풀어봐야 의미가 있다.
const WEAK_SUBJECT_MIN_ANSWERED = 5;
const FREQUENT_WRONG_LIMIT = 5;
const MOCK_TREND_LIMIT = 10;

const questionById = new Map(questions.map((q) => [q.id, q]));

export default function StatsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, logout } = useAuth();
  const [stats, setStats] = useState<StudyStats | null>(null);
  const [dailyLog, setDailyLog] = useState<DayLog[]>([]);
  const [progress, setProgress] = useState<QuestionProgress[]>([]);
  const [mockResults, setMockResults] = useState<MockExamRecord[]>([]);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const loadAll = useCallback(async () => {
    const [s, log, p, mock] = await Promise.all([
      getStudyStats(),
      getLast7DaysLog(),
      getQuestionProgress(),
      getMockExamResults(MOCK_TREND_LIMIT),
    ]);
    setStats(s);
    setDailyLog(log);
    setProgress(p);
    setMockResults(mock);
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadAll().catch(() => {});
    }, [loadAll])
  );

  const overallRate =
    stats && stats.totalAnswered > 0
      ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100)
      : 0;

  const maxDailyCount = Math.max(...dailyLog.map((d) => d.count), 1);

  // 정답률이 가장 낮은 과목 (충분히 풀어본 과목 중에서)
  const weakSubject = SUBJECTS.map((subject) => {
    const s = stats?.bySubject[subject];
    return { subject, answered: s?.total ?? 0, rate: s && s.total > 0 ? s.correct / s.total : 0 };
  })
    .filter((s) => s.answered >= WEAK_SUBJECT_MIN_ANSWERED)
    .sort((a, b) => a.rate - b.rate)[0];

  // 틀린 횟수가 많은 순 (같으면 오답 비율이 높은 순)
  const frequentWrong = progress
    .map((p) => ({ ...p, wrong: p.attempts - p.correct, question: questionById.get(p.questionId) }))
    .filter((p): p is typeof p & { question: Question } => p.wrong > 0 && p.question !== undefined)
    .sort((a, b) => b.wrong - a.wrong || b.wrong / b.attempts - a.wrong / a.attempts)
    .slice(0, FREQUENT_WRONG_LIMIT);

  // 오래된 것 → 최신 순으로 그래프에 그린다
  const mockTrend = [...mockResults].reverse();

  const handleReset = () => setShowResetConfirm(true);

  const confirmReset = async () => {
    setShowResetConfirm(false);
    await resetStudyStats();
    await clearWrongAnswers();
    await loadAll();
  };

  // "YYYY-MM-DD" → "M/D" (Date로 파싱하면 기기 시간대에 따라 하루 밀릴 수 있어서 문자열로 자른다)
  const formatDate = (dateStr: string) => {
    const [, m, d] = dateStr.split("-");
    return `${Number(m)}/${Number(d)}`;
  };

  const handleLogout = () => setShowLogoutConfirm(true);

  const confirmLogout = async () => {
    setShowLogoutConfirm(false);
    await logout();
    router.replace("/login");
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>
              학습 통계
            </Text>
            {user ? (
              <Text style={[styles.headerEmail, { color: colors.muted }]}>
                {user.nickname || user.email}
              </Text>
            ) : null}
          </View>
          <View style={styles.headerActions}>
            <Pressable
              style={({ pressed }) => [pressed && { opacity: 0.6 }]}
              onPress={handleReset}
            >
              <IconSymbol name="arrow.clockwise" size={20} color={colors.muted} />
            </Pressable>
            <Pressable
              style={({ pressed }) => [pressed && { opacity: 0.6 }]}
              onPress={handleLogout}
            >
              <IconSymbol name="rectangle.portrait.and.arrow.right" size={20} color={colors.muted} />
            </Pressable>
          </View>
        </View>

        {/* Overall Stats */}
        <View style={styles.overallGrid}>
          <StatCard
            colors={colors}
            value={String(stats?.totalAnswered ?? 0)}
            label="총 풀이"
            icon="doc.text.fill"
            iconColor={colors.primary}
          />
          <StatCard
            colors={colors}
            value={`${overallRate}%`}
            label="전체 정답률"
            icon="checkmark.circle.fill"
            iconColor={colors.success}
          />
          <StatCard
            colors={colors}
            value={String(stats?.streakDays ?? 0)}
            label="연속 학습일"
            icon="flame.fill"
            iconColor={colors.warning}
          />
          <StatCard
            colors={colors}
            value={String(stats?.totalCorrect ?? 0)}
            label="총 정답"
            icon="star.fill"
            iconColor={colors.accent}
          />
        </View>

        {/* Subject Stats */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          과목별 정답률
        </Text>
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {SUBJECTS.map((subject, idx) => {
            const s = stats?.bySubject[subject as Subject];
            const answered = s?.total ?? 0;
            const correct = s?.correct ?? 0;
            const rate = answered > 0 ? Math.round((correct / answered) * 100) : 0;
            const color = SUBJECT_COLORS[subject as Subject];
            return (
              <View key={subject}>
                {idx > 0 && (
                  <View style={[styles.divider, { backgroundColor: colors.border }]} />
                )}
                <View style={styles.subjectRow}>
                  <View style={styles.subjectLeft}>
                    <View style={[styles.subjectDot, { backgroundColor: color }]} />
                    <Text style={[styles.subjectName, { color: colors.foreground }]}>
                      {subject}
                    </Text>
                  </View>
                  <View style={styles.subjectRight}>
                    <Text style={[styles.subjectAnswered, { color: colors.muted }]}>
                      {answered}문제
                    </Text>
                    <Text style={[styles.subjectRate, { color: color }]}>
                      {rate}%
                    </Text>
                  </View>
                </View>
                <View style={[styles.barBg, { backgroundColor: colors.border }]}>
                  <View
                    style={[
                      styles.barFill,
                      { backgroundColor: color, width: `${rate}%` },
                    ]}
                  />
                </View>
                <Text style={[styles.barDetail, { color: colors.muted }]}>
                  {correct}/{answered} 정답
                </Text>
              </View>
            );
          })}
        </View>

        {/* Daily Log */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          최근 7일 학습
        </Text>
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.chartContainer}>
            {dailyLog.map((day, idx) => {
              const barHeight = Math.max(
                (day.count / maxDailyCount) * 100,
                day.count > 0 ? 8 : 0
              );
              // 서버가 한국 시간 기준 오늘을 마지막 항목으로 돌려준다
              const isToday = idx === dailyLog.length - 1;
              return (
                <View key={day.date} style={styles.chartBar}>
                  <Text style={[styles.chartCount, { color: colors.muted }]}>
                    {day.count > 0 ? day.count : ""}
                  </Text>
                  <View style={styles.chartBarWrap}>
                    <View
                      style={[
                        styles.chartBarFill,
                        {
                          height: barHeight,
                          backgroundColor: isToday
                            ? colors.primary
                            : colors.primary + "60",
                          borderRadius: 4,
                        },
                      ]}
                    />
                  </View>
                  <Text
                    style={[
                      styles.chartDate,
                      {
                        color: isToday ? colors.primary : colors.muted,
                        fontWeight: isToday ? "700" : "400",
                      },
                    ]}
                  >
                    {formatDate(day.date)}
                  </Text>
                </View>
              );
            })}
          </View>
          <Text style={[styles.chartNote, { color: colors.muted }]}>
            오늘 포함 최근 7일간 풀이 수
          </Text>
        </View>

        {/* Weak Subject */}
        {weakSubject && (
          <Pressable
            style={({ pressed }) => [
              styles.weakCard,
              {
                backgroundColor: SUBJECT_COLORS[weakSubject.subject] + "12",
                borderColor: SUBJECT_COLORS[weakSubject.subject] + "40",
              },
              pressed && { opacity: 0.8 },
            ]}
            onPress={() =>
              router.push({ pathname: "/quiz-session", params: { subject: weakSubject.subject } })
            }
          >
            <IconSymbol name="lightbulb.fill" size={22} color={SUBJECT_COLORS[weakSubject.subject]} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.weakTitle, { color: colors.foreground }]}>
                {weakSubject.subject} 집중 공략!
              </Text>
              <Text style={[styles.weakDesc, { color: colors.muted }]}>
                정답률 {Math.round(weakSubject.rate * 100)}%로 가장 약한 과목이에요. 지금 10문제 풀어볼까요?
              </Text>
            </View>
            <IconSymbol name="chevron.right" size={16} color={colors.muted} />
          </Pressable>
        )}

        {/* Frequently Wrong */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          자주 틀리는 문제 TOP {FREQUENT_WRONG_LIMIT}
        </Text>
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {frequentWrong.length === 0 ? (
            <Text style={[styles.emptyNote, { color: colors.muted }]}>
              아직 틀린 문제가 없어요. 계속 풀어보세요!
            </Text>
          ) : (
            frequentWrong.map((item, idx) => (
              <View key={item.questionId}>
                {idx > 0 && <View style={[styles.divider, { backgroundColor: colors.border }]} />}
                <View style={styles.wrongRow}>
                  <Text style={[styles.wrongRank, { color: colors.error }]}>{idx + 1}</Text>
                  <View style={{ flex: 1, gap: 4 }}>
                    <Text
                      style={[styles.wrongQuestion, { color: colors.foreground }]}
                      numberOfLines={2}
                    >
                      {item.question.question}
                    </Text>
                    <Text style={[styles.wrongMeta, { color: colors.muted }]}>
                      {item.question.subject} · {item.attempts}번 중 {item.wrong}번 틀림
                    </Text>
                  </View>
                </View>
              </View>
            ))
          )}
        </View>

        {/* Mock Exam Trend */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          모의고사 점수 추이
        </Text>
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {mockTrend.length === 0 ? (
            <Pressable onPress={() => router.push("/mock-exam")}>
              <Text style={[styles.emptyNote, { color: colors.muted }]}>
                아직 응시 기록이 없어요. 실전 모의고사에 도전해보세요 →
              </Text>
            </Pressable>
          ) : (
            <>
              <View style={styles.chartContainer}>
                <View
                  pointerEvents="none"
                  style={[
                    styles.passLine,
                    // 막대 영역(100px)은 날짜 라벨(약 13px) + gap(4px) 위에서 시작한다
                    { bottom: 17 + OVERALL_PASS_RATE * 100, borderColor: colors.success + "80" },
                  ]}
                />
                {mockTrend.map((r) => {
                  const score = Math.round((r.correct / r.total) * 100);
                  return (
                    <View key={r.id} style={styles.chartBar}>
                      <Text style={[styles.chartCount, { color: colors.muted }]}>{score}</Text>
                      <View style={styles.chartBarWrap}>
                        <View
                          style={[
                            styles.chartBarFill,
                            {
                              height: Math.max(score, 4),
                              backgroundColor: r.passed ? colors.success : colors.error + "90",
                              borderRadius: 4,
                            },
                          ]}
                        />
                      </View>
                      <Text style={[styles.chartDate, { color: colors.muted }]}>
                        {new Date(r.takenAt).getMonth() + 1}/{new Date(r.takenAt).getDate()}
                      </Text>
                    </View>
                  );
                })}
              </View>
              <Text style={[styles.chartNote, { color: colors.muted }]}>
                최근 {mockTrend.length}회 · 초록 = 합격 · 점선 = 합격선 {OVERALL_PASS_RATE * 100}점
              </Text>
            </>
          )}
        </View>

        {/* Achievement */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          달성 현황
        </Text>
        <View style={styles.achievementGrid}>
          {[
            {
              icon: "doc.text.fill" as const,
              label: "첫 문제 풀기",
              achieved: (stats?.totalAnswered ?? 0) >= 1,
              color: colors.primary,
            },
            {
              icon: "star.fill" as const,
              label: "10문제 정답",
              achieved: (stats?.totalCorrect ?? 0) >= 10,
              color: colors.warning,
            },
            {
              icon: "flame.fill" as const,
              label: "3일 연속 학습",
              achieved: (stats?.streakDays ?? 0) >= 3,
              color: colors.error,
            },
            {
              icon: "trophy.fill" as const,
              label: "정답률 70%",
              achieved: overallRate >= 70 && (stats?.totalAnswered ?? 0) >= 10,
              color: colors.accent,
            },
          ].map((item) => (
            <View
              key={item.label}
              style={[
                styles.achieveCard,
                {
                  backgroundColor: item.achieved
                    ? item.color + "12"
                    : colors.surface,
                  borderColor: item.achieved ? item.color + "40" : colors.border,
                },
              ]}
            >
              <IconSymbol
                name={item.icon}
                size={28}
                color={item.achieved ? item.color : colors.border}
              />
              <Text
                style={[
                  styles.achieveLabel,
                  { color: item.achieved ? colors.foreground : colors.muted },
                ]}
                numberOfLines={2}
              >
                {item.label}
              </Text>
              {item.achieved && (
                <View style={[styles.achievedBadge, { backgroundColor: item.color }]}>
                  <Text style={styles.achievedBadgeText}>달성</Text>
                </View>
              )}
            </View>
          ))}
        </View>
      </ScrollView>

      <ConfirmDialog
        visible={showResetConfirm}
        title="학습 기록 초기화"
        message="모든 학습 통계와 오답 노트가 초기화됩니다. 계속하시겠습니까?"
        confirmLabel="초기화"
        destructive
        onConfirm={confirmReset}
        onCancel={() => setShowResetConfirm(false)}
      />

      <ConfirmDialog
        visible={showLogoutConfirm}
        title="로그아웃"
        message="로그아웃하시겠습니까?"
        confirmLabel="로그아웃"
        destructive
        onConfirm={confirmLogout}
        onCancel={() => setShowLogoutConfirm(false)}
      />
    </ScreenContainer>
  );
}

function StatCard({
  colors,
  value,
  label,
  icon,
  iconColor,
}: {
  colors: ReturnType<typeof useColors>;
  value: string;
  label: string;
  icon: React.ComponentProps<typeof IconSymbol>["name"];
  iconColor: string;
}) {
  return (
    <View
      style={[
        styles.statCard,
        { backgroundColor: colors.surface, borderColor: colors.border },
      ]}
    >
      <IconSymbol name={icon} size={22} color={iconColor} />
      <Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>
      <Text style={[styles.statLabel, { color: colors.muted }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    padding: 20,
    paddingBottom: 32,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  headerEmail: {
    fontSize: 12,
    marginTop: 2,
  },
  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
  overallGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginBottom: 24,
  },
  statCard: {
    width: "47%",
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 6,
    alignItems: "flex-start",
  },
  statValue: {
    fontSize: 26,
    fontWeight: "800",
    letterSpacing: -1,
  },
  statLabel: {
    fontSize: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
    marginBottom: 12,
    letterSpacing: -0.3,
  },
  card: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    marginBottom: 24,
  },
  divider: {
    height: 1,
    marginVertical: 12,
  },
  subjectRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  subjectLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  subjectDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  subjectName: {
    fontSize: 14,
    fontWeight: "600",
  },
  subjectRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  subjectAnswered: {
    fontSize: 12,
  },
  subjectRate: {
    fontSize: 15,
    fontWeight: "800",
    minWidth: 40,
    textAlign: "right",
  },
  barBg: {
    height: 8,
    borderRadius: 4,
    overflow: "hidden",
    marginBottom: 4,
  },
  barFill: {
    height: 8,
    borderRadius: 4,
  },
  barDetail: {
    fontSize: 11,
  },
  // Chart
  chartContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    height: 120,
    marginBottom: 8,
  },
  chartBar: {
    flex: 1,
    alignItems: "center",
    justifyContent: "flex-end",
    gap: 4,
  },
  chartCount: {
    fontSize: 10,
    fontWeight: "600",
    height: 14,
  },
  chartBarWrap: {
    width: "70%",
    height: 100,
    justifyContent: "flex-end",
  },
  chartBarFill: {
    width: "100%",
    minHeight: 0,
  },
  chartDate: {
    fontSize: 10,
  },
  chartNote: {
    fontSize: 11,
    textAlign: "center",
    marginTop: 4,
  },
  passLine: {
    position: "absolute",
    left: 0,
    right: 0,
    borderTopWidth: 1,
    borderStyle: "dashed",
  },
  emptyNote: {
    fontSize: 13,
    textAlign: "center",
    paddingVertical: 8,
  },
  // Weak subject / frequent wrong
  weakCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 24,
  },
  weakTitle: {
    fontSize: 15,
    fontWeight: "700",
  },
  weakDesc: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 2,
  },
  wrongRow: {
    flexDirection: "row",
    gap: 12,
    alignItems: "flex-start",
  },
  wrongRank: {
    fontSize: 16,
    fontWeight: "800",
    width: 16,
  },
  wrongQuestion: {
    fontSize: 13,
    fontWeight: "600",
    lineHeight: 19,
  },
  wrongMeta: {
    fontSize: 11,
  },
  // Achievement
  achievementGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  achieveCard: {
    width: "47%",
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 8,
    alignItems: "flex-start",
    position: "relative",
  },
  achieveLabel: {
    fontSize: 13,
    fontWeight: "600",
    lineHeight: 18,
  },
  achievedBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 20,
  },
  achievedBadgeText: {
    fontSize: 10,
    fontWeight: "700",
    color: "#FFFFFF",
  },
});
