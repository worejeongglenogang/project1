import React, { useCallback, useState } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
} from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import {
  getExamDate,
  getQuestionProgress,
  getStudyStats,
  QuestionProgress,
  StudyStats,
} from "@/lib/storage";
import { diffDays, kstDateStr } from "@/lib/kst-date";
import { SUBJECTS, Subject, SUBJECT_COLORS, questions } from "@/data/questions";

const TOTAL_QUESTIONS = questions.length;
const subjectOf = new Map(questions.map((q) => [q.id, q.subject]));

function formatDday(days: number): string {
  if (days === 0) return "D-DAY";
  return days > 0 ? `D-${days}` : `D+${-days}`;
}

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const [stats, setStats] = useState<StudyStats | null>(null);
  const [progress, setProgress] = useState<QuestionProgress[]>([]);
  const [examDate, setExamDate] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      getStudyStats().then(setStats).catch(() => {});
      getQuestionProgress().then(setProgress).catch(() => {});
      getExamDate().then(setExamDate).catch(() => {});
    }, [])
  );

  const overallRate =
    stats && stats.totalAnswered > 0
      ? Math.round((stats.totalCorrect / stats.totalAnswered) * 100)
      : 0;
  const solvedTotal = progress.filter((p) => subjectOf.has(p.questionId)).length;
  const dday = examDate ? diffDays(kstDateStr(), examDate) : null;

  // 진도율 = 한 번이라도 푼 "서로 다른" 문제 수 / 과목 문제 수 (같은 문제를 여러 번 풀어도 1개)
  const subjectProgress = SUBJECTS.map((subject) => {
    const subjectTotal = questions.filter((q) => q.subject === subject).length;
    const solved = progress.filter((p) => subjectOf.get(p.questionId) === subject).length;
    const s = stats?.bySubject[subject];
    const answered = s?.total ?? 0;
    const correct = s?.correct ?? 0;
    const rate = answered > 0 ? Math.round((correct / answered) * 100) : 0;
    return { subject, solved, answered, rate, total: subjectTotal };
  });

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>
              i can do it 자격증
            </Text>
            <Text style={[styles.headerSubtitle, { color: colors.muted }]}>
              ADSP(데이터분석 준전문가) 자격증
            </Text>
          </View>
          {stats?.streakDays ? (
            <View style={[styles.streakBadge, { backgroundColor: colors.warning + "20" }]}>
              <IconSymbol name="flame.fill" size={16} color={colors.warning} />
              <Text style={[styles.streakText, { color: colors.warning }]}>
                {stats.streakDays}일 연속
              </Text>
            </View>
          ) : null}
        </View>

        {/* D-day Card */}
        <Pressable
          style={({ pressed }) => [
            styles.ddayCard,
            { backgroundColor: colors.surface, borderColor: colors.border },
            pressed && { opacity: 0.75 },
          ]}
          onPress={() => router.push("/study-settings")}
        >
          <IconSymbol name="calendar" size={22} color={colors.primary} />
          {dday !== null ? (
            <View style={{ flex: 1 }}>
              <Text style={[styles.ddayTitle, { color: colors.foreground }]}>
                ADsP 시험{" "}
                <Text style={{ color: dday <= 7 && dday >= 0 ? colors.error : colors.primary }}>
                  {formatDday(dday)}
                </Text>
              </Text>
              <Text style={[styles.ddaySub, { color: colors.muted }]}>
                {dday < 0 ? "시험이 끝났어요. 다음 시험일을 설정해보세요" : `${examDate} · 알림 설정`}
              </Text>
            </View>
          ) : (
            <View style={{ flex: 1 }}>
              <Text style={[styles.ddayTitle, { color: colors.foreground }]}>시험일을 설정하세요</Text>
              <Text style={[styles.ddaySub, { color: colors.muted }]}>
                D-day와 매일 학습 알림을 받을 수 있어요
              </Text>
            </View>
          )}
          <IconSymbol name="chevron.right" size={16} color={colors.muted} />
        </Pressable>

        {/* Overall Stats Card */}
        <View style={[styles.statsCard, { backgroundColor: colors.primary }]}>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{stats?.totalAnswered ?? 0}</Text>
              <Text style={styles.statLabel}>총 풀이</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{overallRate}%</Text>
              <Text style={styles.statLabel}>정답률</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>
                {solvedTotal}
                <Text style={styles.statValueSub}>/{TOTAL_QUESTIONS}</Text>
              </Text>
              <Text style={styles.statLabel}>푼 문제</Text>
            </View>
          </View>
        </View>

        {/* Subject Progress */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          과목별 학습 현황
        </Text>
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {subjectProgress.map((item, idx) => (
            <View key={item.subject}>
              {idx > 0 && <View style={[styles.divider, { backgroundColor: colors.border }]} />}
              <View style={styles.subjectRow}>
                <View style={styles.subjectInfo}>
                  <View
                    style={[
                      styles.subjectDot,
                      { backgroundColor: SUBJECT_COLORS[item.subject as Subject] },
                    ]}
                  />
                  <Text style={[styles.subjectName, { color: colors.foreground }]}>
                    {item.subject}
                  </Text>
                </View>
                <Text style={[styles.subjectRate, { color: colors.muted }]}>
                  {item.solved}/{item.total}문제 · 정답률 {item.rate}%
                </Text>
              </View>
              <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
                <View
                  style={[
                    styles.progressFill,
                    {
                      backgroundColor: SUBJECT_COLORS[item.subject as Subject],
                      width: `${item.total > 0 ? Math.round((item.solved / item.total) * 100) : 0}%`,
                    },
                  ]}
                />
              </View>
            </View>
          ))}
        </View>

        {/* Quick Start */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          빠른 시작
        </Text>
        <View style={styles.quickStartGrid}>
          {SUBJECTS.map((subject) => (
            <Pressable
              key={subject}
              style={({ pressed }) => [
                styles.quickCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
                pressed && { opacity: 0.75 },
              ]}
              onPress={() =>
                router.push({
                  pathname: "/quiz-session",
                  params: { subject },
                })
              }
            >
              <View
                style={[
                  styles.quickCardIcon,
                  { backgroundColor: SUBJECT_COLORS[subject] + "18" },
                ]}
              >
                <IconSymbol
                  name="book.fill"
                  size={22}
                  color={SUBJECT_COLORS[subject]}
                />
              </View>
              <Text
                style={[styles.quickCardTitle, { color: colors.foreground }]}
                numberOfLines={2}
              >
                {subject}
              </Text>
              <Text style={[styles.quickCardCount, { color: colors.muted }]}>
                {questions.filter((q) => q.subject === subject).length}문제
              </Text>
            </Pressable>
          ))}
          <Pressable
            style={({ pressed }) => [
              styles.quickCard,
              { backgroundColor: colors.primary + "12", borderColor: colors.primary + "40" },
              pressed && { opacity: 0.75 },
            ]}
            onPress={() =>
              router.push({
                pathname: "/quiz-session",
                params: { subject: "전체" },
              })
            }
          >
            <View
              style={[
                styles.quickCardIcon,
                { backgroundColor: colors.primary + "20" },
              ]}
            >
              <IconSymbol name="shuffle" size={22} color={colors.primary} />
            </View>
            <Text
              style={[styles.quickCardTitle, { color: colors.foreground }]}
              numberOfLines={2}
            >
              전체 랜덤
            </Text>
            <Text style={[styles.quickCardCount, { color: colors.muted }]}>
              {TOTAL_QUESTIONS}문제
            </Text>
          </Pressable>
        </View>

        {/* Tip Card */}
        <View
          style={[
            styles.tipCard,
            { backgroundColor: colors.primary + "10", borderColor: colors.primary + "30" },
          ]}
        >
          <IconSymbol name="lightbulb.fill" size={18} color={colors.primary} />
          <Text style={[styles.tipText, { color: colors.primary }]}>
            매일 꾸준히 풀면 합격률이 높아집니다. 오답 노트를 활용하세요!
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    padding: 20,
    paddingBottom: 32,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  streakBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
  },
  streakText: {
    fontSize: 13,
    fontWeight: "700",
  },
  statsCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  statsRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
  },
  statItem: {
    alignItems: "center",
    flex: 1,
  },
  statValue: {
    fontSize: 28,
    fontWeight: "800",
    color: "#FFFFFF",
    letterSpacing: -1,
  },
  statValueSub: {
    fontSize: 14,
    fontWeight: "600",
    color: "rgba(255,255,255,0.75)",
    letterSpacing: 0,
  },
  ddayCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 14,
  },
  ddayTitle: {
    fontSize: 16,
    fontWeight: "800",
  },
  ddaySub: {
    fontSize: 12,
    marginTop: 2,
  },
  statLabel: {
    fontSize: 12,
    color: "rgba(255,255,255,0.75)",
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    height: 36,
    backgroundColor: "rgba(255,255,255,0.25)",
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
    marginBottom: 12,
    letterSpacing: -0.3,
  },
  card: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
    marginBottom: 24,
  },
  divider: {
    height: 1,
    marginVertical: 12,
  },
  subjectRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  subjectInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  subjectDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  subjectName: {
    fontSize: 14,
    fontWeight: "600",
  },
  subjectRate: {
    fontSize: 12,
  },
  progressBg: {
    height: 6,
    borderRadius: 3,
    overflow: "hidden",
  },
  progressFill: {
    height: 6,
    borderRadius: 3,
  },
  quickStartGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginBottom: 24,
  },
  quickCard: {
    width: "47%",
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 8,
  },
  quickCardIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  quickCardTitle: {
    fontSize: 14,
    fontWeight: "700",
    lineHeight: 20,
  },
  quickCardCount: {
    fontSize: 12,
  },
  tipCard: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
  },
  tipText: {
    fontSize: 13,
    lineHeight: 20,
    flex: 1,
    fontWeight: "500",
  },
});
