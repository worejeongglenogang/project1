import React, { useCallback, useState } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
} from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { getBookmarks } from "@/lib/storage";
import { SUBJECTS, Subject, SUBJECT_COLORS, questions } from "@/data/questions";

const SUBJECT_DESCRIPTIONS: Record<Subject, string> = {
  "1과목(데이터 이해)": "데이터 개념, 데이터베이스, 빅데이터",
  "2과목(데이터 분석 기획)": "분석 기획, 통계 기초, 데이터 수집",
  "3과목(데이터 분석)": "데이터 분석, 머신러닝, 시각화",
};

export default function QuizScreen() {
  const colors = useColors();
  const router = useRouter();

  const totalCount = questions.length;
  const [bookmarkCount, setBookmarkCount] = useState(0);

  useFocusEffect(
    useCallback(() => {
      getBookmarks()
        .then((ids) => setBookmarkCount(ids.length))
        .catch(() => {});
    }, [])
  );

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            문제 풀기
          </Text>
          <Text style={[styles.headerSubtitle, { color: colors.muted }]}>
            과목을 선택하거나 전체 랜덤으로 시작하세요
          </Text>
        </View>

        {/* Mock Exam Card */}
        <Pressable
          style={({ pressed }) => [
            styles.allCard,
            { backgroundColor: "#0F172A" },
            pressed && { opacity: 0.88 },
          ]}
          onPress={() => router.push("/mock-exam")}
        >
          <View style={styles.allCardContent}>
            <View style={styles.allCardLeft}>
              <Text style={styles.allCardTitle}>실전 모의고사</Text>
              <Text style={styles.allCardDesc}>
                1과목 10 · 2과목 10 · 3과목 30문제, 90분 타이머
              </Text>
              <View style={styles.allCardBadge}>
                <Text style={styles.allCardBadgeText}>매번 랜덤 출제</Text>
              </View>
            </View>
            <IconSymbol name="clock.fill" size={40} color="rgba(255,255,255,0.6)" />
          </View>
        </Pressable>

        {/* Photo Recognition Card */}
        <Pressable
          style={({ pressed }) => [
            styles.allCard,
            { backgroundColor: colors.error },
            pressed && { opacity: 0.88 },
          ]}
          onPress={() => router.push("/photo-recognition")}
        >
          <View style={styles.allCardContent}>
            <View style={styles.allCardLeft}>
              <Text style={styles.allCardTitle}>사진으로 풀기</Text>
              <Text style={styles.allCardDesc}>
                문제를 촬영하면 AI가 해설해줍니다
              </Text>
              <View style={styles.allCardBadge}>
                <Text style={styles.allCardBadgeText}>AI 해설</Text>
              </View>
            </View>
            <IconSymbol name="camera.fill" size={40} color="rgba(255,255,255,0.6)" />
          </View>
        </Pressable>

        {/* All Random Card */}
        <Pressable
          style={({ pressed }) => [
            styles.allCard,
            { backgroundColor: colors.primary },
            pressed && { opacity: 0.88 },
          ]}
          onPress={() =>
            router.push({ pathname: "/quiz-session", params: { subject: "전체" } })
          }
        >
          <View style={styles.allCardContent}>
            <View style={styles.allCardLeft}>
              <Text style={styles.allCardTitle}>전체 랜덤 풀기</Text>
              <Text style={styles.allCardDesc}>
                모든 과목에서 무작위로 출제
              </Text>
              <View style={styles.allCardBadge}>
                <Text style={styles.allCardBadgeText}>{totalCount}문제</Text>
              </View>
            </View>
            <IconSymbol name="shuffle" size={40} color="rgba(255,255,255,0.6)" />
          </View>
        </Pressable>

        {/* Bookmark Card */}
        <Pressable
          style={({ pressed }) => [
            styles.bookmarkCard,
            { backgroundColor: colors.warning + "12", borderColor: colors.warning + "40" },
            pressed && { opacity: 0.8 },
          ]}
          onPress={() =>
            router.push({ pathname: "/quiz-session", params: { subject: "북마크" } })
          }
        >
          <IconSymbol name="bookmark.fill" size={24} color={colors.warning} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.bookmarkTitle, { color: colors.foreground }]}>
              북마크한 문제 풀기
            </Text>
            <Text style={[styles.bookmarkDesc, { color: colors.muted }]}>
              {bookmarkCount > 0
                ? `헷갈려서 표시한 ${bookmarkCount}문제`
                : "풀이 중 오른쪽 위 북마크 버튼으로 모아보세요"}
            </Text>
          </View>
          <IconSymbol name="chevron.right" size={16} color={colors.muted} />
        </Pressable>

        {/* Subject Cards */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          과목별 풀기
        </Text>
        <View style={styles.subjectGrid}>
          {SUBJECTS.map((subject) => {
            const count = questions.filter((q) => q.subject === subject).length;
            const color = SUBJECT_COLORS[subject];
            return (
              <Pressable
                key={subject}
                style={({ pressed }) => [
                  styles.subjectCard,
                  {
                    backgroundColor: colors.surface,
                    borderColor: colors.border,
                  },
                  pressed && { opacity: 0.75 },
                ]}
                onPress={() =>
                  router.push({
                    pathname: "/quiz-session",
                    params: { subject },
                  })
                }
              >
                <View
                  style={[
                    styles.subjectCardIcon,
                    { backgroundColor: color + "18" },
                  ]}
                >
                  <IconSymbol name="book.fill" size={28} color={color} />
                </View>
                <Text
                  style={[styles.subjectCardTitle, { color: colors.foreground }]}
                >
                  {subject}
                </Text>
                <Text
                  style={[styles.subjectCardDesc, { color: colors.muted }]}
                  numberOfLines={2}
                >
                  {SUBJECT_DESCRIPTIONS[subject]}
                </Text>
                <View style={styles.subjectCardFooter}>
                  <View
                    style={[styles.subjectCountBadge, { backgroundColor: color + "18" }]}
                  >
                    <Text style={[styles.subjectCountText, { color }]}>
                      {count}문제
                    </Text>
                  </View>
                  <IconSymbol name="chevron.right" size={16} color={colors.muted} />
                </View>
              </Pressable>
            );
          })}
        </View>

        {/* Info Box */}
        <View
          style={[
            styles.infoBox,
            { backgroundColor: colors.surface, borderColor: colors.border },
          ]}
        >
          <IconSymbol name="info.circle" size={18} color={colors.muted} />
          <Text style={[styles.infoText, { color: colors.muted }]}>
            각 세션은 10문제로 구성됩니다(3과목은 30문제). 아직 안 푼 문제와 틀린 문제가 먼저
            출제되고, 오답은 자동으로 오답 노트에 저장됩니다.
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    padding: 20,
    paddingBottom: 32,
  },
  header: {
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 14,
    marginTop: 4,
    lineHeight: 20,
  },
  allCard: {
    borderRadius: 18,
    padding: 20,
    marginBottom: 28,
  },
  allCardContent: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  allCardLeft: {
    gap: 4,
  },
  allCardTitle: {
    fontSize: 20,
    fontWeight: "800",
    color: "#FFFFFF",
    letterSpacing: -0.5,
  },
  allCardDesc: {
    fontSize: 13,
    color: "rgba(255,255,255,0.75)",
  },
  allCardBadge: {
    marginTop: 8,
    backgroundColor: "rgba(255,255,255,0.2)",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    alignSelf: "flex-start",
  },
  allCardBadgeText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  bookmarkCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 28,
  },
  bookmarkTitle: {
    fontSize: 16,
    fontWeight: "700",
  },
  bookmarkDesc: {
    fontSize: 12,
    marginTop: 2,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
    marginBottom: 12,
    letterSpacing: -0.3,
  },
  subjectGrid: {
    gap: 12,
    marginBottom: 24,
  },
  subjectCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 18,
    gap: 8,
  },
  subjectCardIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  subjectCardTitle: {
    fontSize: 17,
    fontWeight: "700",
  },
  subjectCardDesc: {
    fontSize: 13,
    lineHeight: 20,
  },
  subjectCardFooter: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 4,
  },
  subjectCountBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  subjectCountText: {
    fontSize: 12,
    fontWeight: "700",
  },
  infoBox: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
  },
  infoText: {
    fontSize: 13,
    lineHeight: 20,
    flex: 1,
  },
});
