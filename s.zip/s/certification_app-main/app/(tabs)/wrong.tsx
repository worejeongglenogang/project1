import React, { useCallback, useState } from "react";
import {
  FlatList,
  Text,
  View,
  Pressable,
  StyleSheet,
  Alert,
  Modal,
  ActivityIndicator,
} from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { DmuExplanationPlayer } from "@/components/dmu-explanation-player";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import {
  getWrongAnswers,
  WrongAnswer,
  clearWrongAnswers,
} from "@/lib/storage";
import { questions, Question, Subject, SUBJECT_COLORS, SUBJECTS } from "@/data/questions";
import { diffDays, kstDateStr } from "@/lib/kst-date";
import { isDueForReview, WRONG_GRADUATE_STREAK } from "@/lib/review-schedule";

type FilterTab = "전체" | Subject;

function reviewLabel(item: WrongAnswer, now: number): string {
  if (isDueForReview(item, now)) return "오늘 복습";
  const days = diffDays(kstDateStr(new Date(now)), kstDateStr(new Date(item.nextReviewAt)));
  return days <= 1 ? "내일 복습" : `${days}일 후 복습`;
}

export default function WrongScreen() {
  const colors = useColors();
  const router = useRouter();
  const [wrongAnswers, setWrongAnswers] = useState<WrongAnswer[]>([]);
  const [activeFilter, setActiveFilter] = useState<FilterTab>("전체");
  const [activeExplanation, setActiveExplanation] = useState<string | null>(null);
  // 칠판(자막/TTS)은 오답 맞춤 해설을 쓰지만, 하단 "해설 내용" 박스는 항상
  // 문제은행의 기본 해설을 보여준다 - 둘을 분리해서 둘 다 확인할 수 있게 한다.
  const [activeDefaultExplanation, setActiveDefaultExplanation] = useState("");
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const generateExplanationMutation = trpc.explain.generateForWrongAnswer.useMutation();

  useFocusEffect(
    useCallback(() => {
      getWrongAnswers().then(setWrongAnswers).catch(() => {});
    }, [])
  );

  const filtered =
    activeFilter === "전체"
      ? wrongAnswers
      : wrongAnswers.filter((w) => w.subject === activeFilter);
  const now = Date.now();
  const dueCount = filtered.filter((w) => isDueForReview(w, now)).length;
  const totalDueCount = wrongAnswers.filter((w) => isDueForReview(w, now)).length;

  const questionMap = new Map<string, Question>(
    questions.map((q) => [q.id, q])
  );

  const handleClearAll = () => {
    Alert.alert(
      "오답 노트 초기화",
      "모든 오답을 삭제하시겠습니까?",
      [
        { text: "취소", style: "cancel" },
        {
          text: "삭제",
          style: "destructive",
          onPress: async () => {
            await clearWrongAnswers();
            setWrongAnswers([]);
          },
        },
      ]
    );
  };

  const handleRetry = (mode: "due" | "all") => {
    if (filtered.length === 0) return;
    const subjectParam =
      activeFilter === "전체" ? "오답_전체" : activeFilter;
    router.push({
      pathname: "/wrong-session",
      params: { filter: subjectParam, mode },
    });
  };

  const handleShowDmuExplanation = async (item: WrongAnswer, q: Question) => {
    if (generatingId) return;
    setGeneratingId(item.questionId);
    setActiveDefaultExplanation(q.explanation);
    try {
      const result = await generateExplanationMutation.mutateAsync({
        question: q.question,
        options: q.options,
        selectedOption: item.selectedOption,
        correctOption: q.answer,
      });
      setActiveExplanation(result.explanation);
    } catch (error) {
      console.warn("[Wrong] Falling back to static explanation:", error);
      setActiveExplanation(q.explanation);
    } finally {
      setGeneratingId(null);
    }
  };

  const filterTabs: FilterTab[] = ["전체", ...SUBJECTS];

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            오답 노트
          </Text>
          <Text style={[styles.headerSubtitle, { color: colors.muted }]}>
            {wrongAnswers.length}개의 오답 · 오늘 복습 {totalDueCount}개
          </Text>
        </View>
        {wrongAnswers.length > 0 && (
          <Pressable
            style={({ pressed }) => [pressed && { opacity: 0.6 }]}
            onPress={handleClearAll}
          >
            <IconSymbol name="trash.fill" size={20} color={colors.error} />
          </Pressable>
        )}
      </View>

      {/* Filter Tabs */}
      <View style={styles.filterContainer}>
        <FlatList
          horizontal
          data={filterTabs}
          keyExtractor={(item) => item}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filterList}
          renderItem={({ item }) => {
            const isActive = activeFilter === item;
            const color =
              item === "전체" ? colors.primary : SUBJECT_COLORS[item as Subject];
            return (
              <Pressable
                style={({ pressed }) => [
                  styles.filterTab,
                  {
                    backgroundColor: isActive ? color + "18" : colors.surface,
                    borderColor: isActive ? color : colors.border,
                  },
                  pressed && { opacity: 0.75 },
                ]}
                onPress={() => setActiveFilter(item)}
              >
                <Text
                  style={[
                    styles.filterTabText,
                    { color: isActive ? color : colors.muted },
                  ]}
                >
                  {item}
                </Text>
              </Pressable>
            );
          }}
        />
      </View>

      {/* Retry Buttons */}
      {filtered.length > 0 && (
        <View style={styles.retryRow}>
          <Pressable
            style={({ pressed }) => [
              styles.retryBtn,
              { backgroundColor: colors.primary, flex: 1.4 },
              dueCount === 0 && { opacity: 0.45 },
              pressed && { opacity: 0.85 },
            ]}
            onPress={() => handleRetry("due")}
            disabled={dueCount === 0}
          >
            <IconSymbol name="calendar" size={18} color="#FFFFFF" />
            <Text style={styles.retryBtnText}>오늘 복습 ({dueCount})</Text>
          </Pressable>
          <Pressable
            style={({ pressed }) => [
              styles.retryBtn,
              { borderColor: colors.primary, borderWidth: 1.5, flex: 1 },
              pressed && { opacity: 0.75 },
            ]}
            onPress={() => handleRetry("all")}
          >
            <IconSymbol name="arrow.clockwise" size={18} color={colors.primary} />
            <Text style={[styles.retryBtnText, { color: colors.primary }]}>
              전체 ({filtered.length})
            </Text>
          </Pressable>
        </View>
      )}
      {filtered.length > 0 && (
        <Text style={[styles.retryHint, { color: colors.muted }]}>
          복습일에 {WRONG_GRADUATE_STREAK}번 맞히면 오답노트에서 졸업해요 (1일 → 3일 → 7일 간격)
        </Text>
      )}

      {/* List */}
      {filtered.length === 0 ? (
        <View style={styles.emptyContainer}>
          <IconSymbol name="checkmark.circle.fill" size={56} color={colors.success} />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            오답이 없습니다!
          </Text>
          <Text style={[styles.emptyDesc, { color: colors.muted }]}>
            문제를 풀면 오답이 자동으로 저장됩니다
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.questionId}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => {
            const q = questionMap.get(item.questionId);
            if (!q) return null;
            const subjectColor = SUBJECT_COLORS[item.subject];
            return (
              <View
                style={[
                  styles.wrongCard,
                  { backgroundColor: colors.surface, borderColor: colors.border },
                ]}
              >
                {/* Subject Badge */}
                <View style={styles.wrongCardHeader}>
                  <View
                    style={[
                      styles.subjectBadge,
                      { backgroundColor: subjectColor + "18" },
                    ]}
                  >
                    <Text style={[styles.subjectBadgeText, { color: subjectColor }]}>
                      {item.subject}
                    </Text>
                  </View>
                  <View style={styles.reviewInfo}>
                    <View style={styles.reviewDots}>
                      {Array.from({ length: WRONG_GRADUATE_STREAK }, (_, i) => (
                        <View
                          key={i}
                          style={[
                            styles.reviewDot,
                            {
                              backgroundColor:
                                i < item.correctStreak ? colors.success : colors.border,
                            },
                          ]}
                        />
                      ))}
                    </View>
                    <Text
                      style={[
                        styles.reviewLabel,
                        { color: isDueForReview(item, now) ? colors.error : colors.muted },
                      ]}
                    >
                      {reviewLabel(item, now)}
                    </Text>
                  </View>
                </View>

                {/* Question */}
                <Text
                  style={[styles.wrongQuestion, { color: colors.foreground }]}
                  numberOfLines={3}
                >
                  {q.question}
                </Text>

                {/* Answer Comparison */}
                <View style={styles.answerRow}>
                  <View
                    style={[
                      styles.answerChip,
                      { backgroundColor: colors.error + "12", borderColor: colors.error + "40" },
                    ]}
                  >
                    <IconSymbol name="xmark" size={12} color={colors.error} />
                    <Text style={[styles.answerChipText, { color: colors.error }]}>
                      내 답: {q.options[item.selectedOption]}
                    </Text>
                  </View>
                </View>
                <View style={styles.answerRow}>
                  <View
                    style={[
                      styles.answerChip,
                      { backgroundColor: colors.success + "12", borderColor: colors.success + "40" },
                    ]}
                  >
                    <IconSymbol name="checkmark" size={12} color={colors.success} />
                    <Text style={[styles.answerChipText, { color: colors.success }]}>
                      정답: {q.options[q.answer]}
                    </Text>
                  </View>
                </View>

                {/* Explanation */}
                <View
                  style={[
                    styles.explanationBox,
                    { backgroundColor: colors.background, borderColor: colors.border },
                  ]}
                >
                  <Text style={[styles.explanationLabel, { color: colors.muted }]}>
                    해설
                  </Text>
                  <Text style={[styles.explanationText, { color: colors.foreground }]}>
                    {q.explanation}
                  </Text>
                </View>

                {/* 동그래 해설 - 학생이 실제로 고른 오답 기준으로 맞춤 생성 */}
                <Pressable
                  style={({ pressed }) => [
                    styles.dmuBtn,
                    { backgroundColor: colors.primary + "12", borderColor: colors.primary + "40" },
                    (pressed || generatingId === item.questionId) && { opacity: 0.75 },
                  ]}
                  onPress={() => handleShowDmuExplanation(item, q)}
                  disabled={generatingId !== null}
                >
                  {generatingId === item.questionId ? (
                    <>
                      <ActivityIndicator size="small" color={colors.primary} />
                      <Text style={[styles.dmuBtnText, { color: colors.primary }]}>
                        맞춤 해설 생성 중...
                      </Text>
                    </>
                  ) : (
                    <>
                      <IconSymbol name="play.fill" size={14} color={colors.primary} />
                      <Text style={[styles.dmuBtnText, { color: colors.primary }]}>
                        동그래 해설 보기
                      </Text>
                    </>
                  )}
                </Pressable>
              </View>
            );
          }}
        />
      )}

      {/*
        RN의 Modal은 별도 네이티브 창(윈도우)에 렌더링되기 때문에, 앱 루트의
        GestureHandlerRootView 밖으로 벗어난다. 그 상태에서는 gesture-handler가
        터치 시스템을 가로채면서 안쪽의 일반 PanResponder(동그래 해설의 스와이프
        닫기)가 move 이벤트를 못 받는 문제가 생겨서, Modal 안에 별도로 하나 더
        둬야 한다.
      */}
      <Modal
        visible={activeExplanation !== null}
        animationType="slide"
        onRequestClose={() => setActiveExplanation(null)}
      >
        <GestureHandlerRootView style={{ flex: 1 }}>
          <ScreenContainer>
            <DmuExplanationPlayer
              explanation={activeExplanation ?? ""}
              referenceExplanation={activeDefaultExplanation}
              onClose={() => setActiveExplanation(null)}
            />
          </ScreenContainer>
        </GestureHandlerRootView>
      </Modal>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: "700",
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  filterContainer: {
    marginBottom: 12,
  },
  filterList: {
    paddingHorizontal: 20,
    gap: 8,
  },
  filterTab: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    borderWidth: 1,
  },
  filterTabText: {
    fontSize: 13,
    fontWeight: "600",
  },
  retryRow: {
    flexDirection: "row",
    gap: 10,
    marginHorizontal: 20,
    marginBottom: 8,
  },
  retryBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 12,
    paddingVertical: 13,
  },
  retryHint: {
    fontSize: 12,
    marginHorizontal: 20,
    marginBottom: 12,
  },
  retryBtnText: {
    fontSize: 15,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  listContent: {
    padding: 20,
    paddingTop: 4,
    gap: 14,
    paddingBottom: 32,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    paddingBottom: 60,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "700",
  },
  emptyDesc: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 22,
  },
  wrongCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 10,
  },
  wrongCardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  reviewInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  reviewDots: {
    flexDirection: "row",
    gap: 3,
  },
  reviewDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  reviewLabel: {
    fontSize: 12,
    fontWeight: "700",
  },
  subjectBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  subjectBadgeText: {
    fontSize: 12,
    fontWeight: "700",
  },
  wrongQuestion: {
    fontSize: 14,
    fontWeight: "600",
    lineHeight: 22,
  },
  answerRow: {
    flexDirection: "row",
  },
  answerChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    flex: 1,
  },
  answerChipText: {
    fontSize: 12,
    fontWeight: "500",
    flex: 1,
    lineHeight: 18,
  },
  explanationBox: {
    borderRadius: 10,
    borderWidth: 1,
    padding: 12,
    gap: 4,
  },
  explanationLabel: {
    fontSize: 11,
    fontWeight: "700",
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  explanationText: {
    fontSize: 13,
    lineHeight: 20,
  },
  dmuBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderRadius: 10,
    borderWidth: 1,
    paddingVertical: 10,
  },
  dmuBtnText: {
    fontSize: 13,
    fontWeight: "700",
  },
});
