import { Tabs, usePathname, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Gesture, GestureDetector } from "react-native-gesture-handler";

import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Platform, View } from "react-native";
import { useColors } from "@/hooks/use-colors";

// 하단 탭 바 순서와 동일 - 좌우로 스와이프하면 이 순서대로 옆 탭으로 이동한다.
const TAB_ORDER = ["/", "/quiz", "/wrong", "/stats"] as const;

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const pathname = usePathname();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 56 + bottomPadding;

  // 명확하게 가로로 움직이는 스와이프에만 반응하고(activeOffsetX), 세로로
  // 스크롤하는 제스처는 그대로 각 화면의 ScrollView가 처리하도록 놔둔다
  // (failOffsetY). 모바일에서만 켠다 - 웹은 마우스 드래그/휠 스크롤과 겹친다.
  const swipeGesture = Gesture.Pan()
    .enabled(Platform.OS !== "web")
    .activeOffsetX([-20, 20])
    .failOffsetY([-15, 15])
    .runOnJS(true)
    .onEnd((e) => {
      const currentIndex = TAB_ORDER.indexOf(pathname as (typeof TAB_ORDER)[number]);
      if (currentIndex === -1) return;
      if (e.translationX < -60 && currentIndex < TAB_ORDER.length - 1) {
        router.push(TAB_ORDER[currentIndex + 1] as never);
      } else if (e.translationX > 60 && currentIndex > 0) {
        router.push(TAB_ORDER[currentIndex - 1] as never);
      }
    });

  return (
    <GestureDetector gesture={swipeGesture}>
    {/* GestureDetector의 자식이 view-flatten 최적화로 사라지지 않도록 보호 */}
    <View collapsable={false} style={{ flex: 1 }}>
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarStyle: {
          paddingTop: 8,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          backgroundColor: colors.background,
          borderTopColor: colors.border,
          borderTopWidth: 0.5,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: "600",
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "홈",
          tabBarIcon: ({ color }) => <IconSymbol size={26} name="house.fill" color={color} />,
        }}
      />
      <Tabs.Screen
        name="quiz"
        options={{
          title: "문제풀기",
          tabBarIcon: ({ color }) => <IconSymbol size={26} name="book.fill" color={color} />,
        }}
      />
      <Tabs.Screen
        name="wrong"
        options={{
          title: "오답노트",
          tabBarIcon: ({ color }) => <IconSymbol size={26} name="xmark.circle.fill" color={color} />,
        }}
      />
      <Tabs.Screen
        name="stats"
        options={{
          title: "통계",
          tabBarIcon: ({ color }) => <IconSymbol size={26} name="chart.bar.fill" color={color} />,
        }}
      />
    </Tabs>
    </View>
    </GestureDetector>
  );
}
