import React, { useState, useCallback, useRef, useEffect } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Animated,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { BookmarkButton } from "@/components/bookmark-button";
import { DonguraeExplainButton } from "@/components/dongurae-explain-button";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { useBookmarks } from "@/hooks/use-bookmarks";
import {
  getQuestionsBySubject,
  questions as allQuestions,
  Question,
  Subject,
} from "@/data/questions";
import { pickQuestions, shuffle } from "@/lib/question-picker";
import { getBookmarks, getQuestionProgress, submitAnswer } from "@/lib/storage";

const DEFAULT_QUIZ_COUNT = 10;
const SUBJECT_3_QUIZ_COUNT = 30;
const BOOKMARK_QUIZ_MAX = 30;

/** "북마크"는 북마크한 문제만 모아서 푸는 모드 */
type SessionKey = Subject | "전체" | "북마크";

function getQuizCount(subject: SessionKey): number {
  if (subject === "북마크") return BOOKMARK_QUIZ_MAX;
  return subject === "3과목(데이터 분석)" ? SUBJECT_3_QUIZ_COUNT : DEFAULT_QUIZ_COUNT;
}

async function loadSessionQuestions(key: SessionKey): Promise<Question[]> {
  const count = getQuizCount(key);
  if (key === "북마크") {
    const ids = new Set(await getBookmarks());
    return shuffle(allQuestions.filter((q) => ids.has(q.id))).slice(0, count);
  }
  // 풀이 기록을 못 불러오면(네트워크 등) 그냥 무작위로 출제한다.
  const progress = await getQuestionProgress().catch(() => []);
  return pickQuestions(getQuestionsBySubject(key), count, progress);
}

type Phase = "quiz" | "result";

export default function QuizSessionScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();
  const { subject } = useLocalSearchParams<{ subject: string }>();
  const bookmarks = useBookmarks();

  const subjectKey = (subject ?? "전체") as SessionKey;
  const [questions, setQuestions] = useState<Question[] | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [phase, setPhase] = useState<Phase>("quiz");
  const fadeAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    let cancelled = false;
    loadSessionQuestions(subjectKey).then((qs) => {
      if (cancelled) return;
      setQuestions(qs);
      setAnswers(Array(qs.length).fill(null));
    });
    return () => {
      cancelled = true;
    };
  }, [subjectKey]);

  const sessionQuestions = questions ?? [];
  const currentQ = sessionQuestions[currentIndex];
  const isAnswered = selectedOption !== null;
  const isCorrect = selectedOption === currentQ?.answer;
  const correctCount = answers.filter(
    (a, i) => a !== null && a === sessionQuestions[i]?.answer
  ).length;

  const handleSelect = useCallback(
    async (optionIndex: number) => {
      if (isAnswered || !currentQ) return;
      setSelectedOption(optionIndex);

      const correct = optionIndex === currentQ.answer;

      if (Platform.OS !== "web") {
        if (correct) {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        } else {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        }
      }

      setAnswers((prev) => {
        const next = [...prev];
        next[currentIndex] = optionIndex;
        return next;
      });

      try {
        await submitAnswer(currentQ.id, optionIndex);
      } catch (error) {
        console.warn("[Quiz] Failed to save answer:", error);
      }
    },
    [isAnswered, currentIndex, currentQ]
  );

  const handleNext = useCallback(() => {
    if (currentIndex + 1 >= sessionQuestions.length) {
      setPhase("result");
      return;
    }
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0, duration: 120, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 180, useNativeDriver: true }),
    ]).start();
    setCurrentIndex((prev) => prev + 1);
    setSelectedOption(null);
    setShowExplanation(false);
  }, [currentIndex, sessionQuestions.length, fadeAnim]);

  const handleRestart = useCallback(() => {
    router.replace({
      pathname: "/quiz-session",
      params: { subject: subjectKey },
    });
  }, [router, subjectKey]);

  if (questions === null || questions.length === 0) {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <View style={styles.center}>
          {questions === null ? (
            <Text style={[styles.centerDesc, { color: colors.muted }]}>문제를 준비하는 중...</Text>
          ) : (
            <>
              <IconSymbol name="bookmark" size={48} color={colors.muted} />
              <Text style={[styles.centerTitle, { color: colors.foreground }]}>
                북마크한 문제가 없어요
              </Text>
              <Text style={[styles.centerDesc, { color: colors.muted }]}>
                문제를 풀 때 오른쪽 위 북마크 버튼을 눌러 헷갈리는 문제를 모아보세요
              </Text>
              <Pressable
                style={({ pressed }) => [
                  styles.centerBtn,
                  { backgroundColor: colors.primary },
                  pressed && { opacity: 0.85 },
                ]}
                onPress={() => router.back()}
              >
                <Text style={styles.centerBtnText}>돌아가기</Text>
              </Pressable>
            </>
          )}
        </View>
      </ScreenContainer>
    );
  }

  if (phase === "result") {
    return (
      <ResultScreen
        colors={colors}
        correctCount={correctCount}
        total={questions.length}
        subject={subjectKey === "북마크" ? "북마크한 문제" : subjectKey}
        onRestart={handleRestart}
        onHome={() => router.replace("/")}
      />
    );
  }

  const progress = (currentIndex + (isAnswered ? 1 : 0)) / questions.length;

  return (
    <ScreenContainer {...swipeBackHandlers}>
      {/* Top Bar */}
      <View style={styles.topBar}>
        <Pressable
          style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
          onPress={() => router.back()}
        >
          <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
        </Pressable>
        <View style={styles.topCenter}>
          <Text style={[styles.topSubject, { color: colors.primary }]}>
            {subjectKey === "북마크" ? "북마크한 문제" : subjectKey}
          </Text>
          <Text style={[styles.topProgress, { color: colors.muted }]}>
            {currentIndex + 1} / {questions.length}
          </Text>
        </View>
        <BookmarkButton
          bookmarked={bookmarks.isBookmarked(currentQ.id)}
          onPress={() => bookmarks.toggle(currentQ.id)}
        />
      </View>

      {/* Progress Bar */}
      <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
        <Animated.View
          style={[
            styles.progressFill,
            {
              backgroundColor: colors.primary,
              width: `${progress * 100}%`,
            },
          ]}
        />
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          {/* Question */}
          <View
            style={[
              styles.questionCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
            ]}
          >
            <View style={styles.questionBadge}>
              <Text style={[styles.questionBadgeText, { color: colors.primary }]}>
                Q{currentIndex + 1}
              </Text>
            </View>
            <Text style={[styles.questionText, { color: colors.foreground }]}>
              {currentQ.question}
            </Text>
          </View>

          {/* Options */}
          <View style={styles.optionsContainer}>
            {currentQ.options.map((option, idx) => {
              const isSelected = selectedOption === idx;
              const isCorrectOption = idx === currentQ.answer;
              let bgColor = colors.surface;
              let borderColor = colors.border;
              let textColor = colors.foreground;

              if (isAnswered) {
                if (isCorrectOption) {
                  bgColor = colors.success + "18";
                  borderColor = colors.success;
                  textColor = colors.success;
                } else if (isSelected && !isCorrectOption) {
                  bgColor = colors.error + "18";
                  borderColor = colors.error;
                  textColor = colors.error;
                }
              } else if (isSelected) {
                bgColor = colors.primary + "18";
                borderColor = colors.primary;
                textColor = colors.primary;
              }

              return (
                <Pressable
                  key={idx}
                  style={({ pressed }) => [
                    styles.optionBtn,
                    {
                      backgroundColor: bgColor,
                      borderColor: borderColor,
                    },
                    pressed && !isAnswered && { opacity: 0.75 },
                  ]}
                  onPress={() => handleSelect(idx)}
                  disabled={isAnswered}
                >
                  <View
                    style={[
                      styles.optionLabel,
                      { backgroundColor: borderColor + "30" },
                    ]}
                  >
                    <Text style={[styles.optionLabelText, { color: textColor }]}>
                      {["①", "②", "③", "④"][idx]}
                    </Text>
                  </View>
                  <Text
                    style={[styles.optionText, { color: textColor }]}
                    numberOfLines={3}
                  >
                    {option}
                  </Text>
                  {isAnswered && isCorrectOption && (
                    <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                  )}
                  {isAnswered && isSelected && !isCorrectOption && (
                    <IconSymbol name="xmark.circle.fill" size={20} color={colors.error} />
                  )}
                </Pressable>
              );
            })}
          </View>

          {/* Feedback & Explanation */}
          {isAnswered && (
            <View
              style={[
                styles.feedbackCard,
                {
                  backgroundColor: isCorrect
                    ? colors.success + "12"
                    : colors.error + "12",
                  borderColor: isCorrect ? colors.success + "40" : colors.error + "40",
                },
              ]}
            >
              <View style={styles.feedbackHeader}>
                <IconSymbol
                  name={isCorrect ? "checkmark.circle.fill" : "xmark.circle.fill"}
                  size={22}
                  color={isCorrect ? colors.success : colors.error}
                />
                <Text
                  style={[
                    styles.feedbackTitle,
                    { color: isCorrect ? colors.success : colors.error },
                  ]}
                >
                  {isCorrect ? "정답입니다!" : "오답입니다"}
                </Text>
                <Pressable
                  style={({ pressed }) => [
                    styles.explanationToggle,
                    { borderColor: isCorrect ? colors.success : colors.error },
                    pressed && { opacity: 0.7 },
                  ]}
                  onPress={() => setShowExplanation((v) => !v)}
                >
                  <Text
                    style={[
                      styles.explanationToggleText,
                      { color: isCorrect ? colors.success : colors.error },
                    ]}
                  >
                    {showExplanation ? "해설 닫기" : "해설 보기"}
                  </Text>
                </Pressable>
              </View>
              {showExplanation && (
                <Text style={[styles.explanationText, { color: colors.foreground }]}>
                  {currentQ.explanation}
                </Text>
              )}
              {selectedOption !== null && (
                <DonguraeExplainButton
                  key={currentQ.id}
                  question={currentQ}
                  selectedOption={selectedOption}
                />
              )}
            </View>
          )}

          {/* Next Button */}
          {isAnswered && (
            <Pressable
              style={({ pressed }) => [
                styles.nextBtn,
                { backgroundColor: colors.primary },
                pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
              ]}
              onPress={handleNext}
            >
              <Text style={styles.nextBtnText}>
                {currentIndex + 1 >= questions.length ? "결과 보기" : "다음 문제"}
              </Text>
              <IconSymbol
                name={currentIndex + 1 >= questions.length ? "trophy.fill" : "arrow.right"}
                size={18}
                color="#FFFFFF"
              />
            </Pressable>
          )}
        </Animated.View>
      </ScrollView>
    </ScreenContainer>
  );
}

// ─── Result Screen ────────────────────────────────────────────────────────────

function ResultScreen({
  colors,
  correctCount,
  total,
  subject,
  onRestart,
  onHome,
}: {
  colors: ReturnType<typeof useColors>;
  correctCount: number;
  total: number;
  subject: string;
  onRestart: () => void;
  onHome: () => void;
}) {
  const rate = Math.round((correctCount / total) * 100);
  const isPassed = rate >= 60;
  const swipeBackHandlers = useSwipeBack();

  return (
    <ScreenContainer {...swipeBackHandlers}>
      <ScrollView
        contentContainerStyle={styles.resultContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.resultIconWrap}>
          <IconSymbol
            name={isPassed ? "trophy.fill" : "arrow.clockwise"}
            size={56}
            color={isPassed ? colors.warning : colors.primary}
          />
        </View>
        <Text style={[styles.resultTitle, { color: colors.foreground }]}>
          {isPassed ? "훌륭해요! 🎉" : "조금 더 노력해요!"}
        </Text>
        <Text style={[styles.resultSubject, { color: colors.muted }]}>
          {subject} 풀이 완료
        </Text>

        <View style={[styles.resultScoreCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.resultRate, { color: isPassed ? colors.success : colors.primary }]}>
            {rate}%
          </Text>
          <Text style={[styles.resultScore, { color: colors.muted }]}>
            {total}문제 중 {correctCount}문제 정답
          </Text>
          <View style={[styles.resultProgressBg, { backgroundColor: colors.border }]}>
            <View
              style={[
                styles.resultProgressFill,
                {
                  backgroundColor: isPassed ? colors.success : colors.primary,
                  width: `${rate}%`,
                },
              ]}
            />
          </View>
          <Text style={[styles.resultPassText, { color: isPassed ? colors.success : colors.muted }]}>
            {isPassed ? "합격 기준(60%) 달성!" : "합격 기준: 60% 이상"}
          </Text>
        </View>

        <View style={styles.resultBtns}>
          <Pressable
            style={({ pressed }) => [
              styles.resultBtn,
              styles.resultBtnOutline,
              { borderColor: colors.primary },
              pressed && { opacity: 0.75 },
            ]}
            onPress={onHome}
          >
            <IconSymbol name="house.fill" size={18} color={colors.primary} />
            <Text style={[styles.resultBtnText, { color: colors.primary }]}>홈으로</Text>
          </Pressable>
          <Pressable
            style={({ pressed }) => [
              styles.resultBtn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85 },
            ]}
            onPress={onRestart}
          >
            <IconSymbol name="arrow.clockwise" size={18} color="#FFFFFF" />
            <Text style={[styles.resultBtnText, { color: "#FFFFFF" }]}>다시 풀기</Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    padding: 24,
  },
  centerTitle: { fontSize: 20, fontWeight: "700" },
  centerDesc: { fontSize: 14, textAlign: "center", lineHeight: 22 },
  centerBtn: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: 8,
  },
  centerBtnText: { color: "#FFFFFF", fontWeight: "700", fontSize: 15 },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  backBtn: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  topCenter: {
    flex: 1,
    alignItems: "center",
  },
  topSubject: {
    fontSize: 14,
    fontWeight: "700",
  },
  topProgress: {
    fontSize: 12,
    marginTop: 1,
  },
  progressBg: {
    height: 4,
    marginHorizontal: 0,
  },
  progressFill: {
    height: 4,
    borderRadius: 2,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  questionCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    marginBottom: 16,
  },
  questionBadge: {
    marginBottom: 10,
  },
  questionBadgeText: {
    fontSize: 13,
    fontWeight: "700",
  },
  questionText: {
    fontSize: 16,
    fontWeight: "600",
    lineHeight: 26,
  },
  optionsContainer: {
    gap: 10,
    marginBottom: 16,
  },
  optionBtn: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1.5,
    padding: 14,
    gap: 12,
  },
  optionLabel: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  optionLabelText: {
    fontSize: 14,
    fontWeight: "700",
  },
  optionText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 22,
    fontWeight: "500",
  },
  feedbackCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 16,
    gap: 10,
  },
  feedbackHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  feedbackTitle: {
    fontSize: 15,
    fontWeight: "700",
    flex: 1,
  },
  explanationToggle: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
  },
  explanationToggleText: {
    fontSize: 12,
    fontWeight: "600",
  },
  explanationText: {
    fontSize: 13,
    lineHeight: 22,
  },
  nextBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 14,
    paddingVertical: 16,
    marginTop: 4,
  },
  nextBtnText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  // Result
  resultContent: {
    padding: 24,
    alignItems: "center",
    paddingBottom: 48,
  },
  resultIconWrap: {
    marginTop: 32,
    marginBottom: 16,
  },
  resultTitle: {
    fontSize: 26,
    fontWeight: "800",
    letterSpacing: -0.5,
    marginBottom: 4,
  },
  resultSubject: {
    fontSize: 14,
    marginBottom: 28,
  },
  resultScoreCard: {
    width: "100%",
    borderRadius: 18,
    borderWidth: 1,
    padding: 24,
    alignItems: "center",
    gap: 8,
    marginBottom: 32,
  },
  resultRate: {
    fontSize: 52,
    fontWeight: "900",
    letterSpacing: -2,
  },
  resultScore: {
    fontSize: 15,
  },
  resultProgressBg: {
    width: "100%",
    height: 8,
    borderRadius: 4,
    overflow: "hidden",
    marginTop: 8,
  },
  resultProgressFill: {
    height: 8,
    borderRadius: 4,
  },
  resultPassText: {
    fontSize: 13,
    fontWeight: "600",
    marginTop: 4,
  },
  resultBtns: {
    flexDirection: "row",
    gap: 12,
    width: "100%",
  },
  resultBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 15,
    borderRadius: 14,
  },
  resultBtnOutline: {
    borderWidth: 1.5,
    backgroundColor: "transparent",
  },
  resultBtnText: {
    fontSize: 15,
    fontWeight: "700",
  },
});
