import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  TextInput,
  Switch,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { getExamDate, setExamDate } from "@/lib/storage";
import { isValidDateStr } from "@/lib/kst-date";
import {
  DEFAULT_REMINDER,
  getReminderSettings,
  remindersSupported,
  ReminderSettings,
  saveReminderSettings,
} from "@/lib/study-reminder";

const pad = (n: number) => String(n).padStart(2, "0");

export default function StudySettingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();

  const [examDateInput, setExamDateInput] = useState("");
  const [reminder, setReminder] = useState<ReminderSettings>(DEFAULT_REMINDER);
  const [message, setMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getExamDate()
      .then((d) => setExamDateInput(d ?? ""))
      .catch(() => {});
    getReminderSettings().then(setReminder);
  }, []);

  const adjustTime = (field: "hour" | "minute", delta: number) => {
    setReminder((prev) => {
      const max = field === "hour" ? 24 : 60;
      return { ...prev, [field]: (prev[field] + delta + max) % max };
    });
  };

  const handleSave = async () => {
    const trimmed = examDateInput.trim();
    if (trimmed && !isValidDateStr(trimmed)) {
      setMessage({ text: "시험일은 2026-11-15 같은 형식으로 입력해주세요.", isError: true });
      return;
    }
    setSaving(true);
    setMessage(null);
    try {
      await setExamDate(trimmed || null);
      const ok = await saveReminderSettings(reminder);
      if (!ok) {
        setReminder((prev) => ({ ...prev, enabled: false }));
        setMessage({
          text: "시험일은 저장했지만, 알림 권한이 없어 알림을 켜지 못했어요. 기기 설정에서 알림을 허용해주세요.",
          isError: true,
        });
        return;
      }
      router.back();
    } catch (error) {
      console.warn("[StudySettings] save failed:", error);
      setMessage({ text: "저장하지 못했어요. 잠시 후 다시 시도해주세요.", isError: true });
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScreenContainer {...swipeBackHandlers}>
      <View style={styles.topBar}>
        <Pressable
          style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
          onPress={() => router.back()}
        >
          <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.topTitle, { color: colors.foreground }]}>시험일 · 학습 알림</Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Exam Date */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.cardHeader}>
            <IconSymbol name="calendar" size={20} color={colors.primary} />
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>시험일</Text>
          </View>
          <Text style={[styles.cardDesc, { color: colors.muted }]}>
            홈 화면에 D-day가 표시돼요. 비워두면 D-day를 숨겨요.
          </Text>
          <TextInput
            value={examDateInput}
            onChangeText={setExamDateInput}
            placeholder="예: 2026-11-15"
            placeholderTextColor={colors.muted}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="numbers-and-punctuation"
            maxLength={10}
            style={[
              styles.input,
              { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background },
            ]}
          />
        </View>

        {/* Reminder */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.cardHeader}>
            <IconSymbol name="bell.fill" size={20} color={colors.warning} />
            <Text style={[styles.cardTitle, { color: colors.foreground, flex: 1 }]}>매일 학습 알림</Text>
            <Switch
              value={reminder.enabled}
              onValueChange={(enabled) => setReminder((prev) => ({ ...prev, enabled }))}
              disabled={!remindersSupported}
            />
          </View>
          <Text style={[styles.cardDesc, { color: colors.muted }]}>
            {remindersSupported
              ? "정해진 시간에 \"오늘 10문제 풀어요\" 알림을 보내드려요."
              : "학습 알림은 휴대폰 앱에서만 설정할 수 있어요."}
          </Text>

          {remindersSupported && reminder.enabled && (
            <View style={styles.timeRow}>
              {(["hour", "minute"] as const).map((field) => (
                <View key={field} style={styles.timeUnit}>
                  <Pressable
                    style={({ pressed }) => [styles.stepBtn, { borderColor: colors.border }, pressed && { opacity: 0.6 }]}
                    onPress={() => adjustTime(field, field === "hour" ? -1 : -10)}
                  >
                    <Text style={[styles.stepText, { color: colors.foreground }]}>−</Text>
                  </Pressable>
                  <Text style={[styles.timeText, { color: colors.foreground }]}>
                    {pad(reminder[field])}
                    <Text style={[styles.timeUnitLabel, { color: colors.muted }]}>
                      {field === "hour" ? "시" : "분"}
                    </Text>
                  </Text>
                  <Pressable
                    style={({ pressed }) => [styles.stepBtn, { borderColor: colors.border }, pressed && { opacity: 0.6 }]}
                    onPress={() => adjustTime(field, field === "hour" ? 1 : 10)}
                  >
                    <Text style={[styles.stepText, { color: colors.foreground }]}>+</Text>
                  </Pressable>
                </View>
              ))}
            </View>
          )}
        </View>

        {message && (
          <Text style={[styles.message, { color: message.isError ? colors.error : colors.success }]}>
            {message.text}
          </Text>
        )}

        <Pressable
          style={({ pressed }) => [
            styles.saveBtn,
            { backgroundColor: colors.primary },
            (pressed || saving) && { opacity: 0.85 },
          ]}
          onPress={handleSave}
          disabled={saving}
        >
          <Text style={styles.saveBtnText}>{saving ? "저장 중..." : "저장"}</Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  backBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  topTitle: { flex: 1, textAlign: "center", fontSize: 16, fontWeight: "700" },
  content: { padding: 20, gap: 16, paddingBottom: 40 },
  card: { borderRadius: 16, borderWidth: 1, padding: 16, gap: 10 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  cardTitle: { fontSize: 16, fontWeight: "700" },
  cardDesc: { fontSize: 13, lineHeight: 20 },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
  },
  timeRow: { flexDirection: "row", justifyContent: "center", gap: 24, marginTop: 4 },
  timeUnit: { flexDirection: "row", alignItems: "center", gap: 10 },
  stepBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  stepText: { fontSize: 18, fontWeight: "700" },
  timeText: { fontSize: 24, fontWeight: "800", fontVariant: ["tabular-nums"] },
  timeUnitLabel: { fontSize: 13, fontWeight: "600" },
  message: { fontSize: 13, lineHeight: 20, textAlign: "center" },
  saveBtn: { borderRadius: 14, paddingVertical: 16, alignItems: "center" },
  saveBtnText: { color: "#FFFFFF", fontSize: 16, fontWeight: "700" },
});
