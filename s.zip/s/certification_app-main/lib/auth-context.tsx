import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { trpcVanilla } from "@/lib/trpc";
import { getAuthToken, setAuthToken, clearAuthToken } from "@/lib/auth-token";

export interface AuthUser {
  id: string;
  email: string;
  nickname: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, nickname: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const token = await getAuthToken();
      if (!token) {
        setIsLoading(false);
        return;
      }
      try {
        const me = await trpcVanilla.auth.me.query();
        setUser(me);
      } catch {
        await clearAuthToken();
      } finally {
        setIsLoading(false);
      }
    })();
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const { token, user: loggedInUser } = await trpcVanilla.auth.login.mutate({ email, password });
    await setAuthToken(token);
    setUser(loggedInUser);
  }, []);

  const signup = useCallback(async (email: string, nickname: string, password: string) => {
    const { token, user: newUser } = await trpcVanilla.auth.signup.mutate({ email, nickname, password });
    await setAuthToken(token);
    setUser(newUser);
  }, []);

  const logout = useCallback(async () => {
    await clearAuthToken();
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, isLoading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}
