import type { Question } from "@/data/questions";

/** 문제 하나에 대한 누적 풀이 기록 (server progress.getQuestionProgress) */
export interface QuestionProgress {
  questionId: string;
  attempts: number;
  correct: number;
  lastCorrect: boolean;
  lastAt: number;
}

export function shuffle<T>(items: readonly T[]): T[] {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

/**
 * 안 푼 문제 → 마지막에 틀린 문제 → 맞힌 문제(오래전에 푼 순) 순서로 우선 출제한다.
 * 뽑은 뒤에는 순서를 섞어서, 세션 안에서 우선순위가 티 나지 않게 한다.
 */
export function pickQuestions(
  pool: readonly Question[],
  count: number,
  progress: readonly QuestionProgress[]
): Question[] {
  const byId = new Map(progress.map((p) => [p.questionId, p]));
  const unseen: Question[] = [];
  const weak: Question[] = [];
  const solved: Question[] = [];

  for (const q of pool) {
    const p = byId.get(q.id);
    if (!p) unseen.push(q);
    else if (!p.lastCorrect) weak.push(q);
    else solved.push(q);
  }

  const solvedOldestFirst = shuffle(solved).sort(
    (a, b) => byId.get(a.id)!.lastAt - byId.get(b.id)!.lastAt
  );
  const ordered = [...shuffle(unseen), ...shuffle(weak), ...solvedOldestFirst];
  return shuffle(ordered.slice(0, Math.min(count, ordered.length)));
}
