import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";

/**
 * 매일 정해진 시간에 "오늘 문제 풀기" 로컬 알림을 보낸다.
 * 알림은 기기에 예약되는 것이라 설정도 기기별로 AsyncStorage에 저장한다
 * (시험일은 계정에 저장 - server settings 라우터).
 * 웹은 expo-notifications 예약 알림을 지원하지 않는다.
 */
const STORAGE_KEY = "study-reminder";
const CHANNEL_ID = "study-reminder";

export interface ReminderSettings {
  enabled: boolean;
  hour: number;
  minute: number;
}

export const DEFAULT_REMINDER: ReminderSettings = { enabled: false, hour: 21, minute: 0 };

export const remindersSupported = Platform.OS !== "web";

export async function getReminderSettings(): Promise<ReminderSettings> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULT_REMINDER, ...JSON.parse(raw) } : DEFAULT_REMINDER;
  } catch {
    return DEFAULT_REMINDER;
  }
}

/**
 * 설정을 저장하고 알림을 다시 예약한다. 켜려는데 알림 권한이 거부되면 false.
 */
export async function saveReminderSettings(settings: ReminderSettings): Promise<boolean> {
  if (remindersSupported) {
    await Notifications.cancelAllScheduledNotificationsAsync();

    if (settings.enabled) {
      const { granted } = await Notifications.requestPermissionsAsync();
      if (!granted) return false;

      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
          name: "학습 알림",
          importance: Notifications.AndroidImportance.DEFAULT,
        });
      }

      await Notifications.scheduleNotificationAsync({
        content: {
          title: "오늘도 ADsP 한 세트! 📚",
          body: "10문제만 풀고 연속 학습 기록을 이어가요 🔥",
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DAILY,
          hour: settings.hour,
          minute: settings.minute,
          channelId: CHANNEL_ID,
        },
      });
    }
  }

  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  return true;
}

/** 앱이 켜져 있을 때 온 알림도 배너로 보여준다. 루트 레이아웃에서 한 번 호출. */
export function configureNotificationHandler(): void {
  if (!remindersSupported) return;
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowBanner: true,
      shouldShowList: true,
      shouldPlaySound: false,
      shouldSetBadge: false,
    }),
  });
}
