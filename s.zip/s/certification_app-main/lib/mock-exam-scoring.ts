import { SUBJECTS, type Question, type Subject } from "@/data/questions";

export const SUBJECT_PASS_RATE = 0.4; // 과목별 40% 이상
export const OVERALL_PASS_RATE = 0.6; // 전체 60% 이상

export interface SubjectScore {
  total: number;
  correct: number;
}

export interface MockExamScore {
  total: number;
  correct: number;
  bySubject: Record<Subject, SubjectScore>;
  passed: boolean;
}

export function subjectPassed(score: SubjectScore): boolean {
  return score.total > 0 && score.correct / score.total >= SUBJECT_PASS_RATE;
}

/** 모의고사 채점. 풀지 않은 문제(selected === null)는 오답으로 친다. */
export function scoreMockExam(
  items: { question: Question; selected: number | null }[]
): MockExamScore {
  const bySubject = Object.fromEntries(
    SUBJECTS.map((s) => [s, { total: 0, correct: 0 }])
  ) as Record<Subject, SubjectScore>;

  for (const { question, selected } of items) {
    const s = bySubject[question.subject];
    s.total += 1;
    if (selected === question.answer) s.correct += 1;
  }

  const total = items.length;
  const correct = SUBJECTS.reduce((sum, s) => sum + bySubject[s].correct, 0);
  const passed =
    total > 0 &&
    correct / total >= OVERALL_PASS_RATE &&
    SUBJECTS.every((s) => bySubject[s].total === 0 || subjectPassed(bySubject[s]));

  return { total, correct, bySubject, passed };
}
