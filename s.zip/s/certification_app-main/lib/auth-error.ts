/**
 * 로그인/회원가입 실패 시 사용자에게 보여줄 메시지를 만든다.
 *
 * 서버의 zod 입력 검증이 실패하면 tRPC는 이슈 배열을 JSON 문자열로 그대로
 * 던지는데(예: `[{"code":"invalid_format","path":["email"],...}]`), 이걸
 * 그대로 화면에 띄우면 사용자에게는 의미 없는 원본 JSON 덩어리로 보인다.
 * 여기서 그 형태를 감지해서 필드별로 친절한 한국어 메시지로 바꾼다.
 */
export function getFriendlyAuthErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : "";

  if (!message) {
    return "요청 처리 중 오류가 발생했습니다.";
  }

  if (/fetch|network/i.test(message)) {
    return "서버에 연결할 수 없습니다. 네트워크 상태를 확인해주세요.";
  }

  if (message.trim().startsWith("[")) {
    try {
      const issues = JSON.parse(message) as Array<{ path?: string[] }>;
      const field = issues[0]?.path?.[0];
      if (field === "email") return "올바른 이메일 형식을 입력해주세요.";
      if (field === "password") return "비밀번호 형식을 확인해주세요.";
      if (field === "nickname") return "닉네임을 확인해주세요.";
    } catch {
      // JSON 파싱 실패 시 아래 기본 메시지로 대체한다.
    }
    return "입력값을 다시 확인해주세요.";
  }

  return message;
}
