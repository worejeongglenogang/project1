import React, { useEffect, useRef } from "react";
import { View, StyleSheet, Animated } from "react-native";
import { Image } from "expo-image";

export interface CharacterAnimatorProps {
  /**
   * 입 모양 상태 (0-1: 닫힘 ~ 완전 열림)
   */
  mouthOpen: number;
  /**
   * 제스처 타입
   */
  gesture?: "idle" | "thinking" | "explaining" | "happy" | "confused";
  /**
   * 크기 (픽셀)
   */
  size?: number;
  /**
   * 캐릭터 이미지 URI
   */
  characterImageUri?: string;
}

/**
 * 동그래 캐릭터 애니메이터
 * 입 모양과 제스처를 애니메이션으로 표현
 */
export function CharacterAnimator({
  mouthOpen,
  gesture = "idle",
  size = 200,
  characterImageUri,
}: CharacterAnimatorProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(1)).current;

  // 제스처 애니메이션
  useEffect(() => {
    switch (gesture) {
      case "thinking":
        Animated.loop(
          Animated.sequence([
            Animated.timing(rotateAnim, {
              toValue: -5,
              duration: 500,
              useNativeDriver: true,
            }),
            Animated.timing(rotateAnim, {
              toValue: 5,
              duration: 500,
              useNativeDriver: true,
            }),
            Animated.timing(rotateAnim, {
              toValue: 0,
              duration: 500,
              useNativeDriver: true,
            }),
          ])
        ).start();
        break;

      case "happy":
        Animated.sequence([
          Animated.timing(scaleAnim, {
            toValue: 1.1,
            duration: 300,
            useNativeDriver: true,
          }),
          Animated.timing(scaleAnim, {
            toValue: 1,
            duration: 300,
            useNativeDriver: true,
          }),
        ]).start();
        break;

      case "confused":
        Animated.loop(
          Animated.sequence([
            Animated.timing(rotateAnim, {
              toValue: -3,
              duration: 400,
              useNativeDriver: true,
            }),
            Animated.timing(rotateAnim, {
              toValue: 3,
              duration: 400,
              useNativeDriver: true,
            }),
            Animated.timing(rotateAnim, {
              toValue: 0,
              duration: 400,
              useNativeDriver: true,
            }),
          ])
        ).start();
        break;

      case "explaining":
        // 설명 중에는 가벼운 바운스
        Animated.loop(
          Animated.sequence([
            Animated.timing(scaleAnim, {
              toValue: 1.02,
              duration: 600,
              useNativeDriver: true,
            }),
            Animated.timing(scaleAnim, {
              toValue: 1,
              duration: 600,
              useNativeDriver: true,
            }),
          ])
        ).start();
        break;

      default:
        // idle: 제스처 없음
        rotateAnim.setValue(0);
        scaleAnim.setValue(1);
        break;
    }

    return () => {
      rotateAnim.setValue(0);
      scaleAnim.setValue(1);
    };
  }, [gesture, rotateAnim, scaleAnim]);

  // 입 모양 계산 (mouthOpen: 0-1)
  const mouthHeight = Math.max(2, mouthOpen * 20);
  const mouthBorderRadius = mouthOpen > 0.5 ? 10 : 5;

  return (
    <Animated.View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          transform: [
            { scale: scaleAnim },
            {
              rotateZ: rotateAnim.interpolate({
                inputRange: [-10, 0, 10],
                outputRange: ["-10deg", "0deg", "10deg"],
              }),
            },
          ],
        },
      ]}
    >
      {/* 캐릭터 기본 이미지 */}
      {characterImageUri ? (
        <Image
          source={{ uri: characterImageUri }}
          style={[styles.characterImage, { width: size, height: size }]}
          contentFit="contain"
        />
      ) : (
        <View style={[styles.characterPlaceholder, { width: size, height: size }]} />
      )}

      {/* 입 모양 오버레이 */}
      <View
        style={[
          styles.mouthOverlay,
          {
            width: size * 0.15,
            height: mouthHeight,
            borderRadius: mouthBorderRadius,
            bottom: size * 0.15,
            left: size * 0.425,
            opacity: mouthOpen,
          },
        ]}
      />

      {/* 눈 깜빡임 (선택사항) */}
      <Animated.View
        style={[
          styles.eyeBlink,
          {
            opacity: opacityAnim,
          },
        ]}
      />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "relative",
    justifyContent: "center",
    alignItems: "center",
  },
  characterImage: {
    position: "absolute",
  },
  characterPlaceholder: {
    backgroundColor: "#E0E7FF",
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  mouthOverlay: {
    position: "absolute",
    backgroundColor: "#FF6B9D",
    zIndex: 10,
  },
  eyeBlink: {
    position: "absolute",
    top: "35%",
    left: "30%",
    width: 15,
    height: 15,
    borderRadius: 7.5,
    backgroundColor: "rgba(0, 0, 0, 0.3)",
  },
});
