import type { BottomTabBarButtonProps } from "expo-router/build/react-navigation/bottom-tabs/types";
import { Platform, Pressable } from "react-native";
import * as Haptics from "expo-haptics";

// Plain Pressable instead of @react-navigation/elements' PlatformPressable:
// that component reads theme via @react-navigation/core's useTheme(), which
// throws because expo-router (SDK 56+) no longer renders a NavigationContainer.
export function HapticTab({ style, onPress, onPressIn, children, ref: _ref, ...rest }: BottomTabBarButtonProps) {
  return (
    <Pressable
      {...rest}
      style={style}
      onPress={onPress}
      android_ripple={Platform.OS === "android" ? { borderless: true, foreground: true } : undefined}
      onPressIn={(ev) => {
        if (process.env.EXPO_OS === "ios") {
          // Add a soft haptic feedback when pressing down on the tabs.
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }
        onPressIn?.(ev);
      }}
    >
      {children}
    </Pressable>
  );
}
