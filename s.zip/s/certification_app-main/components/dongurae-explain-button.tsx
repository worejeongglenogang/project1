import React, { useState } from "react";
import { ActivityIndicator, Modal, Pressable, StyleSheet, Text } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { DmuExplanationPlayer } from "@/components/dmu-explanation-player";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import type { Question } from "@/data/questions";

/**
 * 문제 풀이 화면용 "동그래 해설 듣기" 버튼 + 재생 모달.
 * 틀렸으면 오답노트처럼 학생이 고른 오답 기준의 맞춤 해설(Gemini)을 만들고,
 * 실패하거나 맞힌 경우엔 문제은행의 기본 해설을 읽어준다(쿼터를 아끼기 위해).
 */
export function DonguraeExplainButton({
  question,
  selectedOption,
}: {
  question: Question;
  selectedOption: number;
}) {
  const colors = useColors();
  const [explanation, setExplanation] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const generateMutation = trpc.explain.generateForWrongAnswer.useMutation();

  const isCorrect = selectedOption === question.answer;

  const handlePress = async () => {
    if (loading) return;
    if (isCorrect) {
      setExplanation(question.explanation);
      return;
    }
    setLoading(true);
    try {
      const result = await generateMutation.mutateAsync({
        question: question.question,
        options: question.options,
        selectedOption,
        correctOption: question.answer,
      });
      setExplanation(result.explanation);
    } catch (error) {
      console.warn("[Dongurae] Falling back to static explanation:", error);
      setExplanation(question.explanation);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Pressable
        style={({ pressed }) => [
          styles.btn,
          { backgroundColor: colors.primary + "12", borderColor: colors.primary + "40" },
          (pressed || loading) && { opacity: 0.75 },
        ]}
        onPress={handlePress}
        disabled={loading}
      >
        {loading ? (
          <>
            <ActivityIndicator size="small" color={colors.primary} />
            <Text style={[styles.btnText, { color: colors.primary }]}>맞춤 해설 생성 중...</Text>
          </>
        ) : (
          <>
            <IconSymbol name="speaker.wave.2.fill" size={14} color={colors.primary} />
            <Text style={[styles.btnText, { color: colors.primary }]}>동그래 해설 듣기</Text>
          </>
        )}
      </Pressable>

      {/* Modal은 앱 루트의 GestureHandlerRootView 밖에 렌더링되므로 안에 하나 더 둔다 (wrong.tsx 참고). */}
      <Modal
        visible={explanation !== null}
        animationType="slide"
        onRequestClose={() => setExplanation(null)}
      >
        <GestureHandlerRootView style={{ flex: 1 }}>
          <ScreenContainer>
            <DmuExplanationPlayer
              explanation={explanation ?? ""}
              referenceExplanation={question.explanation}
              onClose={() => setExplanation(null)}
            />
          </ScreenContainer>
        </GestureHandlerRootView>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  btn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderRadius: 10,
    borderWidth: 1,
    paddingVertical: 10,
    marginTop: 2,
  },
  btnText: {
    fontSize: 13,
    fontWeight: "700",
  },
});
