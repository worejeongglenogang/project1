import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Animated,
  Platform,
  Easing,
} from "react-native";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import { Image } from "expo-image";
import * as Speech from "expo-speech";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import {
  splitIntoSentenceSegments,
  findSegmentForCharIndex,
  type SentenceSegment,
} from "@/lib/ai-service";

const DONGGURAECHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

// expo-speech가 ios/android에서 발화 위치(onBoundary)를 얼마나 빨리 보내는지는
// 단말/엔진마다 다르다. 이 시간 안에 첫 이벤트가 안 오면 "이 기기는 onBoundary를
// 지원하지 않는다"고 보고 추정 시간 기반 폴백으로 전환한다.
const BOUNDARY_GRACE_MS = 600;
const SPEECH_RATE = Platform.OS === "ios" ? 0.58 : 1.1;

export interface DmuExplanationPlayerProps {
  /** 칠판에서 자막으로 보여주고 TTS로 읽어주는 해설 (오답 맞춤 해설, 실패 시 기본 해설로 대체됨) */
  explanation: string;
  /** 하단 "해설 내용" 박스에 표시할 텍스트. 생략하면 explanation을 그대로 보여준다
   *  (오답노트에서는 항상 기본 해설을 넘겨서, 맞춤 해설과 별개로 원문 해설도 읽을 수 있게 한다). */
  referenceExplanation?: string;
  onClose: () => void;
  characterSize?: number;
}

/**
 * 텍스트 길이 기반으로 대략적인 발화 시간을 추정한다 (폴백 전용).
 * 실제 재생 중에는 onBoundary가 정확한 위치를 알려주므로 이 추정치는
 * onBoundary를 못 받는 기기에서만 쓰인다.
 */
function estimateSpeechDurationSeconds(text: string, rate: number): number {
  const syllablesPerSecond = 6; // 평균적인 한국어 발화 속도 근사치
  const base = text.length / syllablesPerSecond;
  const adjusted = base / rate;
  return Math.max(2, Math.min(180, adjusted));
}

type FallbackWindow = SentenceSegment & { startTime: number; endTime: number };

export function DmuExplanationPlayer({
  explanation,
  referenceExplanation,
  onClose,
  characterSize = 90,
}: DmuExplanationPlayerProps) {
  const colors = useColors();

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSegment, setCurrentSegment] = useState<SentenceSegment | null>(null);
  const [progress, setProgress] = useState(0);

  const bodyBounce = useRef(new Animated.Value(0)).current;
  const subtitleOpacity = useRef(new Animated.Value(1)).current;
  // 말할 때마다(단어 경계마다) 짧게 통통 튀는 "입 모양" 대용 펄스
  const scaleAnim = useRef(new Animated.Value(1)).current;
  // 해설 중에만 쓰는 "생생하게 설명하는" 느낌의 추가 모션들
  const wiggleAnim = useRef(new Animated.Value(0)).current;
  const pointerAnim = useRef(new Animated.Value(0)).current;
  // 아래로 스와이프해서 닫을 때 화면을 손가락 따라 살짝 끌어내리는 용도
  const swipeTranslateY = useRef(new Animated.Value(0)).current;

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const bodyAnimRef = useRef<Animated.CompositeAnimation | null>(null);
  const talkPulseRef = useRef<Animated.CompositeAnimation | null>(null);
  const wiggleAnimRef = useRef<Animated.CompositeAnimation | null>(null);
  const pointerAnimRef = useRef<Animated.CompositeAnimation | null>(null);
  const startTimeRef = useRef<number>(0);
  const isPlayingRef = useRef(false);
  const hasBoundaryFiredRef = useRef(false);
  const fallbackModeRef = useRef(false);
  const lastFallbackPulseMsRef = useRef(0);

  // 실제로 화면에 표시/발화되는 정규화된 텍스트. onBoundary의 charIndex는
  // 이 문자열 기준 위치이므로, 세그먼트 분할도 반드시 같은 문자열로 해야 한다.
  const cleanText = useMemo(() => explanation.replace(/\s+/g, " ").trim(), [explanation]);

  const segments = useMemo(() => splitIntoSentenceSegments(cleanText), [cleanText]);

  const estimatedDurationSec = useMemo(
    () => estimateSpeechDurationSeconds(cleanText, SPEECH_RATE),
    [cleanText]
  );

  // onBoundary를 지원하지 않는 기기를 위한 폴백 시간표: 문장 길이에 비례해서
  // 추정 총 발화시간을 배분한다 (예전처럼 "N개 문장에 30초 균등분할"이 아님).
  const fallbackWindows = useMemo<FallbackWindow[]>(() => {
    const totalChars = segments.reduce((sum, seg) => sum + (seg.endChar - seg.startChar), 0);
    let cursor = 0;
    return segments.map((seg) => {
      const segChars = seg.endChar - seg.startChar;
      const duration = totalChars > 0 ? (segChars / totalChars) * estimatedDurationSec : 0;
      const startTime = cursor;
      cursor += duration;
      return { ...seg, startTime, endTime: cursor };
    });
  }, [segments, estimatedDurationSec]);

  useEffect(() => {
    if (!currentSegment) return;
    Animated.sequence([
      Animated.timing(subtitleOpacity, {
        toValue: 0,
        duration: 60,
        useNativeDriver: true,
      }),
      Animated.timing(subtitleOpacity, {
        toValue: 1,
        duration: 120,
        useNativeDriver: true,
      }),
    ]).start();
  }, [currentSegment, subtitleOpacity]);

  // 진폭/시간에 ±지터를 줘서, 완벽히 똑같은 주기로 반복되는 "로봇 같은" 느낌을
  // 없앤다. 사람의 움직임은 매번 조금씩 다르다는 점을 흉내낸 것.
  const withJitter = (base: number, ratio: number) => base * (1 - ratio + Math.random() * ratio * 2);

  // 평소(대기)에는 잔잔하게 숨쉬듯, 해설 중에는 더 크고 빠르게 - 진폭/속도만
  // 바꿔서 같은 bodyBounce 값을 재사용한다 (전환 시 이전 사이클을 멈추고 새로
  // 시작한다). Animated.loop 대신 매 사이클마다 스스로 다시 예약하는 방식이라
  // 사이클마다 진폭/시간을 살짝씩 다르게 줄 수 있다.
  const runBodyBounceLoop = useCallback(
    (amplitude: number, durationMs: number) => {
      bodyAnimRef.current?.stop();
      bodyBounce.setValue(0);

      const cycle = () => {
        const amp = withJitter(amplitude, 0.18);
        const dur = withJitter(durationMs, 0.18);
        const seq = Animated.sequence([
          Animated.timing(bodyBounce, {
            toValue: -amp,
            duration: dur,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
          Animated.timing(bodyBounce, {
            toValue: 0,
            duration: dur,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
        ]);
        bodyAnimRef.current = seq;
        seq.start(({ finished }) => {
          if (finished) cycle();
        });
      };
      cycle();
    },
    [bodyBounce]
  );

  // 대기 상태에서도 캐릭터가 완전히 멈춰있지 않도록, 마운트되면 바로 잔잔한
  // 숨쉬기 루프를 시작한다.
  useEffect(() => {
    runBodyBounceLoop(4, 900);
  }, [runBodyBounceLoop]);

  // 단어 경계(onBoundary)마다 짧게 통통 튀며 "말하는" 인상을 준다. 별도의
  // 입 모양 이미지가 없어서 정확한 립싱크는 아니지만, 고정 주기 반복 대신
  // 실제 발화 타이밍에 맞춰 튀기 때문에 훨씬 자연스럽게 느껴진다.
  const triggerTalkPulse = useCallback(() => {
    talkPulseRef.current?.stop();
    const seq = Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 1.05 + Math.random() * 0.03,
        duration: 90,
        easing: Easing.out(Easing.quad),
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 130,
        easing: Easing.in(Easing.quad),
        useNativeDriver: true,
      }),
    ]);
    talkPulseRef.current = seq;
    seq.start();
  }, [scaleAnim]);

  const startAnimations = useCallback(() => {
    // 해설 중에는 더 크고 활발하게 - 실제로 설명하는 듯한 인상을 준다.
    // (입 모양 펄스는 더 이상 여기서 고정 주기로 돌리지 않고, onBoundary/폴백
    // 타이머에서 실제 발화 타이밍에 맞춰 triggerTalkPulse()를 호출한다.)
    runBodyBounceLoop(9, 320);

    // 고개를 갸웃거리듯 좌우로 살짝 흔들어 "설명하고 있다"는 느낌을 더한다.
    // bodyBounce와 마찬가지로 매 사이클 진폭/시간에 지터를 줘서 기계적으로
    // 반복되는 느낌을 없앤다.
    const wiggleCycle = () => {
      const seq = Animated.sequence([
        Animated.timing(wiggleAnim, {
          toValue: withJitter(1, 0.2),
          duration: withJitter(420, 0.25),
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(wiggleAnim, {
          toValue: withJitter(-1, 0.2),
          duration: withJitter(840, 0.25),
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(wiggleAnim, {
          toValue: 0,
          duration: withJitter(420, 0.25),
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]);
      wiggleAnimRef.current = seq;
      seq.start(({ finished }) => {
        if (finished) wiggleCycle();
      });
    };
    wiggleCycle();

    // 칠판을 톡톡 짚어가며 설명하는 듯한 포인터(분필) 모션.
    const pointerCycle = () => {
      const seq = Animated.sequence([
        Animated.timing(pointerAnim, {
          toValue: 1,
          duration: 260,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(pointerAnim, {
          toValue: 0,
          duration: 260,
          easing: Easing.in(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.delay(withJitter(500, 0.3)),
      ]);
      pointerAnimRef.current = seq;
      seq.start(({ finished }) => {
        if (finished) pointerCycle();
      });
    };
    pointerCycle();
  }, [runBodyBounceLoop, wiggleAnim, pointerAnim]);

  const stopAnimations = useCallback(() => {
    talkPulseRef.current?.stop();
    talkPulseRef.current = null;
    scaleAnim.setValue(1);

    wiggleAnimRef.current?.stop();
    wiggleAnimRef.current = null;
    wiggleAnim.setValue(0);

    pointerAnimRef.current?.stop();
    pointerAnimRef.current = null;
    pointerAnim.setValue(0);

    // 완전히 멈추지 않고 잔잔한 대기 애니메이션으로 되돌아간다.
    runBodyBounceLoop(4, 900);
  }, [scaleAnim, wiggleAnim, pointerAnim, runBodyBounceLoop]);

  const stopAll = useCallback(() => {
    isPlayingRef.current = false;
    setIsPlaying(false);
    Speech.stop();
    stopAnimations();
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setProgress(0);
    setCurrentSegment(null);
  }, [stopAnimations]);

  const handleClose = useCallback(() => {
    stopAll();
    onClose();
  }, [stopAll, onClose]);

  // 화면을 아래로 스와이프하면 손가락을 따라 끌려 내려가다가, 일정 거리
  // 이상 놓으면 닫히고 아니면 원위치로 튕겨 돌아온다.
  // PanResponder(RN 구식 responder 시스템) 대신 react-native-gesture-handler를
  // 쓰는 이유: 이 화면은 RN Modal 안에서 열리는데, Modal은 별도 네이티브 창에
  // 렌더링되고 그 안에 GestureHandlerRootView를 다시 둬야 하다 보니, 같은
  // gesture-handler 계열로 통일해야 터치가 안정적으로 잡힌다.
  const swipeGesture = Gesture.Pan()
    .activeOffsetY([12, 999])
    .failOffsetX([-25, 25])
    .runOnJS(true)
    .onUpdate((e) => {
      if (e.translationY > 0) {
        swipeTranslateY.setValue(e.translationY);
      }
    })
    .onEnd((e) => {
      if (e.translationY > 120 || e.velocityY > 800) {
        Animated.timing(swipeTranslateY, {
          toValue: 600,
          duration: 200,
          useNativeDriver: true,
        }).start(() => {
          swipeTranslateY.setValue(0);
          handleClose();
        });
      } else {
        Animated.spring(swipeTranslateY, {
          toValue: 0,
          useNativeDriver: true,
          friction: 8,
        }).start();
      }
    });

  const handlePlay = useCallback(async () => {
    if (isPlayingRef.current) return;
    if (!cleanText) {
      console.warn("[DmuPlayer] No explanation text to speak");
      return;
    }

    // Stop any existing speech first
    try {
      const speaking = await Speech.isSpeakingAsync();
      if (speaking) {
        await Speech.stop();
        // Small delay to ensure speech engine is ready
        await new Promise((r) => setTimeout(r, 200));
      }
    } catch (e) {
      console.warn("[DmuPlayer] isSpeakingAsync error:", e);
    }

    isPlayingRef.current = true;
    setIsPlaying(true);
    setProgress(0);
    setCurrentSegment(null);
    hasBoundaryFiredRef.current = false;
    fallbackModeRef.current = false;
    lastFallbackPulseMsRef.current = 0;
    startTimeRef.current = Date.now();

    // Start animations
    startAnimations();

    // 타이머는 (1) onBoundary가 안 오면 폴백으로 전환하는 감시 역할과
    // (2) 폴백 모드일 때 실제 진행률/자막을 미는 역할을 함께 한다.
    const safetyLimitSec = estimatedDurationSec + 5;
    timerRef.current = setInterval(() => {
      if (!isPlayingRef.current) return;
      const elapsed = (Date.now() - startTimeRef.current) / 1000;

      if (!hasBoundaryFiredRef.current && !fallbackModeRef.current && elapsed * 1000 > BOUNDARY_GRACE_MS) {
        console.log("[DmuPlayer] No onBoundary event received, switching to time-based fallback sync");
        fallbackModeRef.current = true;
      }

      if (fallbackModeRef.current) {
        const active = fallbackWindows.find((w) => elapsed >= w.startTime && elapsed < w.endTime);
        setCurrentSegment((prev) => {
          if (!active) return prev;
          return prev?.startChar === active.startChar ? prev : active;
        });
        setProgress(estimatedDurationSec > 0 ? Math.min(elapsed / estimatedDurationSec, 1) : 0);

        // onBoundary가 없는 기기에서는 단어 단위 타이밍을 알 수 없으니,
        // 평균적인 발화 속도만큼의 간격으로 대신 펄스를 흉내낸다.
        const elapsedMs = elapsed * 1000;
        if (elapsedMs - lastFallbackPulseMsRef.current > 280) {
          lastFallbackPulseMsRef.current = elapsedMs;
          triggerTalkPulse();
        }
      }

      if (elapsed >= safetyLimitSec) {
        stopAll();
      }
    }, 100);

    console.log("[DmuPlayer] Speaking text length:", cleanText.length);
    console.log("[DmuPlayer] First 100 chars:", cleanText.substring(0, 100));

    Speech.speak(cleanText, {
      language: "ko-KR",
      rate: SPEECH_RATE,
      pitch: 1.0,
      volume: 1.0,
      onStart: () => {
        console.log("[DmuPlayer] TTS started successfully");
      },
      onBoundary: (event: { charIndex?: number; charLength?: number }) => {
        // ios/android: { charIndex, charLength } / web: SpeechSynthesisEvent(같은 필드 보유)
        const charIndex = event?.charIndex ?? 0;
        hasBoundaryFiredRef.current = true;
        fallbackModeRef.current = false;

        const total = cleanText.length || 1;
        setProgress(Math.min(charIndex / total, 1));

        const seg = findSegmentForCharIndex(segments, charIndex);
        setCurrentSegment((prev) => (seg && prev?.startChar === seg.startChar ? prev : seg));

        // onBoundary는 보통 단어 단위로 오므로, 실제 발화 타이밍 그대로
        // 펄스를 줘서 "말하는" 인상을 준다 (고정 주기 반복보다 훨씬 자연스럽다).
        triggerTalkPulse();
      },
      onDone: () => {
        console.log("[DmuPlayer] TTS completed");
        stopAll();
      },
      onStopped: () => {
        console.log("[DmuPlayer] TTS was stopped");
      },
      onError: (error: Error) => {
        console.error("[DmuPlayer] TTS error:", error);
        stopAll();
      },
    });
  }, [cleanText, segments, fallbackWindows, estimatedDurationSec, startAnimations, stopAll, triggerTalkPulse]);

  useEffect(() => {
    return () => {
      isPlayingRef.current = false;
      Speech.stop();
      stopAnimations();
      // stopAnimations()는 대기용 숨쉬기 루프를 다시 시작시키므로, 언마운트
      // 시에는 그것까지 마저 멈춘다.
      bodyAnimRef.current?.stop();
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <GestureDetector gesture={swipeGesture}>
    <Animated.View
      collapsable={false}
      style={[
        styles.container,
        { backgroundColor: colors.background, transform: [{ translateY: swipeTranslateY }] },
      ]}
    >
      {/* 아래로 스와이프해서 닫을 수 있다는 걸 알려주는 손잡이 */}
      <View style={styles.dragHandleWrapper}>
        <View style={[styles.dragHandle, { backgroundColor: colors.border }]} />
      </View>

      {/* Header */}
      <View style={styles.header}>
        <Pressable
          style={({ pressed }) => [
            styles.closeButton,
            pressed && { opacity: 0.6 },
          ]}
          onPress={handleClose}
        >
          <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>
          동그래 해설
        </Text>
        <View style={{ width: 36 }} />
      </View>

      {/* 글씨가 칠판 전체 폭을 쓰고, 캐릭터는 오른쪽 아래 구석에 작게 떠 있다 */}
      <View style={styles.stageArea}>
        <View style={styles.blackboard}>
          <View style={styles.chalkTray} />

          {/* 아래쪽엔 구석 캐릭터가 있는 만큼 paddingBottom으로 그 높이를
              비워둔다 - 글씨 폭은 그대로 전체를 쓰면서, 줄이 늘어나도 캐릭터와
              절대 안 겹치게 하기 위함(가로로 폭을 줄이면 다시 읽기 불편해짐). */}
          <View style={[styles.textArea, { paddingBottom: characterSize + 12 }]}>
            {currentSegment ? (
              <Animated.View style={{ opacity: subtitleOpacity }}>
                <Text style={styles.subtitleText}>{currentSegment.text}</Text>
              </Animated.View>
            ) : (
              <Text style={styles.subtitlePlaceholder}>
                {isPlaying ? "재생 중..." : "재생 버튼을 눌러주세요"}
              </Text>
            )}
          </View>

          <Animated.View
            style={[
              styles.characterWrapper,
              {
                transform: [
                  { translateY: bodyBounce },
                  { scale: scaleAnim },
                  {
                    rotate: wiggleAnim.interpolate({
                      inputRange: [-1, 1],
                      outputRange: ["-4deg", "4deg"],
                    }),
                  },
                ],
              },
            ]}
          >
            <Image
              source={DONGGURAECHARACTER_SOURCE}
              style={[
                styles.characterImage,
                { width: characterSize, height: characterSize },
              ]}
              contentFit="contain"
            />

            {/* 글씨(왼쪽)를 향해 짚어가며 설명하는 분필 포인터 */}
            <Animated.View
              style={[
                styles.chalkPointer,
                {
                  opacity: isPlaying ? 1 : 0,
                  transform: [
                    {
                      rotate: pointerAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: ["0deg", "-18deg"],
                      }),
                    },
                    {
                      translateX: pointerAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0, -10],
                      }),
                    },
                  ],
                },
              ]}
            >
              <View style={styles.chalkStick} />
            </Animated.View>
          </Animated.View>
        </View>
      </View>

      {/* Silent mode hint for iOS */}
      {Platform.OS === "ios" && (
        <Text style={[styles.silentModeHint, { color: colors.warning }]}>
          * iPhone 좌측 스위치를 올려 무음 모드를 해제해 주세요
        </Text>
      )}

      {/* Progress bar */}
      <View style={[styles.progressBar, { backgroundColor: colors.border }]}>
        <View
          style={[
            styles.progressFill,
            {
              backgroundColor: colors.primary,
              width: `${progress * 100}%`,
            },
          ]}
        />
      </View>

      {/* Play/Stop button */}
      <View style={styles.controls}>
        <Pressable
          style={({ pressed }) => [
            styles.playButton,
            { backgroundColor: isPlaying ? colors.error : colors.primary },
            pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] },
          ]}
          onPress={isPlaying ? stopAll : handlePlay}
        >
          <IconSymbol
            name={isPlaying ? "stop.fill" : "play.fill"}
            size={24}
            color="#FFFFFF"
          />
          <Text style={styles.playButtonText}>
            {isPlaying ? "정지" : "해설 듣기"}
          </Text>
        </Pressable>
      </View>

      {/* Explanation text preview - 길어도 잘리지 않고 스크롤해서 끝까지 읽을 수 있다.
          칠판(자막/TTS)은 오답 맞춤 해설을 쓰지만, 이 박스는 항상 기본 해설을 보여준다
          (referenceExplanation 미지정 시엔 explanation을 그대로 씀 - 사진인식 등). */}
      <View style={[styles.explanationPreview, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.explanationLabel, { color: colors.muted }]}>
          해설 내용
        </Text>
        <ScrollView style={styles.explanationScroll} showsVerticalScrollIndicator={true}>
          <Text style={[styles.explanationText, { color: colors.foreground }]}>
            {referenceExplanation ?? explanation}
          </Text>
        </ScrollView>
      </View>
    </Animated.View>
    </GestureDetector>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  dragHandleWrapper: {
    alignItems: "center",
    paddingTop: 8,
  },
  dragHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
  },
  closeButton: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  // 칠판이 전체 폭을 차지하고, 글씨가 그 폭을 온전히 다 쓴다. 캐릭터는 더 이상
  // 글씨와 폭을 나눠 쓰지 않고, 칠판 오른쪽 아래 구석에 작게 떠 있는 형태로
  // 바뀌었다 (글씨 가독성이 안 좋다는 피드백 때문 - 캐릭터가 옆에서 폭을
  // 잡아먹으면 좁은 폭에 줄바꿈이 많아져서 읽기 불편했다).
  stageArea: {
    paddingVertical: 20,
  },
  blackboard: {
    minHeight: 240,
    justifyContent: "center",
    backgroundColor: "#1f3d2e",
    borderRadius: 12,
    borderWidth: 8,
    // 나무 액자 느낌의 진한 갈색 테두리
    borderColor: "#6b4a34",
    paddingHorizontal: 20,
    paddingVertical: 20,
    paddingBottom: 28,
    position: "relative",
  },
  chalkTray: {
    position: "absolute",
    bottom: -6,
    left: "8%",
    right: "8%",
    height: 8,
    borderRadius: 4,
    backgroundColor: "#4a3323",
  },
  textArea: {
    width: "100%",
  },
  characterWrapper: {
    position: "absolute",
    right: 8,
    bottom: 8,
    alignItems: "center",
    justifyContent: "flex-end",
  },
  characterImage: {},
  chalkPointer: {
    position: "absolute",
    bottom: "30%",
    left: -6,
  },
  chalkStick: {
    width: 34,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#f5e6c8",
    transform: [{ rotate: "-35deg" }],
  },
  silentModeHint: {
    fontSize: 12,
    textAlign: "center",
    marginBottom: 10,
    fontWeight: "600",
  },
  subtitleText: {
    fontSize: 19,
    fontWeight: "700",
    lineHeight: 30,
    letterSpacing: 0.2,
    textAlign: "left",
    color: "#fdf6e8",
  },
  subtitlePlaceholder: {
    fontSize: 15,
    textAlign: "left",
    color: "#cbb996",
  },
  progressBar: {
    height: 4,
    borderRadius: 2,
    marginBottom: 16,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 2,
  },
  controls: {
    alignItems: "center",
    marginBottom: 16,
  },
  playButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 28,
    paddingVertical: 14,
    paddingHorizontal: 32,
    minWidth: 160,
  },
  playButtonText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  explanationPreview: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
  },
  explanationScroll: {
    maxHeight: 220,
  },
  explanationLabel: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 8,
  },
  explanationText: {
    fontSize: 16,
    lineHeight: 26,
    letterSpacing: 0.1,
  },
});
