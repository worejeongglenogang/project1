#!/usr/bin/env node
// npm/pnpm run scripts through cmd.exe on Windows, which doesn't understand
// bash's ${VAR:-default} syntax. This wrapper picks the port in Node instead,
// so `pnpm dev:metro` works the same on Windows, macOS, and Linux.
import { spawn } from "node:child_process";

const port = process.env.EXPO_PORT || "8081";

const child = spawn("npx", ["expo", "start", "--web", "--port", port], {
  stdio: "inherit",
  shell: true,
  env: { ...process.env, EXPO_USE_METRO_WORKSPACE_ROOT: "1" },
});

child.on("exit", (code) => process.exit(code ?? 1));
