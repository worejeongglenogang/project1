/**
 * Minimal .env loader. Reads `.env` from the project root and sets any
 * variables it defines onto process.env — but only if they aren't already
 * set, so real environment variables (e.g. set by your shell or a hosting
 * provider) always win over the file.
 *
 * (예전에는 Manus 플랫폼이 주입하는 시스템 환경변수 이름을 EXPO_PUBLIC_* 이름으로
 * 매핑해주는 로직이 있었는데, 이제 Manus를 쓰지 않아서 그 매핑은 제거했다.
 * .env.example 참고.)
 */
import fs from "fs";
import path from "path";

const envPath = path.resolve(process.cwd(), ".env");

if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, "utf8");
  const lines = envContent.split("\n");

  lines.forEach((line) => {
    // Skip comments and empty lines
    if (!line || line.trim().startsWith("#")) return;

    const match = line.match(/^([^=]+)=(.*)$/);
    if (match) {
      const key = match[1].trim();
      const value = match[2].trim().replace(/^["']|["']$/g, ""); // Remove quotes

      // Only set if not already defined in environment
      if (!process.env[key]) {
        process.env[key] = value;
      }
    }
  });
}
